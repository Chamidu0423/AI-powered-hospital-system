function createDoctorCard(doctor) {
    return `
        <div class="col-md-4">
            <div class="doctor-card">
                <img src="${doctor.image}" alt="${doctor.name}" class="doctor-image" 
                     onerror="this.src='img/default-doctor.jpg'">
                <div class="doctor-info">
                    <h3 class="doctor-name">${doctor.name}</h3>
                    <p class="doctor-id"><strong>ID:</strong> ${doctor.id}</p>
                    <p class="doctor-specialty">${doctor.specialty.charAt(0).toUpperCase() + doctor.specialty.slice(1)}</p>
                    <div class="doctor-rating">
                        ${getStarRating(doctor.rating)}
                        <span>(${doctor.rating})</span>
                    </div>
                    <p><strong>Experience:</strong> ${doctor.experience}</p>
                    <p><strong>Available:</strong> ${doctor.availability}</p>
                    <p><strong>Contact:</strong> ${doctor.phone}</p>
                    <button class="book-appointment-btn" onclick="bookAppointment('${doctor.id}')">
                        Book Appointment
                    </button>
                </div>
            </div>
        </div>
    `;
}

function getStarRating(rating) {
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            stars += '<i class="fas fa-star"></i>';
        } else if (i - 0.5 <= rating) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        } else {
            stars += '<i class="far fa-star"></i>';
        }
    }
    return stars;
}

function searchDoctors() {
    const specialty = document.getElementById('specialtyFilter').value.toLowerCase();
    const searchTerm = document.getElementById('searchInput').value;
    
    fetch(`api/get_doctors.php?search=${encodeURIComponent(searchTerm)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const filteredDoctors = data.doctors.filter(doctor => 
                    !specialty || doctor.specialty === specialty
                );
                displayDoctors(filteredDoctors);
            } else {
                alert(data.message || 'Error fetching doctors');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error fetching doctors');
        });
}

function displayDoctors(doctorsList) {
    const container = document.getElementById('doctorsList');
    if (doctorsList.length === 0) {
        container.innerHTML = '<div class="col-12 text-center"><p>No doctors found matching your criteria.</p></div>';
        return;
    }
    container.innerHTML = doctorsList.map(doctor => createDoctorCard(doctor)).join('');
}

function bookAppointment(doctorId) {
    alert(`Booking functionality for doctor ${doctorId} will be implemented soon!`);
}

document.addEventListener('DOMContentLoaded', () => {
    searchDoctors();
});