document.addEventListener("DOMContentLoaded", function () {
  const serviceData = {
    "pulse-emergency-ambulance-medical-transport": {
      title: "Emergency Ambulance & Medical Transport",
      content: `
                <p>Our 24/7 Emergency Ambulance Service provides rapid response and professional medical care during transport.</p>
                <h4>Key Features:</h4>
                <ul>
                    <li>Advanced Life Support (ALS) ambulances</li>
                    <li>Highly trained medical staff</li>
                    <li>State-of-the-art medical equipment</li>
                    <li>GPS-tracked fleet for optimal response times</li>
                    <li>Inter-hospital transfers</li>
                </ul>
                <p>We also offer specialized medical transportation services including:</p>
                <ul>
                    <li>Air ambulance services</li>
                    <li>Non-emergency medical transport</li>
                    <li>Patient repatriation</li>
                    <li>Event medical coverage</li>
                </ul>`,
    },
    "health-screening": {
      title: "Health Screening",
      content: `
                <p>Comprehensive health screening packages designed for early detection and prevention.</p>
                <h4>Available Screenings:</h4>
                <ul>
                    <li>Basic Health Screening</li>
                    <li>Executive Health Screening</li>
                    <li>Cancer Screening</li>
                    <li>Cardiac Health Screening</li>
                    <li>Women's Health Screening</li>
                    <li>Men's Health Screening</li>
                </ul>
                <p>Each screening package includes:</p>
                <ul>
                    <li>Detailed medical report</li>
                    <li>Doctor's consultation</li>
                    <li>Personalized health recommendations</li>
                    <li>Follow-up care planning</li>
                </ul>`,
    },
    "laboratory-services": {
      title: "Laboratory Services",
      content: `
                <p>State-of-the-art laboratory facilities offering a wide range of diagnostic tests.</p>
                <h4>Our Services Include:</h4>
                <ul>
                    <li>Clinical Chemistry</li>
                    <li>Hematology</li>
                    <li>Microbiology</li>
                    <li>Molecular Diagnostics</li>
                    <li>Genetic Testing</li>
                </ul>
                <p>Additional Features:</p>
                <ul>
                    <li>24/7 emergency testing</li>
                    <li>Home sample collection</li>
                    <li>Online test results</li>
                    <li>Expert pathologist consultation</li>
                </ul>`,
    },
    "pulse-fertility-centre": {
      title: "Pulse Fertility Centre",
      content: `
                <p>Comprehensive fertility treatments using advanced reproductive technologies.</p>
                <h4>Available Treatments:</h4>
                <ul>
                    <li>In Vitro Fertilization (IVF)</li>
                    <li>Intrauterine Insemination (IUI)</li>
                    <li>Fertility Preservation</li>
                    <li>Genetic Screening</li>
                </ul>
                <p>Support Services:</p>
                <ul>
                    <li>Fertility Counseling</li>
                    <li>Nutritional Support</li>
                    <li>Psychological Support</li>
                    <li>Support Group Sessions</li>
                </ul>`,
    },
    "pulse-proton-therapy-centre": {
      title: "Pulse Proton Therapy Centre",
      content: `
                <p>Advanced cancer treatment using precise proton beam therapy.</p>
                <h4>Treatment Capabilities:</h4>
                <ul>
                    <li>Precise tumor targeting</li>
                    <li>Minimal damage to healthy tissue</li>
                    <li>Treatment for complex tumors</li>
                    <li>Pediatric cancer treatment</li>
                </ul>
                <p>Additional Services:</p>
                <ul>
                    <li>Treatment Planning</li>
                    <li>Recovery Support</li>
                    <li>Follow-up Care</li>
                    <li>Research Participation Options</li>
                </ul>`,
    },
    "nutrition-dietetics": {
      title: "Nutrition & Dietetics",
      content: `
                <p>Personalized nutrition counseling and dietary planning services.</p>
                <h4>Our Services:</h4>
                <ul>
                    <li>Nutritional Assessment</li>
                    <li>Diet Planning</li>
                    <li>Weight Management</li>
                    <li>Sports Nutrition</li>
                </ul>
                <p>Specialized Programs:</p>
                <ul>
                    <li>Diabetes Management</li>
                    <li>Heart-Healthy Diets</li>
                    <li>Pediatric Nutrition</li>
                    <li>Pregnancy Nutrition</li>
                </ul>`,
    },
    "cancer-centre": {
      title: "Cancer Centre",
      content: `
                <p>Comprehensive cancer care with advanced treatment options and support services.</p>
                <h4>Treatment Options:</h4>
                <ul>
                    <li>Chemotherapy</li>
                    <li>Radiation Therapy</li>
                    <li>Immunotherapy</li>
                    <li>Targeted Therapy</li>
                </ul>
                <p>Support Services:</p>
                <ul>
                    <li>Cancer Counseling</li>
                    <li>Pain Management</li>
                    <li>Rehabilitation</li>
                    <li>Support Groups</li>
                </ul>`,
    },
    "radiology-imaging": {
      title: "Radiology & Imaging",
      content: `
                <p>Advanced diagnostic imaging services using state-of-the-art technology.</p>
                <h4>Available Services:</h4>
                <ul>
                    <li>MRI Scanning</li>
                    <li>CT Scanning</li>
                    <li>X-Ray Services</li>
                    <li>Ultrasound</li>
                    <li>Nuclear Medicine</li>
                </ul>
                <p>Special Features:</p>
                <ul>
                    <li>3D Imaging</li>
                    <li>Digital Radiography</li>
                    <li>Emergency Imaging</li>
                    <li>Interventional Radiology</li>
                </ul>`,
    },
  };

  const modalHTML = `
        <div class="service-modal" id="serviceModal">
            <div class="service-modal-content">
                <div class="service-modal-header">
                    <h3 class="service-modal-title"></h3>
                    <button class="service-modal-close">&times;</button>
                </div>
                <div class="service-modal-body"></div>
                <div class="service-modal-footer">
                    <button class="service-modal-btn">Close</button>
                </div>
            </div>
        </div>
    `;

  document.body.insertAdjacentHTML("beforeend", modalHTML);

  const modal = document.getElementById("serviceModal");
  const modalTitle = modal.querySelector(".service-modal-title");
  const modalBody = modal.querySelector(".service-modal-body");
  const closeButtons = modal.querySelectorAll(
    ".service-modal-close, .service-modal-btn"
  );

  document.querySelectorAll(".animated-button").forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault();
      const serviceTitle = this.closest(".col-md-6")
        .querySelector("h3")
        .textContent.trim();
      console.log("Service Title:", serviceTitle);

      const serviceKey = serviceTitle
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "");
      console.log("Service Key:", serviceKey);

      if (serviceData[serviceKey]) {
        modalTitle.textContent = serviceData[serviceKey].title;
        modalBody.innerHTML = serviceData[serviceKey].content;
        modal.classList.add("active");
        document.body.style.overflow = "hidden";
      } else {
        console.log("No data found for service:", serviceKey);
      }
    });
  });

  closeButtons.forEach((button) => {
    button.addEventListener("click", closeModal);
  });

  modal.addEventListener("click", function (e) {
    if (e.target === this) {
      closeModal();
    }
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && modal.classList.contains("active")) {
      closeModal();
    }
  });

  function closeModal() {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  }
});
