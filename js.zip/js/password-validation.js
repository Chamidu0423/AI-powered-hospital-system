$(document).ready(function() {
    $('#confirmPassword').on('input', function() {
        const password = $('#password').val();
        const confirmPassword = $(this).val();
        
        if (password !== confirmPassword) {
            $('#passwordMatch').show();
        } else {
            $('#passwordMatch').hide();
        }
    });

    $('#createPasswordForm').on('submit', function(e) {
        e.preventDefault();
        const password = $('#password').val();
        const confirmPassword = $('#confirmPassword').val();

        if (password !== confirmPassword) {
            $('#passwordMatch').show();
            return;
        }

        $.ajax({
            url: 'update_password.php',
            method: 'POST',
            data: { password: password },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Password setup completed successfully!');
                    setTimeout(function() {
                        window.location.href = 'index.php';
                    }, 1000);
                } else {
                    alert(response.message || 'Error updating password');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            }
        });
    });
});