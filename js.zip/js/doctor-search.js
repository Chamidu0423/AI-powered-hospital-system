document.addEventListener("DOMContentLoaded", function () {
  const modal = document.getElementById("doctorModal");
  const btn = document.getElementById("findDoctorBtn");
  const searchInput = document.getElementById("searchInput");
  const doctorsGrid = document.getElementById("doctorsGrid");

  btn.onclick = function () {
    modal.style.display = "block";
    modal.offsetHeight;
    modal.classList.add("show");
    searchDoctors("");
    document.body.style.overflow = "hidden";
  };

  window.onclick = function (event) {
    if (event.target == modal) {
      closeModal();
    }
  };

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && modal.classList.contains("show")) {
      closeModal();
    }
  });

  function closeModal() {
    modal.classList.remove("show");
    document.body.style.overflow = "";
    setTimeout(() => {
      modal.style.display = "none";
    }, 300);
  }

  let timeout = null;
  searchInput.addEventListener("input", function () {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      searchDoctors(this.value);
    }, 300);
  });

  function searchDoctors(searchTerm) {
    doctorsGrid.innerHTML =
      '<div class="text-center w-100"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';

    fetch(`search_doctors.php?search=${encodeURIComponent(searchTerm)}`)
      .then((response) => response.json())
      .then((doctors) => {
        displayDoctors(doctors);
      })
      .catch((error) => {
        console.error("Error:", error);
        doctorsGrid.innerHTML =
          '<p class="text-center text-danger">Error loading doctors. Please try again later.</p>';
      });
  }

  function displayDoctors(doctors) {
    doctorsGrid.innerHTML = "";

    if (doctors.length === 0) {
      doctorsGrid.innerHTML =
        '<p class="text-center">No doctors found matching your search.</p>';
      return;
    }

    doctors.forEach((doctor) => {
      const doctorCard = document.createElement("div");
      doctorCard.className = "doctor-card";
      doctorCard.innerHTML = `
                <img src="${doctor.image}" alt="${
        doctor.name
      }" onerror="this.src='assets/img/default-doctor.png'">
                <div class="doctor-info">
                    <div class="doctor-id-container">
                        <span class="doctor-id">ID: ${doctor.id}</span>
                        <button class="copy-id-btn" data-doctor-id="${
                          doctor.id
                        }" title="Copy Doctor ID">
                            <i class="fa-regular fa-copy"></i>
                        </button>
                    </div>
                    <h3>${doctor.name}</h3>
                    <p><i class="fas fa-stethoscope"></i> ${
                      doctor.specialty || "General Medicine"
                    }</p>
                    <p><i class="fas fa-star"></i> ${doctor.rating} Rating</p>
                    <p><i class="fas fa-clock"></i> ${doctor.experience}</p>
                    <p><i class="fas fa-calendar"></i> Available: ${
                      doctor.availability
                    }</p>
                    <p><i class="fas fa-phone"></i> ${doctor.phone}</p>
                </div>
            `;
      doctorsGrid.appendChild(doctorCard);
    });

    document.querySelectorAll(".copy-id-btn").forEach((btn) => {
      btn.addEventListener("click", function (e) {
        e.stopPropagation();
        const doctorId = this.getAttribute("data-doctor-id");
        copyDoctorId(doctorId, this);
      });
    });
  }
});

function copyDoctorId(id, button) {
  navigator.clipboard
    .writeText(id)
    .then(() => {
      const originalIcon = button.innerHTML;
      button.innerHTML = '<i class="fas fa-check"></i>';
      setTimeout(() => {
        button.innerHTML = originalIcon;
      }, 1000);
    })
    .catch((err) => {
      console.error("Failed to copy:", err);
    });
}
