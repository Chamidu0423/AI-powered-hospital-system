document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('.search-input');
    const newsCards = document.querySelectorAll('.news-card');

    searchInput.addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        
        newsCards.forEach(card => {
            const content = card.textContent.toLowerCase();
            const parent = card.parentElement;
            
            if (content.includes(searchTerm)) {
                parent.style.display = 'block';
            } else {
                parent.style.display = 'none';
            }
        });
    });
});