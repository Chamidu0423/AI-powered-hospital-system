$(document).ready(function() {
    $('#user_id').on('input', function() {
        const userId = $(this).val();
        $.ajax({
            url: 'check_admin.php',
            method: 'GET',
            data: { user_id: userId },
            dataType: 'json',
            success: function(response) {
                if (response.is_admin) {
                    $('#passwordDiv').slideDown();
                    $('#password-label').text('Admin Password');
                } else {
                    $('#passwordDiv').slideUp();
                    $('#password').val('');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    });

    $('#loginForm').on('submit', function(e) {
        e.preventDefault();
        const userId = $('#user_id').val();
        const password = $('#password').val();

        $.ajax({
            url: 'verify_login.php',
            method: 'POST',
            data: {
                user_id: userId,
                password: password
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    window.location.href = response.redirect;
                } else {
                    alert(response.message || 'Login failed. Please try again.');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            }
        });
    });
});