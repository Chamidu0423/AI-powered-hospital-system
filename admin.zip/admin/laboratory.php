<?php
include 'config.php';

// Initialize variables
$searchTerm = ''; // Initialize the search term variable
$searchResults = []; // Initialize the search results array
$success = ''; // Initialize the success message variable
$error = ''; // Initialize the error message variable

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check which form was submitted
    if (isset($_POST['form_type'])) {
        if ($_POST['form_type'] == 'laboratory_test') {
            // Process Laboratory Test form
            if (
                isset($_POST['patientId']) &&
                isset($_POST['testTitle']) &&
                isset($_POST['diagnosisId']) &&
                isset($_POST['staffId']) &&
                isset($_POST['testDate']) &&
                isset($_POST['testResults'])
            ) {
                // Get form data
                $patientId = $_POST['patientId'];
                $testTitle = $_POST['testTitle'];
                $diagnosisId = $_POST['diagnosisId'];
                $staffId = $_POST['staffId'];
                $testDate = $_POST['testDate'];
                $testResults = $_POST['testResults'];
                
                // Insert data into Laboratory table
                $sql = "INSERT INTO Laboratory (TestTitle, Date, TestResults, PatientID, StaffID, DiagnosisID) 
                        VALUES (?, ?, ?, ?, ?, ?)";
                
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss", $testTitle, $testDate, $testResults, $patientId, $staffId, $diagnosisId);
                
                if ($stmt->execute()) {
                    // Update diagnosis status
                    $updateSql = "UPDATE Diagnosis SET Status = 'Completed' WHERE DiagnosisID = ?";
                    $updateStmt = $conn->prepare($updateSql);
                    $updateStmt->bind_param("s", $diagnosisId);
                    $updateStmt->execute();
                    $updateStmt->close();
                    
                    $success = "Laboratory test recorded successfully!";
                } else {
                    $error = "Error: " . $stmt->error;
                }
                
                $stmt->close();
            } else {
                $error = "All form fields are required for Laboratory Test!";
            }
        } elseif ($_POST['form_type'] == 'assign_lab_date') {
            // Process Assign Lab Date form
            if (
                isset($_POST['patientId']) &&
                isset($_POST['testTitle']) &&
                isset($_POST['description']) &&
                isset($_POST['date']) &&
                isset($_POST['time'])
            ) {
                // Get form data
                $patientId = $_POST['patientId'];
                $testTitle = $_POST['testTitle'];
                $description = $_POST['description'];
                $date = $_POST['date'];
                $time = $_POST['time'];
                
                // Insert data into the LAB_ASSIGN_DATE table
                $sql = "INSERT INTO LAB_ASSIGN_DATE (PatientID, TestTitle, Description, Date, Time) 
                        VALUES (?, ?, ?, ?, ?)";
                
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("sssss", $patientId, $testTitle, $description, $date, $time);
                    
                    if ($stmt->execute()) {
                        $success = "Lab date assigned successfully!";
                    } else {
                        $error = "Error: " . $stmt->error;
                    }
                    
                    $stmt->close();
                } else {
                    $error = "Error preparing SQL statement: " . $conn->error;
                }
            } else {
                $error = "All form fields are required for Assign Lab Date!";
            }
        }
    } else {
        $error = "Invalid form submission!";
    }
}

// Search functionality
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search']; // Get the search term from the form
    
    $searchSql = "SELECT l.*, p.Name as PatientName, s.Name as StaffName, d.Description as DiagnosisDescription 
                 FROM Laboratory l 
                 JOIN Patient p ON l.PatientID = p.PatientID 
                 JOIN Staff s ON l.StaffID = s.StaffID 
                 JOIN Diagnosis d ON l.DiagnosisID = d.DiagnosisID 
                 WHERE l.TestID LIKE ? OR p.Name LIKE ? OR l.TestTitle LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("sss", $searchParam, $searchParam, $searchParam);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
    
    $stmt->close();
} else {
    $searchTerm = ''; // Ensure $searchTerm is defined even if no search is performed
    $searchResults = []; // Initialize $searchResults as an empty array
}

// Fetch data from the LAB_REQUEST table
$labRequestSql = "SELECT * FROM LAB_REQUEST ORDER BY RequestID DESC";
$labRequestResult = $conn->query($labRequestSql);

// Check if there are any results
if ($labRequestResult->num_rows > 0) {
    $labRequests = $labRequestResult->fetch_all(MYSQLI_ASSOC);
} else {
    $labRequests = []; // No data found
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratory Management - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #current-date-time {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        background: #f5f5f5;
        padding: 5px 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    #theme-icon {
        font-size: 20px;
        color: #ffcc00;
        cursor: pointer;
        transition: transform 0.3s ease, color 0.3s ease;
    }

    #theme-icon:hover {
        transform: scale(1.2);
        color: #ffa500;
    }

    .h2 {
        text-align: center;
        display: block;
        margin: 0 auto;
    }

    .sidebar-icon {
        font-size: 22px;
        color: #007bff;
    }

    .sidebar-text {
        font-size: 18px;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Laboratory Management</h1>
                    <div class="d-flex align-items-center">
                        <!-- Date, Time, and Day Display -->
                        <span id="current-date-time" class="me-3"></span>
                        <!-- Day/Night Icon -->
                        <i id="theme-icon" class="fas"></i>
                    </div>
                </div>

                <script>
                function updateDateTimeAndTheme() {
                    // Get the current date and time
                    const currentDate = new Date();
                    let hours = currentDate.getHours();
                    let minutes = currentDate.getMinutes();
                    let day = currentDate.getDate();
                    let month = currentDate.getMonth() + 1; // Months are 0-indexed
                    let year = currentDate.getFullYear();

                    // Day of the week
                    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    const dayOfWeek = daysOfWeek[currentDate.getDay()];

                    minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if minutes are less than 10

                    const dateString = `${month}/${day}/${year}`;
                    const timeString = `${hours}:${minutes}`;

                    // Display date, time, and day of the week
                    document.getElementById('current-date-time').textContent =
                        `${dayOfWeek}, ${dateString} - ${timeString}`;

                    // Change the icon and theme based on the time
                    const themeIcon = document.getElementById('theme-icon');
                    if (hours >= 6 && hours < 18) {
                        // Day time (6 AM to 6 PM)
                        themeIcon.classList.remove('fa-moon');
                        themeIcon.classList.add('fa-sun');
                        themeIcon.style.color = 'orange'; // Day icon color
                    } else {
                        // Night time (6 PM to 6 AM)
                        themeIcon.classList.remove('fa-sun');
                        themeIcon.classList.add('fa-moon');
                        themeIcon.style.color = 'blue'; // Night icon color
                    }
                }

                // Update time, date, and theme every minute
                setInterval(updateDateTimeAndTheme, 60000);

                // Initial call to set the date, time, and theme on page load
                updateDateTimeAndTheme();
                </script>

                <!-- Navigation Tabs -->
                <ul class="nav nav-tabs mb-4" id="labTabs" role="tablist">
                    
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="lab-request-tab" data-bs-toggle="tab" data-bs-target="#lab-request"
                            type="button" role="tab" aria-controls="lab-request" aria-selected="false">
                            <i class="fas fa-list me-2"></i>Lab Requests
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="lab-assign-tab" data-bs-toggle="tab" data-bs-target="#lab-assign"
                            type="button" role="tab" aria-controls="lab-assign" aria-selected="false">
                            <i class="fas fa-calendar-alt me-2"></i>Assign Lab Date
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="lab-tests-tab" data-bs-toggle="tab" data-bs-target="#lab-tests"
                            type="button" role="tab" aria-controls="lab-tests" aria-selected="true">
                            <i class="fas fa-vial me-2"></i>Laboratory Tests
                        </button>
                    </li>
                </ul>

                <!-- Tab Content -->
                <div class="tab-content" id="labTabsContent">
                    <!-- Laboratory Tests Tab (Default) -->
                    <div class="tab-pane fade show active" id="lab-tests" role="tabpanel" aria-labelledby="lab-tests-tab">
                        <div class="row">
                            <!-- Test Form -->
                            <div class="col-lg-6" style="width: ;">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Record Laboratory Test</h6>
                                    </div>
                                    <div class="card-body">
                                        <?php if (isset($success) && isset($_POST['form_type']) && $_POST['form_type'] == 'laboratory_test'): ?>
                                        <div class="alert alert-success" role="alert" id="success-message">
                                            <?php echo $success; ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if (isset($error) && isset($_POST['form_type']) && $_POST['form_type'] == 'laboratory_test'): ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?php echo $error; ?>
                                        </div>
                                        <?php endif; ?>

                                        <form method="POST" action="">
                                            <!-- Hidden input to identify the form -->
                                            <input type="hidden" name="form_type" value="laboratory_test">

                                            <div class="mb-3">
                                                <label for="patientId" class="form-label">Patient</label>
                                                <select class="form-select" id="patientId" name="patientId" required>
                                                    <option value="">Select Patient</option>
                                                    <?php
                                                    $patientSql = "SELECT PatientID, Name FROM Patient ORDER BY Name";
                                                    $patientResult = $conn->query($patientSql);
                                                    
                                                    if ($patientResult->num_rows > 0) {
                                                        while($row = $patientResult->fetch_assoc()) {
                                                            echo "<option value='" . $row["PatientID"] . "'>" . $row["Name"] . " (" . $row["PatientID"] . ")</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label for="diagnosisId" class="form-label">Diagnosis</label>
                                                <select class="form-select" id="diagnosisId" name="diagnosisId" required>
                                                    <option value="">Select Diagnosis</option>
                                                    <?php
                                                    $diagnosisSql = "SELECT d.DiagnosisID, d.Description, p.Name 
                                                                   FROM Diagnosis d 
                                                                   JOIN Patient p ON d.PatientID = p.PatientID 
                                                                   WHERE d.Status = 'Pending'
                                                                   ORDER BY d.DiagnosisID DESC";
                                                    $diagnosisResult = $conn->query($diagnosisSql);
                                                    
                                                    if ($diagnosisResult->num_rows > 0) {
                                                        while($row = $diagnosisResult->fetch_assoc()) {
                                                            $description = substr($row["Description"], 0, 30) . (strlen($row["Description"]) > 30 ? "..." : "");
                                                            echo "<option value='" . $row["DiagnosisID"] . "'>" . $row["DiagnosisID"] . " - " . $description . "</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label for="testTitle" class="form-label">Test Title</label>
                                                <input type="text" class="form-control" id="testTitle" name="testTitle" required>
                                            </div>

                                            <div class="mb-3">
                                                <label for="staffId" class="form-label">Lab Technician</label>
                                                <select class="form-select" id="staffId" name="staffId" required>
                                                    <option value="">Select Lab Technician</option>
                                                    <?php
                                                    $staffSql = "SELECT StaffID, Name FROM Staff WHERE Position = 'Laboratorist' ORDER BY Name";
                                                    $staffResult = $conn->query($staffSql);
                                                    
                                                    if ($staffResult->num_rows > 0) {
                                                        while($row = $staffResult->fetch_assoc()) {
                                                            echo "<option value='" . $row["StaffID"] . "'>" . $row["Name"] . " (" . $row["StaffID"] . ")</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label for="testDate" class="form-label">Test Date</label>
                                                <input type="date" class="form-control" id="testDate" name="testDate" required>
                                            </div>

                                            <div class="mb-3">
                                                <label for="testResults" class="form-label">Test Results</label>
                                                <textarea class="form-control" id="testResults" name="testResults" rows="4" required></textarea>
                                            </div>

                                            <div class="d-grid gap-2">
                                                <button type="submit" class="btn btn-primary">Record Test</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Lab Requests Tab -->
                    <div class="tab-pane fade" id="lab-request" role="tabpanel" aria-labelledby="lab-request-tab">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Lab Requests</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Request ID</th>
                                                <th>Patient ID</th>
                                                <th>Test Title</th>
                                                <th>Description</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (!empty($labRequests)): ?>
                                                <?php foreach ($labRequests as $request): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($request['RequestID']); ?></td>
                                                        <td><?php echo htmlspecialchars($request['PatientID']); ?></td>
                                                        <td><?php echo htmlspecialchars($request['TestTitle']); ?></td>
                                                        <td><?php echo htmlspecialchars($request['Description']); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="4" class="text-center">No lab requests found.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Assign Lab Date Tab -->
                    <div class="tab-pane fade" id="lab-assign" role="tabpanel" aria-labelledby="lab-assign-tab">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Assign Lab Date</h6>
                            </div>
                            <div class="card-body">
                                <?php if (isset($success) && isset($_POST['form_type']) && $_POST['form_type'] == 'assign_lab_date'): ?>
                                <div class="alert alert-success" role="alert" id="success-message">
                                    <?php echo $success; ?>
                                </div>
                                <?php endif; ?>

                                <?php if (isset($error) && isset($_POST['form_type']) && $_POST['form_type'] == 'assign_lab_date'): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $error; ?>
                                </div>
                                <?php endif; ?>

                                <form method="POST" action="">
                                    <!-- Hidden input to identify the form -->
                                    <input type="hidden" name="form_type" value="assign_lab_date">

                                    <div class="mb-3">
                                        <label for="assignPatientId" class="form-label">Patient ID</label>
                                        <!-- <input type="text" class="form-control" id="assignPatientId" name="patientId" required> -->
                                        <select class="form-select" id="assignPatientId" name="patientId" required>
                                                    <option value="">Select Patient</option>
                                                    <?php
                                                    $patientSql = "SELECT PatientID, Name FROM Patient ORDER BY Name";
                                                    $patientResult = $conn->query($patientSql);
                                                    
                                                    if ($patientResult->num_rows > 0) {
                                                        while($row = $patientResult->fetch_assoc()) {
                                                            echo "<option value='" . $row["PatientID"] . "'>" . $row["Name"] . " (" . $row["PatientID"] . ")</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                    </div>
                                    <div class="mb-3">
                                        <label for="assignTestTitle" class="form-label">Test Title</label>
                                        <input type="text" class="form-control" id="assignTestTitle" name="testTitle" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="assignDescription" class="form-label">Description</label>
                                        <textarea class="form-control" id="assignDescription" name="description" rows="4" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="assignDate" class="form-label">Date</label>
                                        <input type="date" class="form-control" id="assignDate" name="date" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="assignTime" class="form-label">Time</label>
                                        <input type="time" class="form-control" id="assignTime" name="time" required>
                                    </div>
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">Assign Lab Date</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Test Details Modal -->
                <div class="modal fade" id="testDetailsModal" tabindex="-1" aria-labelledby="testDetailsModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="testDetailsModalLabel">Test Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="testDetailsContent">
                                <!-- Test details will be loaded here -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="printTestBtn">Print</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // Patient selection changes diagnosis options
        $('#patientId').change(function() {
            var patientId = $(this).val();

            if (patientId) {
                // AJAX request to get diagnoses for this patient
                $.ajax({
                    url: 'getPatientDiagnoses.php',
                    type: 'GET',
                    data: {
                        patientId: patientId
                    },
                    success: function(response) {
                        $('#diagnosisId').html(response);
                    }
                });
            }
        });

        // View test details
        $('.view-test').click(function() {
            var testId = $(this).data('id');

            // AJAX request to get test details
            $.ajax({
                url: 'getTestDetails.php',
                type: 'GET',
                data: {
                    id: testId
                },
                success: function(response) {
                    $('#testDetailsContent').html(response);
                    $('#testDetailsModal').modal('show');
                },
                error: function() {
                    alert('Error fetching test details');
                }
            });
        });

        // Print test
        $('.print-test').click(function() {
            var testId = $(this).data('id');

            // Open print window
            window.open('printTest.php?id=' + testId, '_blank');
        });

        // Print from modal
        $('#printTestBtn').click(function() {
            var testId = $('#testDetailsContent').data('test-id');
            if (testId) {
                window.open('printTest.php?id=' + testId, '_blank');
            }
        });
    });

    // Function to hide the success message after 5 seconds
    function hideMessage() {
        const messageElement = document.getElementById('success-message');
        if (messageElement) {
            setTimeout(() => {
                messageElement.style.display = 'none';
            }, 5000); // Hide after 5 seconds
        }
    }

    // Call the function when the page loads
    window.onload = hideMessage;
    </script>
</body>

</html>