<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointmentId = $_POST['appointmentId'];
    $patientId = $_POST['patientId'];
    $description = $_POST['description'];
    $medicine = $_POST['medicine'];
    $testTitle = $_POST['testTitle'];
    $status = $_POST['status'];
    
    $sql = "INSERT INTO Diagnosis (PatientID, AppointmentID, Description, Medicine, TestTitle, Status) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $patientId, $appointmentId, $description, $medicine, $testTitle, $status);
    
    if ($stmt->execute()) {
        header("Location: appointments.php?tab=diagnosis&success=1");
        exit();
    } else {
        header("Location: appointments.php?tab=diagnosis&error=" . urlencode($stmt->error));
        exit();
    }
    
    $stmt->close();
} else {
    header("Location: appointments.php");
    exit();
}
?>