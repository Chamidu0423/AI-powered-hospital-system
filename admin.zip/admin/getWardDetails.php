<?php
include 'config.php';

if (isset($_GET['id'])) {
    $wardID = $_GET['id']; // Assuming WardID is the correct column name

    // Correcting the query by using 'WardID' instead of 'WardNumber'
    $sql = "SELECT w.*, p.Name as PatientName, s.Name as StaffName, d.Description as DiagnosisDescription 
            FROM Ward w 
            JOIN Patient p ON w.PatientID = p.PatientID 
            JOIN Staff s ON w.StaffID = s.StaffID 
            JOIN Diagnosis d ON w.DiagnosisID = d.DiagnosisID 
            WHERE w.WardID = ?"; // Use the correct column name
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die('<div class="alert alert-danger">Error in SQL statement: ' . $conn->error . '</div>');
    }

    $stmt->bind_param("i", $wardID);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $ward = $result->fetch_assoc();
        
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Ward Number:</h6>';
        echo '<p>' . htmlspecialchars($ward['WardID']) . '</p>'; // Use the correct column
        
        echo '<h6 class="font-weight-bold">Bed Number:</h6>';
        echo '<p>' . htmlspecialchars($ward['BedNo']) . '</p>';
        
        echo '<h6 class="font-weight-bold">Patient:</h6>';
        echo '<p>' . htmlspecialchars($ward['PatientName']) . ' (' . htmlspecialchars($ward['PatientID']) . ')</p>';
        
        echo '<h6 class="font-weight-bold">Admission Date:</h6>';
        echo '<p>' . htmlspecialchars($ward['InDate']) . '</p>';
        
        echo '<h6 class="font-weight-bold">Discharge Date:</h6>';
        echo '<p>' . (!empty($ward['OutDate']) ? htmlspecialchars($ward['OutDate']) : 'Not discharged') . '</p>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Attending Staff:</h6>';
        echo '<p>' . htmlspecialchars($ward['StaffName']) . '</p>';
        
        echo '<h6 class="font-weight-bold">Staff ID:</h6>';
        echo '<p>' . htmlspecialchars($ward['StaffID']) . '</p>';
        
        echo '<h6 class="font-weight-bold">Diagnosis ID:</h6>';
        echo '<p>' . htmlspecialchars($ward['DiagnosisID']) . '</p>';
        echo '</div>';
        
        echo '<div class="col-12 mt-3">';
        echo '<h6 class="font-weight-bold">Diagnosis:</h6>';
        echo '<p>' . htmlspecialchars($ward['DiagnosisDescription']) . '</p>';
        echo '</div>';
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-danger">Ward record not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>