<?php
session_start();
include 'config.php';

if (!isset($_GET['id'])) {
    header("Location: registerPatient.php");
    exit();
}

$patientId = $_GET['id'];
$editMode = isset($_GET['edit']);

$stmt = $conn->prepare("SELECT * FROM Patient WHERE PatientID = ?");
$stmt->bind_param("s", $patientId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Patient not found";
    header("Location: registerPatient.php");
    exit();
}

$patient = $result->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $editMode) {
    $name = htmlspecialchars($_POST['name']);
    $contact = htmlspecialchars($_POST['contact']);
    $email = htmlspecialchars($_POST['email']);
    $address = htmlspecialchars($_POST['address']);
    $nic = htmlspecialchars($_POST['nic']);
    $dob = htmlspecialchars($_POST['dob']);
    $gender = htmlspecialchars($_POST['gender']);
    $reason = htmlspecialchars($_POST['reason']);
    $guardianName = htmlspecialchars($_POST['guardian_name']);
    $guardianContact = htmlspecialchars($_POST['guardian_contact']);
    $guardianNic = htmlspecialchars($_POST['guardian_nic']);

    try {
        $updateSql = "UPDATE Patient SET
            Name = ?,
            ContactNumber = ?,
            Email = ?,
            Address = ?,
            NIC = ?,
            DOB = ?,
            Gender = ?,
            Reason = ?,
            GuardianName = ?,
            GuardianContactNumber = ?,
            GuardianNIC = ?
            WHERE PatientID = ?";

        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("ssssssssssss",
            $name,
            $contact,
            $email,
            $address,
            $nic,
            $dob,
            $gender,
            $reason,
            $guardianName,
            $guardianContact,
            $guardianNic,
            $patientId
        );

        if ($stmt->execute()) {
            $_SESSION['success'] = "Patient updated successfully!";
            header("Location: registerPatient.php");
            exit();
        } else {
            throw new Exception("Update failed: " . $stmt->error);
        }
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: getPatientDetails.php?id=$patientId&edit=1");
        exit();
    } finally {
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Details - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><?= $editMode ? 'Edit' : 'View' ?> Patient Details</h2>
            <a href="registerPatient.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>

        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form method="POST" action="getPatientDetails.php?id=<?= $patientId ?>&edit=1">
            <div class="row g-4">
                <!-- Personal Details Card -->
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="fas fa-user-circle me-2"></i>Personal Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Patient ID</label>
                                    <p class="form-control-plaintext"><?= $patient['PatientID'] ?></p>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Full Name</label>
                                    <?php if ($editMode): ?>
                                    <input type="text" class="form-control" name="name"
                                        value="<?= htmlspecialchars($patient['Name']) ?>" required>
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['Name']) ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Contact Number</label>
                                    <?php if ($editMode): ?>
                                    <input type="tel" class="form-control" name="contact" pattern="[0-9]{10}"
                                        value="<?= htmlspecialchars($patient['ContactNumber']) ?>" required>
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['ContactNumber']) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <?php if ($editMode): ?>
                                    <input type="email" class="form-control" name="email"
                                        value="<?= htmlspecialchars($patient['Email']) ?>" required>
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['Email']) ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-12">
                                    <label class="form-label">Address</label>
                                    <?php if ($editMode): ?>
                                    <textarea class="form-control" name="address" rows="2" required><?= 
                                            htmlspecialchars($patient['Address']) ?></textarea>
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['Address']) ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Medical Details Card -->
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="fas fa-file-medical me-2"></i>Medical Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Date of Birth</label>
                                    <?php if ($editMode): ?>
                                    <input type="date" class="form-control" name="dob"
                                        value="<?= htmlspecialchars($patient['DOB']) ?>" required>
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['DOB']) ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Gender</label>
                                    <?php if ($editMode): ?>
                                    <select class="form-select" name="gender" required>
                                        <option value="Male" <?= $patient['Gender'] == 'Male' ? 'selected' : '' ?>>Male
                                        </option>
                                        <option value="Female" <?= $patient['Gender'] == 'Female' ? 'selected' : '' ?>>
                                            Female</option>
                                        <option value="Other" <?= $patient['Gender'] == 'Other' ? 'selected' : '' ?>>
                                            Other</option>
                                    </select>
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['Gender']) ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-12">
                                    <label class="form-label">Reason for Visit</label>
                                    <?php if ($editMode): ?>
                                    <textarea class="form-control" name="reason" rows="2" required><?= 
                                            htmlspecialchars($patient['Reason']) ?></textarea>
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['Reason']) ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Guardian Information Card -->
                    <div class="card shadow-sm mt-4">
                        <div class="card-header bg-warning">
                            <h5 class="mb-0"><i class="fas fa-user-shield me-2"></i>Guardian Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Guardian Name</label>
                                    <?php if ($editMode): ?>
                                    <input type="text" class="form-control" name="guardian_name"
                                        value="<?= htmlspecialchars($patient['GuardianName']) ?>">
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['GuardianName']) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Guardian Contact</label>
                                    <?php if ($editMode): ?>
                                    <input type="tel" class="form-control" name="guardian_contact" pattern="[0-9]{10}"
                                        value="<?= htmlspecialchars($patient['GuardianContactNumber']) ?>">
                                    <?php else: ?>
                                    <p class="form-control-plaintext">
                                        <?= htmlspecialchars($patient['GuardianContactNumber']) ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Guardian NIC</label>
                                    <?php if ($editMode): ?>
                                    <input type="text" class="form-control" name="guardian_nic"
                                        pattern="\d{9}[Vv]|\d{12}"
                                        value="<?= htmlspecialchars($patient['GuardianNIC']) ?>">
                                    <?php else: ?>
                                    <p class="form-control-plaintext"><?= htmlspecialchars($patient['GuardianNIC']) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($editMode): ?>
            <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary px-5">
                    <i class="fas fa-save me-2"></i>Save Changes
                </button>
                <a href="getPatientDetails.php?id=<?= $patientId ?>" class="btn btn-outline-secondary px-5">
                    Cancel
                </a>
            </div>
            <?php else: ?>
            <div class="text-center mt-4">
                <a href="getPatientDetails.php?id=<?= $patientId ?>&edit=1" class="btn btn-warning px-5">
                    <i class="fas fa-edit me-2"></i>Edit Details
                </a>
            </div>
            <?php endif; ?>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
$conn->close();
?>