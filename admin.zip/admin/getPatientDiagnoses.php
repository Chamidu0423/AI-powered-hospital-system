<?php
include 'config.php';

if (isset($_GET['patientId'])) {
    $patientId = $_GET['patientId'];
    
    $sql = "SELECT DiagnosisID, Description FROM Diagnosis WHERE PatientID = ? ORDER BY DiagnosisID DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $patientId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo '<option value="">Select Diagnosis</option>';
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $description = substr($row["Description"], 0, 30) . (strlen($row["Description"]) > 30 ? "..." : "");
            echo '<option value="' . $row["DiagnosisID"] . '">' . $row["DiagnosisID"] . ' - ' . $description . '</option>';
        }
    } else {
        echo '<option value="" disabled>No diagnoses found for this patient</option>';
    }
    
    $stmt->close();
} else {
    echo '<option value="">Select Diagnosis</option>';
}
?>