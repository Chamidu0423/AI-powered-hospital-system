<?php
include '../admin/config.php';

// Process form submission for adding medication
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add') {
    // Get form data
    $medName = $_POST['medName'];
    $description = $_POST['description'];
    $stockInQty = $_POST['stockInQty'];
    $supplier = $_POST['supplier'];
    $price = $_POST['price'];
    $stockInDate = $_POST['stockInDate'];

    // Insert data into Pharmacy table
    $sql = "INSERT INTO Pharmacy (MedName, Description, StockInQty, StockInDate, BalanceQty, Supplier, Price) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssd", $medName, $description, $stockInQty, $stockInDate, $stockInQty, $supplier, $price);

    if ($stmt->execute()) {
        $success = "Medication added successfully!";
    } else {
        $error = "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Process form submission for dispensing medication
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'dispense') {
    // Get form data
    $medId = $_POST['medId'];
    $patientId = $_POST['patientId'];
    $qty = $_POST['qty'];
    $diagnosisId = $_POST['diagnosisId'];
    $date = $_POST['date'];

    // Get medication price
    $priceSql = "SELECT Price, BalanceQty FROM Pharmacy WHERE MedID = ?";
    $priceStmt = $conn->prepare($priceSql);
    $priceStmt->bind_param("s", $medId);
    $priceStmt->execute();
    $priceResult = $priceStmt->get_result();
    $priceRow = $priceResult->fetch_assoc();
    $unitPrice = $priceRow['Price'];
    $balanceQty = $priceRow['BalanceQty'];
    $totalBill = $unitPrice * $qty;

    // Check if enough stock is available
    if ($balanceQty < $qty) {
        $dispenseError = "Error: Not enough stock available. Current balance: " . $balanceQty;
    } else {
        // Begin transaction
        $conn->begin_transaction();

        try {
            // Insert data into PharmacyTransaction table
            $transactionSql = "INSERT INTO PharmacyTransaction (MedID, Qty, StockOut, PatientID, Date, UnitPrice, TotalBill, DiagnosisID) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            $transactionStmt = $conn->prepare($transactionSql);
            $transactionStmt->bind_param("siissdds", $medId, $qty, $qty, $patientId, $date, $unitPrice, $totalBill, $diagnosisId);
            $transactionStmt->execute();

            // Update balance quantity in Pharmacy table
            $newBalance = $balanceQty - $qty;
            $updateSql = "UPDATE Pharmacy SET BalanceQty = ? WHERE MedID = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("is", $newBalance, $medId);
            $updateStmt->execute();

            // Commit transaction
            $conn->commit();

            $dispenseSuccess = "Medication dispensed successfully!";
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $dispenseError = "Error: " . $e->getMessage();
        }
    }
}

// Search functionality for inventory
$searchTerm = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search'];

    $searchSql = "SELECT * FROM Pharmacy WHERE MedID LIKE ? OR MedName LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("ss", $searchParam, $searchParam);
    $stmt->execute();

    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }

    $stmt->close();
}

// Get low stock medications
$lowStockSql = "SELECT * FROM Pharmacy WHERE BalanceQty <= 10 ORDER BY BalanceQty ASC";
$lowStockResult = $conn->query($lowStockSql);
$lowStockCount = $lowStockResult->num_rows;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Inventory - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        #current-date-time {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            background: #f5f5f5;
            padding: 5px 10px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        #theme-icon {
            font-size: 20px;
            color: #ffcc00;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
        }

        #theme-icon:hover {
            transform: scale(1.2);
            color: #ffa500;
        }

        .h2 {
            text-align: center;
            display: block;
            margin: 0 auto;
        }

        .sidebar-icon {
            font-size: 22px;
            color: #007bff;
        }

        .sidebar-text {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div
                class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Pharmacy Inventory</h1>

                <div class="d-flex align-items-center">
                    <i id="theme-icon" class="fas"></i>
                </div>
            </div>

            <script>
                function updateDateTimeAndTheme() {
                    // Get the current date and time
                    const currentDate = new Date();
                    let hours = currentDate.getHours();
                    let minutes = currentDate.getMinutes();
                    let day = currentDate.getDate();
                    let month = currentDate.getMonth() + 1; // Months are 0-indexed
                    let year = currentDate.getFullYear();

                    // Day of the week
                    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    const dayOfWeek = daysOfWeek[currentDate.getDay()];

                    minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if minutes are less than 10

                    const dateString = `${month}/${day}/${year}`;
                    const timeString = `${hours}:${minutes}`;

                    document.getElementById('current-date-time').textContent =
                        `${dayOfWeek}, ${dateString} - ${timeString}`;

                    const themeIcon = document.getElementById('theme-icon');
                    if (hours >= 6 && hours < 18) {
                        // Day time (6 AM to 6 PM)
                        themeIcon.classList.remove('fa-moon');
                        themeIcon.classList.add('fa-sun');
                        themeIcon.style.color = 'orange'; 
                    } else {
                        // Night time (6 PM to 6 AM)
                        themeIcon.classList.remove('fa-sun');
                        themeIcon.classList.add('fa-moon');
                        themeIcon.style.color = 'blue'; 
                    }
                }

                // Update time, date, and theme every minute
                setInterval(updateDateTimeAndTheme, 60000);

                updateDateTimeAndTheme();
            </script>

            <!-- Nav Tabs -->
            <ul class="nav nav-tabs mb-4" id="pharmacyTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="dispense-tab" data-bs-toggle="tab" data-bs-target="#dispense"
                        type="button" role="tab" aria-controls="dispense" aria-selected="true">
                        <i class="fas fa-prescription-bottle-alt me-2"></i>Dispense Medication
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="transactions-tab" data-bs-toggle="tab" data-bs-target="#transactions"
                        type="button" role="tab" aria-controls="transactions" aria-selected="false">
                        <i class="fas fa-exchange-alt me-2"></i>Transactions
                    </button>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content" id="pharmacyTabsContent">
                <!-- Dispense Medication Tab -->
                <div class="tab-pane fade show active" id="dispense" role="tabpanel" aria-labelledby="dispense-tab">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Dispense Medication</h6>
                        </div>
                        <div class="card-body">
                            <?php if (isset($dispenseSuccess)): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo $dispenseSuccess; ?>
                                </div>
                            <?php endif; ?>

                            <?php if (isset($dispenseError)): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $dispenseError; ?>
                                </div>
                            <?php endif; ?>

                            <form method="POST" action="">
                                <input type="hidden" name="action" value="dispense">

                                <div class="mb-3">
                                    <label for="patientId" class="form-label">Patient</label>
                                    <select class="form-select" id="patientId" name="patientId" required>
                                        <option value="">Select Patient</option>
                                        <?php
                                        $patientSql = "SELECT PatientID, Name FROM Patient ORDER BY Name";
                                        $patientResult = $conn->query($patientSql);

                                        if ($patientResult->num_rows > 0) {
                                            while ($row = $patientResult->fetch_assoc()) {
                                                echo "<option value='" . $row["PatientID"] . "'>" . $row["Name"] . " (" . $row["PatientID"] . ")</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="medId" class="form-label">Medication</label>
                                    <select class="form-select" id="medId" name="medId" required>
                                        <option value="">Select Medication</option>
                                        <?php
                                        $medSql = "SELECT MedID, MedName, BalanceQty FROM Pharmacy WHERE BalanceQty > 0 ORDER BY MedName";
                                        $medResult = $conn->query($medSql);

                                        if ($medResult->num_rows > 0) {
                                            while ($row = $medResult->fetch_assoc()) {
                                                echo "<option value='" . $row["MedID"] . "'>" . $row["MedName"] . " (Stock: " . $row["BalanceQty"] . ")</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="diagnosisId" class="form-label">Diagnosis</label>
                                    <select class="form-select" id="diagnosisId" name="diagnosisId" required>
                                        <option value="">Select Diagnosis</option>
                                        <?php
                                        $diagnosisSql = "SELECT d.DiagnosisID, d.Description, p.Name 
                                                           FROM Diagnosis d 
                                                           JOIN Patient p ON d.PatientID = p.PatientID 
                                                           ORDER BY d.DiagnosisID DESC";
                                        $diagnosisResult = $conn->query($diagnosisSql);

                                        if ($diagnosisResult->num_rows > 0) {
                                            while ($row = $diagnosisResult->fetch_assoc()) {
                                                $description = substr($row["Description"], 0, 30) . (strlen($row["Description"]) > 30 ? "..." : "");
                                                echo "<option value='" . $row["DiagnosisID"] . "'>" . $row["DiagnosisID"] . " - " . $description . "</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="qty" class="form-label">Quantity</label>
                                        <input type="number" class="form-control" id="qty" name="qty" min="1" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="date" class="form-label">Date</label>
                                        <input type="date" class="form-control" id="date" name="date"
                                            value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                </div>

                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Dispense Medication</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Transactions Tab -->
                <div class="tab-pane fade" id="transactions" role="tabpanel" aria-labelledby="transactions-tab">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">Recent Transactions</h6>
                            <button class="btn btn-sm btn-outline-primary" id="printTransactions">
                                <i class="fas fa-print me-1"></i> Print Transactions
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Medication</th>
                                            <th>Patient</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                            <th>Date</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $transactionSql = "SELECT t.*, p.Name as PatientName, m.MedName 
                                                              FROM PharmacyTransaction t 
                                                              JOIN Patient p ON t.PatientID = p.PatientID 
                                                              JOIN Pharmacy m ON t.MedID = m.MedID 
                                                              ORDER BY t.Date DESC, t.TransactionID DESC LIMIT 20";
                                        $transactionResult = $conn->query($transactionSql);

                                        if ($transactionResult->num_rows > 0) {
                                            while ($row = $transactionResult->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["TransactionID"] . "</td>";
                                                echo "<td>" . $row["MedName"] . "</td>";
                                                echo "<td>" . $row["PatientName"] . "</td>";
                                                echo "<td>" . $row["Qty"] . "</td>";
                                                echo "<td>Rs." . number_format($row["TotalBill"], 2) . "</td>";
                                                echo "<td>" . $row["Date"] . "</td>";
                                                echo "<td>
                                                            <button class='btn btn-sm btn-info view-transaction' data-id='" . $row["TransactionID"] . "'>
                                                                <i class='fas fa-eye'></i>
                                                            </button>
                                                            <button class='btn btn-sm btn-primary print-receipt' data-id='" . $row["TransactionID"] . "'>
                                                                <i class='fas fa-print'></i>
                                                            </button>
                                                            <button class='btn btn-sm btn-danger delete-transaction' data-id='" . $row["TransactionID"] . "'>
                                                            <i class='fas fa-trash'></i>
                                                        </button>
                                                        </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='7' class='text-center'>No transactions found</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            // Patient selection changes diagnosis options
            $('#patientId').change(function () {
                var patientId = $(this).val();

                if (patientId) {
                    // AJAX request to get diagnoses for this patient
                    $.ajax({
                        url: 'getPatientDiagnoses.php',
                        type: 'GET',
                        data: {
                            patientId: patientId
                        },
                        success: function (response) {
                            $('#diagnosisId').html(response);
                        }
                    });
                }
            });

            // View medication details
            $('.view-med').click(function () {
                var medId = $(this).data('id');

                // AJAX request to get medication details
                $.ajax({
                    url: 'getMedicationDetails.php',
                    type: 'GET',
                    data: {
                        id: medId
                    },
                    success: function (response) {
                        $('#medicationDetailsContent').html(response);
                        $('#medicationDetailsModal').modal('show');
                    },
                    error: function () {
                        alert('Error fetching medication details');
                    }
                });
            });

            // Restock medication
            $('.restock-med').click(function () {
                var medId = $(this).data('id');
                var medName = $(this).data('name');

                $('#restockMedId').val(medId);
                $('#restockMedName').val(medName);
                $('#restockModal').modal('show');
            });

            // Confirm restock
            $('#confirmRestock').click(function () {
                var medId = $('#restockMedId').val();
                var qty = $('#restockQty').val();
                var date = $('#restockDate').val();

                // AJAX request to restock medication
                $.ajax({
                    url: 'restockMedication.php',
                    type: 'POST',
                    data: {
                        medId: medId,
                        qty: qty,
                        date: date
                    },
                    success: function (response) {
                        $('#restockModal').modal('hide');
                        // Reload the page to show updated data
                        location.reload();
                    },
                    error: function () {
                        alert('Error restocking medication');
                    }
                });
            });

            // View transaction details
            $('.view-transaction').click(function () {
                var transactionId = $(this).data('id');

                // AJAX request to get transaction details
                $.ajax({
                    url: 'getTransactionDetails.php',
                    type: 'GET',
                    data: {
                        id: transactionId
                    },
                    success: function (response) {
                        $('#transactionDetailsContent').html(response);
                        $('#transactionDetailsModal').modal('show');
                    },
                    error: function () {
                        alert('Error fetching transaction details');
                    }
                });
            });

            // Print receipt
            $('.print-receipt').click(function () {
                var transactionId = $(this).data('id');
                window.open('printReceipt.php?id=' + transactionId, '_blank');
            });

            // Print from modal
            $('#printReceiptBtn').click(function () {
                var transactionId = $('#transactionDetailsContent').data('transaction-id');
                if (transactionId) {
                    window.open('printReceipt.php?id=' + transactionId, '_blank');
                }
            });

            // Print inventory
            $('#printInventory').click(function () {
                window.open('printInventory.php', '_blank');
            });

            // Print transactions
            $('#printTransactions').click(function () {
                window.open('printTransactions.php', '_blank');
            });
        });

        // Delete recorded transaction
        document.querySelectorAll('.delete-transaction').forEach(button => {
            button.addEventListener('click', function () {
                const transactionId = this.getAttribute('data-id');

                // Confirm the deletion
                if (confirm("Are you sure you want to delete this transaction?")) {
                    // Send an AJAX request to delete the transaction
                    fetch('deleteTransaction.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            TransactionID: transactionId
                        }),
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Optionally, remove the row from the table
                                this.closest('tr').remove();
                                alert('Transaction deleted successfully.');
                            } else {
                                alert('Error deleting the transaction.');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('Error occurred while deleting.');
                        });
                }
            });
        });
    </script>
</body>

</html>