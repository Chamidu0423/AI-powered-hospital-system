<?php
session_start();
include 'config.php';

$success = null;
$error = null;

if (isset($_GET['success']) && $_GET['success'] == 1) {
    $success = "Patient registered successfully!";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'] ?? '';
    $contactNumber = $_POST['contactNumber'] ?? '';
    $address = $_POST['address'] ?? '';
    $nic = $_POST['nic'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $guardianName = $_POST['guardianName'] ?? null;
    $guardianNic = $_POST['guardianNic'] ?? null;
    $guardianContactNumber = $_POST['guardianContactNumber'] ?? null;
    $reason = $_POST['reason'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $email = $_POST['email'] ?? '';

    try {
        $sql = "INSERT INTO Patient (Name, ContactNumber, Address, NIC, DOB, GuardianName, 
                GuardianNIC, GuardianContactNumber, Reason, Gender, Email)  
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }

        $stmt->bind_param(
            "sssssssssss",
            $name,
            $contactNumber,
            $address,
            $nic,
            $dob,
            $guardianName,
            $guardianNic,
            $guardianContactNumber,
            $reason,
            $gender,
            $email
        );

        if ($stmt->execute()) {
            header("Location: registerPatient.php?success=1");
            exit();
        } else {
            $error = "Error: " . $stmt->error;
        }

        $stmt->close();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}


$searchTerm = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = trim($_GET['search']);

    $searchSql = "SELECT * FROM Patient WHERE PatientID LIKE ? OR Name LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("ss", $searchParam, $searchParam);
    $stmt->execute();

    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }

    $stmt->close();
}

$recentPatients = [];
if (empty($searchTerm)) {
    $recentPatientsSql = "SELECT PatientID, Name, ContactNumber FROM Patient ORDER BY RegistrationDate DESC LIMIT 10";
    $recentPatientsResult = $conn->query($recentPatientsSql);
    if ($recentPatientsResult->num_rows > 0) {
        while ($row = $recentPatientsResult->fetch_assoc()) {
            $recentPatients[] = $row;
        }
    }
}

$searchTerm = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = trim($_GET['search']);

    $searchSql = "SELECT * FROM Patient WHERE PatientID LIKE ? OR Name LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("ss", $searchParam, $searchParam);
    $stmt->execute();

    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }

    $stmt->close();
}

// Fetch recent patients if no search term
$recentPatients = [];
if (empty($searchTerm)) {
    $recentPatientsSql = "SELECT PatientID, Name, ContactNumber FROM Patient ORDER BY RegistrationDate DESC LIMIT 10";
    $recentPatientsResult = $conn->query($recentPatientsSql);
    if ($recentPatientsResult->num_rows > 0) {
        while ($row = $recentPatientsResult->fetch_assoc()) {
            $recentPatients[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Patient - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <link rel="stylesheet" href="styles.css">
    <style>
        #current-date-time {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            background: #f5f5f5;
            padding: 5px 10px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        #theme-icon {
            font-size: 20px;
            color: #ffcc00;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
        }

        #theme-icon:hover {
            transform: scale(1.2);
            color: #ffa500;
        }

        .h2 {
            text-align: center;
            display: block;
            margin: 0 auto;
        }

        .sidebar-icon {
            font-size: 22px;
            color: #007bff;
        }

        .sidebar-text {
            font-size: 18px;
            font-weight: bold;
        }
    </style>

</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link " href="index.php">
                                <i class="fas fa-chart-line me-2 sidebar-icon"></i>
                                <span class="sidebar-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">


                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Register Patient</h1>
                    <div class="d-flex align-items-center">
                        <!-- Date, Time, and Day Display -->
                        <span id="current-date-time" class="me-3"></span>
                        <!-- Day/Night Icon -->
                        <i id="theme-icon" class="fas"></i>
                    </div>
                </div>

                <script>
                    function updateDateTimeAndTheme() {
                        // Get the current date and time
                        const currentDate = new Date();
                        let hours = currentDate.getHours();
                        let minutes = currentDate.getMinutes();
                        let day = currentDate.getDate();
                        let month = currentDate.getMonth() + 1; // Months are 0-indexed
                        let year = currentDate.getFullYear();

                        // Day of the week
                        const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                        const dayOfWeek = daysOfWeek[currentDate.getDay()];

                        minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if minutes are less than 10

                        const dateString = `${month}/${day}/${year}`;
                        const timeString = `${hours}:${minutes}`;

                        // Display date, time, and day of the week
                        document.getElementById('current-date-time').textContent =
                            `${dayOfWeek}, ${dateString} - ${timeString}`;

                        // Change the icon and theme based on the time
                        const themeIcon = document.getElementById('theme-icon');
                        if (hours >= 6 && hours < 18) {
                            // Day time (6 AM to 6 PM)
                            themeIcon.classList.remove('fa-moon');
                            themeIcon.classList.add('fa-sun');
                            themeIcon.style.color = 'orange'; // Day icon color
                        } else {
                            // Night time (6 PM to 6 AM)
                            themeIcon.classList.remove('fa-sun');
                            themeIcon.classList.add('fa-moon');
                            themeIcon.style.color = 'blue'; // Night icon color
                        }
                    }

                    // Update time, date, and theme every minute
                    setInterval(updateDateTimeAndTheme, 60000);

                    // Initial call to set the date, time, and theme on page load
                    updateDateTimeAndTheme();
                </script>

                <script>
                    function goBack() {
                        window.history.back();
                    }
                </script>

                <!-- Notifications -->
                <div class="notification-container"
                    style="position: fixed; top: 60px; left: 50%; transform: translateX(-50%); z-index: 9999; width: 300px;">
                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?= htmlspecialchars($success) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?= htmlspecialchars($error) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <!-- Registration Form -->
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Patient Registration Form</h6>
                            </div>
                            <div class="card-body">
                                <?php if (isset($success)): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo $success; ?>
                                    </div>
                                <?php endif; ?>

                                <?php if (isset($error)): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo $error; ?>
                                    </div>
                                <?php endif; ?>

                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">Full Name</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                            placeholder="Enter full name" required>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="contactNumber" class="form-label">Contact Number</label>
                                            <input type="text" class="form-control" id="contactNumber"
                                                name="contactNumber"
                                                placeholder="Enter contact number (e.g., 0771234567)" pattern="^\d{10}$"
                                                title="Enter a valid 10-digit contact number" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="nic" class="form-label">NIC</label>
                                            <input type="text" class="form-control" id="nic" name="nic"
                                                placeholder="Enter 12-digit NIC (e.g., 200112104148) or 9-digit NIC with V (e.g., 199212345V)"
                                                pattern="^\d{12}$|^\d{9}[Vv]$"
                                                title="NIC should be either 12 digits (e.g., 200112104148) or 9 digits followed by 'V' or 'v' (e.g., 199212345V)"
                                                required>
                                        </div>
                                       
                                    </div>

                                    <div class="mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <textarea class="form-control" id="address" name="address" rows="2"
                                            placeholder="Enter your address" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                            placeholder="Enter your email" required>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="dob" class="form-label">Date of Birth</label>
                                            <input type="date" class="form-control" id="dob" name="dob" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="gender" class="form-label">Gender</label>
                                            <select class="form-select" id="gender" name="gender" required>
                                                <option value="">Select Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                                <option value="Other">Other</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="reason" class="form-label">Reason for Visit</label>
                                        <textarea class="form-control" id="reason" name="reason" rows="2"
                                            placeholder="Enter reason for visit" required></textarea>
                                    </div>

                                    <hr>
                                    <h6 class="mb-3">Guardian Information (Optional)</h6>

                                    <div class="mb-3">
                                        <label for="guardianName" class="form-label">Guardian Name</label>
                                        <input type="text" class="form-control" id="guardianName" name="guardianName"
                                            placeholder="Enter guardian's name">
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="guardianNic" class="form-label">Guardian NIC</label>
                                            <input type="text" class="form-control" id="guardianNic" name="guardianNic"
                                                placeholder="Enter guardian NIC (12 digits or 9 digits with V)">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="guardianContactNumber" class="form-label">Guardian
                                                Contact</label>
                                            <input type="text" class="form-control" id="guardianContactNumber"
                                                name="guardianContactNumber"
                                                placeholder="Enter guardian's contact number">
                                        </div>
                                    </div>

                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">Register Patient</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                    <!-- Search and Results -->
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Search Patients</h6>
                            </div>
                            <div class="card-body">
                                <form method="GET" action="">
                                    <div class="search-container mb-4">
                                        <input type="text" class="form-control" name="search"
                                            placeholder="Search by ID or Name" value="<?php echo $searchTerm; ?>">
                                        <button type="submit" class="btn btn-primary search-icon">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Contact</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($searchResults) && empty($searchTerm)): ?>
                                                <?php
                                                $recentPatientsSql = "SELECT PatientID, Name, ContactNumber FROM Patient ORDER BY RegistrationDate DESC LIMIT 10";
                                                $recentPatientsResult = $conn->query($recentPatientsSql);

                                                if ($recentPatientsResult->num_rows > 0) {
                                                    while ($row = $recentPatientsResult->fetch_assoc()) {
                                                        echo "<tr>";
                                                        echo "<td>" . $row["PatientID"] . "</td>";
                                                        echo "<td>" . $row["Name"] . "</td>";
                                                        echo "<td>" . $row["ContactNumber"] . "</td>";
                                                        // In both recent patients and search results sections, fix the TD element:
                                                        echo "<td>
                                            <button class='btn btn-sm btn-info view-patient' data-id='" . $row["PatientID"] . "'>
                                            <i class='fas fa-eye'></i>
                                                                            </button>
                                                        <button class='btn btn-sm btn-warning edit-patient' data-id='" . $row["PatientID"] . "'>
                                                                      <i class='fas fa-edit'></i>
                                    </button>
                                    <button class='btn btn-sm btn-danger delete-patient' data-id='" . $row["PatientID"] . "'>
                                <i class='fas fa-trash'></i>
                                                    </button>
                                        </td>";
                                                        echo "</tr>";
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='4' class='text-center'>No patients found</td></tr>";
                                                }
                                                ?>
                                            <?php elseif (!empty($searchResults)): ?>
                                                <?php foreach ($searchResults as $patient): ?>
                                                    <tr>
                                                        <td><?php echo $patient["PatientID"]; ?></td>
                                                        <td><?php echo $patient["Name"]; ?></td>
                                                        <td><?php echo $patient["ContactNumber"]; ?></td>
                                                        <td>
                                                            <button class='btn btn-sm btn-info view-patient'
                                                                data-id='<?php echo $patient["PatientID"]; ?>'>
                                                                <i class='fas fa-eye'></i>
                                                            </button>
                                                            <button class='btn btn-sm btn-danger delete-patient'
                                                                data-id='<?php echo $patient["PatientID"]; ?>'>
                                                                <i class='fas fa-trash'></i>
                                                            </button>
                                                        </td>

                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="4" class="text-center">No results found for
                                                        "<?php echo $searchTerm; ?>"</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Patient Details Modal -->
                        <div class="modal fade" id="patientDetailsModal" tabindex="-1"
                            aria-labelledby="patientDetailsModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="patientDetailsModalLabel">Patient Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body" id="patientDetailsContent">
                                        <!-- Patient details will be loaded here -->
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            // Initialize tooltips
            $('[data-bs-toggle="tooltip"]').tooltip();

            // View Patient Details
            $(document).on('click', '.view-patient', function () {
                const patientId = $(this).data('id');
                loadPatientDetails(patientId);
            });

            // Edit Patient
            $(document).on('click', '.edit-patient', function () {
                const patientId = $(this).data('id');
                loadPatientDetails(patientId, true);
            });

            // Delete Patient
            $(document).on('click', '.delete-patient', function () {
                const patientId = $(this).data('id');
                const $row = $(this).closest('tr');
                const isSearch = $('[name="search"]').val().length > 0;

                if (confirm("Are you sure you want to permanently delete this patient?")) {
                    $.ajax({
                        url: 'deletePatient.php',
                        type: 'POST',
                        data: {
                            id: patientId
                        },
                        beforeSend: () => $row.css('opacity', '0.6'),
                        success: (response) => {
                            if (response.trim() === "success") {
                                $row.fadeOut(400, () => {
                                    $row.remove();
                                    showNotification('Patient deleted successfully',
                                        'success');
                                    refreshPatientList(isSearch);
                                });
                            } else {
                                showNotification(response, 'error');
                                $row.css('opacity', '1');
                            }
                        },
                        error: (xhr) => {
                            showNotification(`Error: ${xhr.statusText}`, 'error');
                            $row.css('opacity', '1');
                        }
                    });
                }
            });

            document.getElementById("patientForm").addEventListener("submit", function (e) {
                e.preventDefault();

                let formData = new FormData(this);
                fetch(window.location.href, {
                    method: "POST",
                    body: formData,
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === "success") {
                            alert("Patient updated successfully!");
                            window.location.reload(); // Refresh the page
                        } else {
                            alert("Error: " + data.message);
                        }
                    })
                    .catch(error => console.error("Error:", error));
            });


            function loadPatientDetails(patientId, editMode = false) {
                const url = `getPatientDetails.php?id=${patientId}${editMode ? '&edit=1' : ''}`;

                $.ajax({
                    url: url,
                    type: 'GET',
                    beforeSend: () => {
                        $('#patientDetailsContent').html(`
    <div class="text-center py-4">
        <div class="spinner-border text-primary"></div>
    </div>
`);
                    },
                    success: (response) => {
                        $('#patientDetailsContent').html(response);
                        $('#patientDetailsModal').modal('show');
                    },
                    error: (xhr) => {
                        $('#patientDetailsContent').html(`
    <div class="alert alert-danger">
        Error loading details: ${xhr.statusText}
    </div>
`);
                        $('#patientDetailsModal').modal('show');
                    }
                });
            }

            function refreshPatientList(isSearch) {
                if (isSearch) {
                    $('[name="search"]').closest('form').submit();
                } else {
                    $.ajax({
                        url: 'registerPatient.php',
                        data: {
                            refresh: true
                        },
                        success: (response) => {
                            const $newContent = $(response).find('.table-responsive').html();
                            $('.table-responsive').html($newContent);
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    });
                }
            }

            // Notification System
            function showNotification(message, type = 'success') {
                const alertType = type === 'success' ? 'alert-success' : 'alert-danger';
                const $alert = $(`
<div class="alert ${alertType} alert-dismissible fade show" role="alert">
${message}
<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
`);

                $('.notification-container')
                    .html('')
                    .append($alert)
                    .find('.alert')
                    .delay(500)
                    .fadeOut(400, () => $(this).alert('close'));
            }
        });


        // Update the loadPatientDetails function
        function loadPatientDetails(patientId, editMode = false) {
            const url = `getPatientDetails.php?id=${patientId}${editMode ? '&edit=1' : ''}`;

            // Load content in modal
            $('#patientDetailsContent').load(url, function (response, status) {
                if (status === "success") {
                    $('#patientDetailsModal').modal('show');

                    // Handle form submission within modal
                    $('#patientForm').off('submit').on('submit', function (e) {
                        e.preventDefault();
                        const formData = $(this).serialize();

                        $.ajax({
                            type: "POST",
                            url: "updatePatient.php",
                            data: formData,
                            success: function (response) {
                                $('#patientDetailsModal').modal('hide');
                                location.reload(); // Refresh patient list
                            },
                            error: function (xhr) {
                                alert('Error: ' + xhr.statusText);
                            }
                        });
                    });
                }
            });
        }
    </script>
</body>

</html>