<?php
include 'config.php';

if (isset($_GET['id'])) {
    $diagnosisId = $_GET['id'];
    
    $sql = "SELECT d.*, p.Name as PatientName, p.PatientID, p.ContactNumber, p.NIC, p.Gender, p.DOB,
                  a.Date as AppointmentDate, a.Time as AppointmentTime, s.Name as DoctorName, s.Position 
           FROM Diagnosis d 
           JOIN Patient p ON d.PatientID = p.PatientID 
           LEFT JOIN Appointment a ON d.AppointmentID = a.AppointmentID 
           LEFT JOIN Staff s ON a.StaffID = s.StaffID 
           WHERE d.DiagnosisID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $diagnosisId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $diagnosis = $result->fetch_assoc();
        
        // Calculate age from DOB
        $dob = new DateTime($diagnosis['DOB']);
        $now = new DateTime();
        $age = $now->diff($dob)->y;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diagnosis Report - <?php echo $diagnosis['DiagnosisID']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .report-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .report-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .hospital-name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .report-subtitle {
            font-size: 16px;
            color: #555;
        }
        .patient-info {
            margin-bottom: 20px;
        }
        .diagnosis-details {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
        }
        .signature {
            margin-top: 50px;
            border-top: 1px solid #333;
            width: 200px;
            text-align: center;
            padding-top: 5px;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print mb-3">
            <button onclick="window.print()" class="btn btn-primary">Print Report</button>
            <button onclick="window.close()" class="btn btn-secondary">Close</button>
        </div>
        
        <div class="report-header">
            <div class="report-title">Medical Diagnosis Report</div>
            <div class="hospital-name">VirtualPuls Hospital</div>
            <div class="report-subtitle">Excellence in Healthcare</div>
        </div>
        
        <div class="row">
            <div class="col-md-6 patient-info">
                <h5>Patient Information</h5>
                <table class="table table-bordered">
                    <tr>
                        <th>Patient Name</th>
                        <td><?php echo $diagnosis['PatientName']; ?></td>
                    </tr>
                    <tr>
                        <th>Patient ID</th>
                        <td><?php echo $diagnosis['PatientID']; ?></td>
                    </tr>
                    <tr>
                        <th>NIC</th>
                        <td><?php echo $diagnosis['NIC']; ?></td>
                    </tr>
                    <tr>
                        <th>Gender</th>
                        <td><?php echo $diagnosis['Gender']; ?></td>
                    </tr>
                    <tr>
                        <th>Age</th>
                        <td><?php echo $age; ?> years</td>
                    </tr>
                    <tr>
                        <th>Contact</th>
                        <td><?php echo $diagnosis['ContactNumber']; ?></td>
                    </tr>
                </table>
            </div>
            
            <div class="col-md-6">
                <h5>Diagnosis Information</h5>
                <table class="table table-bordered">
                    <tr>
                        <th>Diagnosis ID</th>
                        <td><?php echo $diagnosis['DiagnosisID']; ?></td>
                    </tr>
                    <?php if ($diagnosis['AppointmentDate']): ?>
                    <tr>
                        <th>Appointment Date</th>
                        <td><?php echo $diagnosis['AppointmentDate']; ?></td>
                    </tr>
                    <tr>
                        <th>Appointment Time</th>
                        <td><?php echo date('h:i A', strtotime($diagnosis['AppointmentTime'])); ?></td>
                    </tr>
                    <tr>
                        <th>Doctor</th>
                        <td><?php echo $diagnosis['DoctorName']; ?> (<?php echo $diagnosis['Position']; ?>)</td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th>Status</th>
                        <td><?php echo $diagnosis['Status']; ?></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <h5>Diagnosis</h5>
                <div class="diagnosis-details">
                    <?php echo nl2br($diagnosis['Description']); ?>
                </div>
                
                <?php if (!empty($diagnosis['Medicine'])): ?>
                <h5 class="mt-4">Prescribed Medication</h5>
                <div class="diagnosis-details">
                    <?php echo nl2br($diagnosis['Medicine']); ?>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($diagnosis['TestTitle'])): ?>
                <h5 class="mt-4">Recommended Lab Tests</h5>
                <div class="diagnosis-details">
                    <?php echo $diagnosis['TestTitle']; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row mt-5">
            <div class="col-6">
                <div class="signature">
                    Doctor's Signature
                </div>
            </div>
            <div class="col-6 text-end">
                <div class="signature" style="margin-left: auto;">
                    Patient's Signature
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>This is a computer-generated report and does not require a physical signature.</p>
            <p>VirtualPuls Hospital - <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
    </div>
</body>
</html>
<?php
    } else {
        echo '<div class="alert alert-danger">Diagnosis record not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>