<?php
include 'config.php';

$searchTerm = '';
$position = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search'];
    $position = isset($_GET['position']) ? $_GET['position'] : '';
    
    $searchSql = "SELECT * FROM Staff WHERE (StaffID LIKE ? OR Name LIKE ?)";
    
    if (!empty($position)) {
        $searchSql .= " AND Position = ?";
        $stmt = $conn->prepare($searchSql);
        $searchParam = "%" . $searchTerm . "%";
        $stmt->bind_param("sss", $searchParam, $searchParam, $position);
    } else {
        $stmt = $conn->prepare($searchSql);
        $searchParam = "%" . $searchTerm . "%";
        $stmt->bind_param("ss", $searchParam, $searchParam);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
    
    $stmt->close();
} elseif (isset($_GET['position']) && !empty($_GET['position'])) {
    $position = $_GET['position'];
    
    $positionSql = "SELECT * FROM Staff WHERE Position = ?";
    $stmt = $conn->prepare($positionSql);
    $stmt->bind_param("s", $position);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
    
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #current-date-time {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        background: #f5f5f5;
        padding: 5px 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    #theme-icon {
        font-size: 20px;
        color: #ffcc00;
        cursor: pointer;
        transition: transform 0.3s ease, color 0.3s ease;
    }

    #theme-icon:hover {
        transform: scale(1.2);
        color: #ffa500;
    }

    .h2 {
        text-align: center;
        display: block;
        margin: 0 auto;
    }

    .sidebar-icon {
        font-size: 22px;
        color: #007bff;
    }

    .sidebar-text {
        font-size: 18px;
        font-weight: bold;
    }

    .icon-size {
        width: 50px;
        height: 50px;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link " href="index.php">
                                <i class="fas fa-chart-line me-2 sidebar-icon"></i>
                                <span class="sidebar-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>

                    </ul>
                </div>
            </div>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Staff Management</h1>
                    <div class="d-flex align-items-center">
                        <span id="current-date-time" class="me-3"></span>
                        <i id="theme-icon" class="fas"></i>
                    </div>
                </div>

                <script>
                function updateDateTimeAndTheme() {
                    const currentDate = new Date();
                    let hours = currentDate.getHours();
                    let minutes = currentDate.getMinutes();
                    let day = currentDate.getDate();
                    let month = currentDate.getMonth() + 1; 
                    let year = currentDate.getFullYear();

                    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    const dayOfWeek = daysOfWeek[currentDate.getDay()];

                    minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if minutes are less than 10

                    const dateString = `${month}/${day}/${year}`;
                    const timeString = `${hours}:${minutes}`;

                    document.getElementById('current-date-time').textContent =
                        `${dayOfWeek}, ${dateString} - ${timeString}`;

                    const themeIcon = document.getElementById('theme-icon');
                    if (hours >= 6 && hours < 18) {
                        themeIcon.classList.remove('fa-moon');
                        themeIcon.classList.add('fa-sun');
                        themeIcon.style.color = 'orange'; // Day icon color
                    } else {
                        themeIcon.classList.remove('fa-sun');
                        themeIcon.classList.add('fa-moon');
                        themeIcon.style.color = 'blue'; // Night icon color
                    }
                }

                setInterval(updateDateTimeAndTheme, 60000);

                updateDateTimeAndTheme();
                </script>
                <!-- Quick Access Buttons -->
                <div class="row mb-4">

                    <div class="col-md-3 mb-3">
                        <a href="registerDoctor.php"
                            class="btn btn-primary btn-block py-3 w-100 d-flex align-items-center justify-content-center text-white fw-bold"
                            style="font-size: 1.2rem;">
                            <img src="./assets/icons/doctor.png" alt="Doctor Icon" class="me-3 icon-size"> Register
                            Doctor
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="registerNurse.php"
                            class="btn btn-success btn-block py-3 w-100 d-flex align-items-center justify-content-center text-white fw-bold"
                            style="font-size: 1.2rem;">
                            <img src="./assets/icons/nurse.png" alt="Nurse Icon" class="me-3 icon-size"> Register Nurse
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="registerLaboratorist.php"
                            class="btn btn-danger btn-block py-3 w-100 d-flex align-items-center justify-content-center text-white fw-bold"
                            style="font-size: 1.2rem;">
                            <img src="./assets/icons/attender.png" alt="Laboratorist Icon" class="me-3 icon-size">
                            Register Laboratorist
                        </a>
                    </div>

                    <div class="col-md-3 mb-3">
                        <a href="registerPharmacist.php"
                            class="btn btn-dark btn-block py-3 w-100 d-flex align-items-center justify-content-center text-white fw-bold"
                            style="font-size: 1.2rem;">
                            <img src="./assets/icons/pharmacist.png" alt="Pharmacist Icon" class="me-3 icon-size">
                            Register Pharmacist
                        </a>
                    </div>

                    <div class="col-md-3 mb-3">
                        <a href="registerAssistance.php"
                            class="btn btn-info btn-block py-3 w-100 d-flex align-items-center justify-content-center text-white fw-bold"
                            style="font-size: 1.2rem;">
                            <img src="./assets/icons/assistance.png" alt="Assistant Icon" class="me-3 icon-size">
                            Register Assistant
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="registerSecurity.php"
                            class="btn btn-secondary btn-block py-3 w-100 d-flex align-items-center justify-content-center text-white fw-bold"
                            style="font-size: 1.2rem;">
                            <img src="./assets/icons/security.png" alt="Security Icon" class="me-3 icon-size"> Register
                            Security
                        </a>
                    </div>


                </div>





                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 font-weight-bold text-primary">Staff Directory</h6>
                                <a href="staffAttendance.php" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-clipboard-check me-1"></i> Manage Attendance
                                </a>
                            </div>
                            <div class="card-body">
                                <form method="GET" action="" class="mb-4">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="search-container">
                                                <input type="text" class="form-control" name="search"
                                                    placeholder="Search by ID or Name"
                                                    value="<?php echo $searchTerm; ?>">
                                                <button type="submit" class="btn btn-primary search-icon">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <select class="form-select" name="position">
                                                <option value="">All Positions</option>
                                                <option value="Doctor"
                                                    <?php echo ($position == 'Doctor') ? 'selected' : ''; ?>>Doctors
                                                </option>
                                                <option value="Nurse"
                                                    <?php echo ($position == 'Nurse') ? 'selected' : ''; ?>>Nurses
                                                </option>
                                                <option value="Laboratorist"
                                                    <?php echo ($position == 'Laboratorist') ? 'selected' : ''; ?>>
                                                    Laboratorists</option>
                                                <option value="Receptionist"
                                                    <?php echo ($position == 'Receptionist') ? 'selected' : ''; ?>>
                                                    Receptionists</option>
                                                <option value="Pharmacist"
                                                    <?php echo ($position == 'Pharmacist') ? 'selected' : ''; ?>>
                                                    Pharmacists</option>
                                                <option value="Security"
                                                    <?php echo ($position == 'Security') ? 'selected' : ''; ?>>Security
                                                </option>
                                            </select>
                                        </div>

                                        <div class="col-md-2">
                                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                                        </div>
                                        <div class="col-md-2">
                                            <a href="staffManagement.php" class="btn btn-secondary w-100">Reset</a>
                                        </div>
                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Position</th>
                                                <th>Contact</th>
                                                <th>Attendance</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($searchResults) && empty($searchTerm) && empty($position)): ?>
                                            <?php
                                                $staffSql = "SELECT StaffID, Name, Position, ContactNumber, Attendance FROM Staff ORDER BY Position, Name LIMIT 20";
                                                $staffResult = $conn->query($staffSql);
                                                
                                                if ($staffResult->num_rows > 0) {
                                                    while($row = $staffResult->fetch_assoc()) {
                                                        $attendanceClass = '';
                                                        if ($row["Attendance"] == 'Present') {
                                                            $attendanceClass = 'text-success';
                                                        } elseif ($row["Attendance"] == 'Absent') {
                                                            $attendanceClass = 'text-danger';
                                                        } elseif ($row["Attendance"] == 'On Leave') {
                                                            $attendanceClass = 'text-warning';
                                                        }
                                                        
                                                        echo "<tr>";
                                                        echo "<td>" . $row["StaffID"] . "</td>";
                                                        echo "<td>" . $row["Name"] . "</td>";
                                                        echo "<td>" . $row["Position"] . "</td>";
                                                        echo "<td>" . $row["ContactNumber"] . "</td>";
                                                        echo "<td class='" . $attendanceClass . "'>" . $row["Attendance"] . "</td>";
                                                        echo "<td>
                                                                <button class='btn btn-sm btn-info view-staff' data-id='" . $row["StaffID"] . "'>
                                                                    <i class='fas fa-eye'></i>
                                                                </button>
                                                                <button class='btn btn-sm btn-warning update-attendance' data-id='" . $row["StaffID"] . "' data-attendance='" . $row["Attendance"] . "'>
                                                                    <i class='fas fa-clipboard-check'></i>
                                                                </button>
                                                                <button class='btn btn-sm btn-danger delete-staff' data-id='" . $row["StaffID"] . "'>
                                                                <i class='fas fa-trash'></i>
                                                            </button>
                                                            
                                                            </td>";
                                                        echo "</tr>";
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='6' class='text-center'>No staff found</td></tr>";
                                                }
                                                ?>
                                            <?php elseif (!empty($searchResults)): ?>
                                            <?php foreach ($searchResults as $staff): ?>
                                            <?php
                                                    $attendanceClass = '';
                                                    if ($staff["Attendance"] == 'Present') {
                                                        $attendanceClass = 'text-success';
                                                    } elseif ($staff["Attendance"] == 'Absent') {
                                                        $attendanceClass = 'text-danger';
                                                    } elseif ($staff["Attendance"] == 'On Leave') {
                                                        $attendanceClass = 'text-warning';
                                                    }
                                                    ?>
                                            <tr>
                                                <td><?php echo $staff["StaffID"]; ?></td>
                                                <td><?php echo $staff["Name"]; ?></td>
                                                <td><?php echo $staff["Position"]; ?></td>
                                                <td><?php echo $staff["ContactNumber"]; ?></td>
                                                <td class="<?php echo $attendanceClass; ?>">
                                                    <?php echo $staff["Attendance"]; ?></td>
                                                <td>
                                                    <button class='btn btn-sm btn-info view-staff'
                                                        data-id='<?php echo $staff["StaffID"]; ?>'>
                                                        <i class='fas fa-eye'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-warning update-attendance'
                                                        data-id='<?php echo $staff["StaffID"]; ?>'
                                                        data-attendance='<?php echo $staff["Attendance"]; ?>'>
                                                        <i class='fas fa-clipboard-check'></i>
                                                    </button>

                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center">No results found for your search
                                                    criteria</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Staff Details Modal -->
                <div class="modal fade" id="staffDetailsModal" tabindex="-1" aria-labelledby="staffDetailsModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staffDetailsModalLabel">Staff Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="staffDetailsContent">
                                <!-- Staff details will be loaded here -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Update Attendance Modal -->
                <div class="modal fade" id="attendanceModal" tabindex="-1" aria-labelledby="attendanceModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="attendanceModalLabel">Update Attendance</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="attendanceForm">
                                    <input type="hidden" id="staffId" name="staffId">
                                    <div class="mb-3">
                                        <label for="attendance" class="form-label">Attendance Status</label>
                                        <select class="form-select" id="attendance" name="attendance" required>
                                            <option value="Present">Present</option>
                                            <option value="Absent">Absent</option>
                                            <option value="On Leave">On Leave</option>
                                            <option value="Late">Late</option>
                                        </select>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary" id="confirmAttendance">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // View staff details
        $('.view-staff').click(function() {
            var staffId = $(this).data('id');

            // AJAX request to get staff details
            $.ajax({
                url: 'getStaffDetails.php',
                type: 'GET',
                data: {
                    id: staffId
                },
                success: function(response) {
                    $('#staffDetailsContent').html(response);
                    $('#staffDetailsModal').modal('show');
                },
                error: function() {
                    alert('Error fetching staff details');
                }
            });
        });

        // Update attendance
        $('.update-attendance').click(function() {
            var staffId = $(this).data('id');
            var attendance = $(this).data('attendance');

            $('#staffId').val(staffId);
            $('#attendance').val(attendance);
            $('#attendanceModal').modal('show');
        });

        $('#confirmAttendance').click(function() {
            var staffId = $('#staffId').val();
            var attendance = $('#attendance').val();

            // AJAX request to update attendance
            $.ajax({
                url: 'updateAttendance.php',
                type: 'POST',
                data: {
                    staffId: staffId,
                    attendance: attendance
                },
                success: function(response) {
                    $('#attendanceModal').modal('hide');
                    location.reload();
                },
                error: function() {
                    alert('Error updating attendance');
                }
            });
        });
    });


    $(document).ready(function() {
        // Delete staff record
        $('.delete-staff').click(function() {
            var staffId = $(this).data('id');

            if (confirm("Are you sure you want to delete this staff member?")) {
                $.ajax({
                    url: 'deleteStaff.php',
                    type: 'POST',
                    data: {
                        staffId: staffId
                    },
                    success: function(response) {
                        if (response === "success") {
                            alert("Staff deleted successfully!");
                            location.reload(); // Refresh the page
                        } else {
                            alert("Error deleting staff.");
                        }
                    },
                    error: function() {
                        alert("Error processing request.");
                    }
                });
            }
        });
    });
    </script>
</body>

</html>