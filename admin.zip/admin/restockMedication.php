<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['medId']) && isset($_POST['qty'])) {
    $medId = $_POST['medId'];
    $qty = $_POST['qty'];
    $date = $_POST['date'];
    
    $conn->begin_transaction();
    
    try {
        $stockSql = "SELECT StockInQty, BalanceQty FROM Pharmacy WHERE MedID = ?";
        $stockStmt = $conn->prepare($stockSql);
        $stockStmt->bind_param("s", $medId);
        $stockStmt->execute();
        $stockResult = $stockStmt->get_result();
        $stockRow = $stockResult->fetch_assoc();
        
        $newStockInQty = $stockRow['StockInQty'] + $qty;
        $newBalanceQty = $stockRow['BalanceQty'] + $qty;
        
        // Update stock in Pharmacy table
        $updateSql = "UPDATE Pharmacy SET StockInQty = ?, BalanceQty = ?, StockInDate = ? WHERE MedID = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("iiss", $newStockInQty, $newBalanceQty, $date, $medId);
        $updateStmt->execute();
        
        $conn->commit();
        
        echo "success";
    } catch (Exception $e) {
        $conn->rollback();
        echo "error: " . $e->getMessage();
    }
} else {
    echo "Invalid request";
}
?>