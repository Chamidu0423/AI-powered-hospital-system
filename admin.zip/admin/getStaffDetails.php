<?php
include 'config.php';

if (isset($_GET['id'])) {
    $staffId = $_GET['id'];
    
    $sql = "SELECT * FROM Staff WHERE StaffID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $staffId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $staff = $result->fetch_assoc();
        
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Staff ID:</h6>';
        echo '<p>' . $staff['StaffID'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Name:</h6>';
        echo '<p>' . $staff['Name'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Position:</h6>';
        echo '<p>' . $staff['Position'] . '</p>';
        
        if ($staff['Position'] == 'Doctor') {
            echo '<h6 class="font-weight-bold">SLMC Registration:</h6>';
            echo '<p>' . ($staff['SLMC_Registration'] ? $staff['SLMC_Registration'] : 'N/A') . '</p>';
            
            echo '<h6 class="font-weight-bold">Criteria/Specialty:</h6>';
            echo '<p>' . ($staff['Criteria'] ? $staff['Criteria'] : 'N/A') . '</p>';
        }
        
        echo '<h6 class="font-weight-bold">Contact Number:</h6>';
        echo '<p>' . $staff['ContactNumber'] . '</p>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">NIC:</h6>';
        echo '<p>' . $staff['NIC'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Address:</h6>';
        echo '<p>' . $staff['Address'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Gender:</h6>';
        echo '<p>' . $staff['Gender'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Date of Birth:</h6>';
        echo '<p>' . $staff['DOB'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Attendance:</h6>';
        echo '<p>' . $staff['Attendance'] . '</p>';
        echo '</div>';
        echo '</div>';
        
        // If doctor, show recent appointments
        if ($staff['Position'] == 'Doctor') {
            $appointmentSql = "SELECT a.AppointmentID, a.Date, a.Time, p.Name as PatientName 
                              FROM Appointment a 
                              JOIN Patient p ON a.PatientID = p.PatientID 
                              WHERE a.StaffID = ? 
                              ORDER BY a.Date DESC, a.Time DESC LIMIT 5";
            $appointmentStmt = $conn->prepare($appointmentSql);
            $appointmentStmt->bind_param("s", $staffId);
            $appointmentStmt->execute();
            $appointmentResult = $appointmentStmt->get_result();
            
            echo '<div class="mt-4">';
            echo '<h5 class="font-weight-bold">Recent Appointments</h5>';
            
            if ($appointmentResult->num_rows > 0) {
                echo '<div class="table-responsive">';
                echo '<table class="table table-bordered">';
                echo '<thead><tr><th>Appointment ID</th><th>Date</th><th>Time</th><th>Patient</th></tr></thead>';
                echo '<tbody>';
                
                while ($appointment = $appointmentResult->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $appointment['AppointmentID'] . '</td>';
                    echo '<td>' . $appointment['Date'] . '</td>';
                    echo '<td>' . $appointment['Time'] . '</td>';
                    echo '<td>' . $appointment['PatientName'] . '</td>';
                    echo '</tr>';
                }
                
                echo '</tbody></table>';
                echo '</div>';
            } else {
                echo '<p>No recent appointments found.</p>';
            }
            echo '</div>';
        }
        
    } else {
        echo '<div class="alert alert-danger">Staff not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>