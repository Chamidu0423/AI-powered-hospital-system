<?php
include 'config.php';

if (isset($_GET['id'])) {
    $appointmentId = $_GET['id'];
    
    $sql = "SELECT a.*, p.Name as PatientName, p.PatientID, p.ContactNumber, p.Address, p.NIC, 
                  s.Name as StaffName, s.Position, s.Criteria 
           FROM Appointment a 
           JOIN Patient p ON a.PatientID = p.PatientID 
           JOIN Staff s ON a.StaffID = s.StaffID 
           WHERE a.AppointmentID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $appointmentId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $appointment = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Slip - <?php echo $appointment['AppointmentID']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .appointment-slip {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
        }
        .slip-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .slip-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .hospital-name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .slip-subtitle {
            font-size: 16px;
            color: #555;
        }
        .slip-info {
            margin-bottom: 20px;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
        }
        .important-note {
            margin-top: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border-left: 4px solid #0d6efd;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 15px;
            }
            .appointment-slip {
                border: none;
            }
        }
    </style>
</head>
<body>
    <div class="no-print mb-3">
        <button onclick="window.print()" class="btn btn-primary">Print Appointment</button>
        <button onclick="window.close()" class="btn btn-secondary">Close</button>
    </div>
    
    <div class="appointment-slip">
        <div class="slip-header">
            <div class="slip-title">Appointment Confirmation</div>
            <div class="hospital-name">VirtualPuls Hospital</div>
            <div class="slip-subtitle">Excellence in Healthcare</div>
        </div>
        
        <div class="row slip-info">
            <div class="col-md-6">
                <h5>Patient Information</h5>
                <p><strong>Name:</strong> <?php echo $appointment['PatientName']; ?><br>
                <strong>ID:</strong> <?php echo $appointment['PatientID']; ?><br>
                <strong>Contact:</strong> <?php echo $appointment['ContactNumber']; ?><br>
                <strong>Address:</strong> <?php echo $appointment['Address']; ?></p>
            </div>
            
            <div class="col-md-6">
                <h5>Appointment Details</h5>
                <p><strong>Appointment ID:</strong> <?php echo $appointment['AppointmentID']; ?><br>
                <strong>Date:</strong> <?php echo $appointment['Date']; ?><br>
                <strong>Time:</strong> <?php echo date('h:i A', strtotime($appointment['Time'])); ?><br>
                <strong>Doctor:</strong> <?php echo $appointment['StaffName']; ?> (<?php echo $appointment['Criteria']; ?>)</p>
            </div>
        </div>
        
        <div class="important-note">
            <h5>Important Notes:</h5>
            <ul>
                <li>Please arrive 15 minutes before your scheduled appointment time.</li>
                <li>Bring your identification card and any previous medical records.</li>
                <li>If you need to cancel or reschedule, please contact us at least 24 hours in advance.</li>
                <li>Contact: 011-2345678 for any inquiries.</li>
            </ul>
        </div>
        
        <div class="footer">
            <p>This is a computer-generated appointment slip and does not require a physical signature.</p>
            <p>VirtualPuls Hospital - <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
    </div>
</body>
</html>
<?php
    } else {
        echo '<div class="alert alert-danger">Appointment record not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>