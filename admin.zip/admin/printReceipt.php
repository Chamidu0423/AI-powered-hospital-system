<?php
include 'config.php';

if (isset($_GET['id'])) {
    $transactionId = $_GET['id'];
    
    $sql = "SELECT t.*, p.Name as PatientName, p.PatientID, p.ContactNumber, p.Address,
                  m.MedName, m.Description, d.Description as DiagnosisDescription 
           FROM PharmacyTransaction t 
           JOIN Patient p ON t.PatientID = p.PatientID 
           JOIN Pharmacy m ON t.MedID = m.MedID 
           LEFT JOIN Diagnosis d ON t.DiagnosisID = d.DiagnosisID 
           WHERE t.TransactionID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $transactionId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $transaction = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt - <?php echo $transaction['TransactionID']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .receipt {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
        }
        .receipt-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .receipt-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .hospital-name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .receipt-subtitle {
            font-size: 16px;
            color: #555;
        }
        .receipt-info {
            margin-bottom: 20px;
        }
        .receipt-table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        .receipt-table th, .receipt-table td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .receipt-table th {
            background-color: #f8f9fa;
        }
        .receipt-total {
            margin-top: 20px;
            text-align: right;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 15px;
            }
            .receipt {
                border: none;
            }
        }
    </style>
</head>
<body>
    <div class="no-print mb-3">
        <button onclick="window.print()" class="btn btn-primary">Print Receipt</button>
        <button onclick="window.close()" class="btn btn-secondary">Close</button>
    </div>
    
    <div class="receipt">
        <div class="receipt-header">
            <div class="receipt-title">Pharmacy Receipt</div>
            <div class="hospital-name">VirtualPuls Hospital</div>
            <div class="receipt-subtitle">Excellence in Healthcare</div>
        </div>
        
        <div class="row receipt-info">
            <div class="col-md-6">
                <h5>Patient Information</h5>
                <p><strong>Name:</strong> <?php echo $transaction['PatientName']; ?><br>
                <strong>ID:</strong> <?php echo $transaction['PatientID']; ?><br>
                <strong>Contact:</strong> <?php echo $transaction['ContactNumber']; ?><br>
                <strong>Address:</strong> <?php echo $transaction['Address']; ?></p>
            </div>
            
            <div class="col-md-6 text-md-end">
                <h5>Receipt Information</h5>
                <p><strong>Receipt No:</strong> <?php echo $transaction['TransactionID']; ?><br>
                <strong>Date:</strong> <?php echo $transaction['Date']; ?><br>
                <strong>Diagnosis ID:</strong> <?php echo $transaction['DiagnosisID']; ?></p>
            </div>
        </div>
        
        <table class="receipt-table">
            <thead>
                <tr>
                    <th>Medication</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo $transaction['MedName']; ?></td>
                    <td><?php echo $transaction['Description']; ?></td>
                    <td><?php echo $transaction['Qty']; ?></td>
                    <td>$<?php echo number_format($transaction['UnitPrice'], 2); ?></td>
                    <td>$<?php echo number_format($transaction['TotalBill'], 2); ?></td>
                </tr>
            </tbody>
        </table>
        
        <div class="receipt-total">
            <p>Total Amount: $<?php echo number_format($transaction['TotalBill'], 2); ?></p>
        </div>
        
        <div class="row mt-5">
            <div class="col-6">
                <p>_______________________<br>Pharmacist Signature</p>
            </div>
            <div class="col-6 text-end">
                <p>_______________________<br>Patient Signature</p>
            </div>
        </div>
        
        <div class="footer">
            <p>This is a computer-generated receipt and does not require a physical signature.</p>
            <p>VirtualPuls Hospital - <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
    </div>
</body>
</html>
<?php
    } else {
        echo '<div class="alert alert-danger">Transaction record not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>