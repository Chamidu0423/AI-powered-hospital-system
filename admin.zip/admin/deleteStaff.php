<?php
include 'config.php';

if (isset($_POST['staffId'])) {
    $staffId = $_POST['staffId'];

    $deleteSql = "DELETE FROM Staff WHERE StaffID = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("s", $staffId);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    $stmt->close();
}
?>