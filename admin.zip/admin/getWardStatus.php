<?php
include 'config.php';

if (isset($_POST['diagnosisId'])) {
    $diagnosisId = $_POST['diagnosisId'];
    $wardStatusSql = "SELECT WardStatus FROM Diagnosis WHERE DiagnosisID = ?";
    $stmt = $conn->prepare($wardStatusSql);
    $stmt->bind_param("s", $diagnosisId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo json_encode(['wardStatus' => $row['WardStatus']]); // Return the ward status as JSON
    } else {
        echo json_encode(['wardStatus' => null]); // No ward status found
    }
    $stmt->close();
}
?>