<?php
include 'config.php';

// Get all medications
$inventorySql = "SELECT * FROM Pharmacy ORDER BY MedName";
$inventoryResult = $conn->query($inventorySql);

// Get low stock medications
$lowStockSql = "SELECT * FROM Pharmacy WHERE BalanceQty <= 10 ORDER BY BalanceQty ASC";
$lowStockResult = $conn->query($lowStockSql);
$lowStockCount = $lowStockResult->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Inventory Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .report-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .report-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .hospital-name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .report-subtitle {
            font-size: 16px;
            color: #555;
        }
        .report-date {
            margin-bottom: 20px;
            text-align: right;
        }
        .section-title {
            margin-top: 30px;
            margin-bottom: 15px;
            font-weight: bold;
            color: #333;
        }
        .low-stock {
            color: #dc3545;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="no-print mb-3">
        <button onclick="window.print()" class="btn btn-primary">Print Report</button>
        <button onclick="window.close()" class="btn btn-secondary">Close</button>
    </div>
    
    <div class="report-header">
        <div class="report-title">Pharmacy Inventory Report</div>
        <div class="hospital-name">VirtualPuls Hospital</div>
        <div class="report-subtitle">Excellence in Healthcare</div>
    </div>
    
    <div class="report-date">
        <p><strong>Report Date:</strong> <?php echo date('Y-m-d'); ?></p>
    </div>
    
    <h4 class="section-title">Complete Inventory</h4>
    
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Stock In</th>
                    <th>Balance</th>
                    <th>Price</th>
                    <th>Supplier</th>
                    <th>Stock In Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($inventoryResult->num_rows > 0) {
                    while($row = $inventoryResult->fetch_assoc()) {
                        $stockClass = ($row["BalanceQty"] <= 10) ? "low-stock" : "";
                        
                        echo "<tr>";
                        echo "<td>" . $row["MedID"] . "</td>";
                        echo "<td>" . $row["MedName"] . "</td>";
                        echo "<td>" . $row["Description"] . "</td>";
                        echo "<td>" . $row["StockInQty"] . "</td>";
                        echo "<td class='" . $stockClass . "'>" . $row["BalanceQty"] . "</td>";
                        echo "<td>$" . number_format($row["Price"], 2) . "</td>";
                        echo "<td>" . $row["Supplier"] . "</td>";
                        echo "<td>" . $row["StockInDate"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8' class='text-center'>No medications found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    
    <?php if ($lowStockCount > 0): ?>
    <h4 class="section-title text-danger">Low Stock Alert</h4>
    
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Balance</th>
                    <th>Price</th>
                    <th>Supplier</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while($row = $lowStockResult->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["MedID"] . "</td>";
                    echo "<td>" . $row["MedName"] . "</td>";
                    echo "<td>" . $row["Description"] . "</td>";
                    echo "<td class='low-stock'>" . $row["BalanceQty"] . "</td>";
                    echo "<td>$" . number_format($row["Price"], 2) . "</td>";
                    echo "<td>" . $row["Supplier"] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    
    <div class="footer">
        <p>This is a computer-generated report and does not require a physical signature.</p>
        <p>VirtualPuls Hospital - <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>
</body>
</html>