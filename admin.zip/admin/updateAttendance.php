<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['staffId']) && isset($_POST['attendance'])) {
    $staffId = $_POST['staffId'];
    $attendance = $_POST['attendance'];
    
    $sql = "UPDATE Staff SET Attendance = ? WHERE StaffID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $attendance, $staffId);
    
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }
    
    $stmt->close();
} else {
    echo "Invalid request";
}
?>