<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $patientId = $_POST['id'];
    
    $stmt = $conn->prepare("DELETE FROM Patient WHERE PatientID = ?");
    $stmt->bind_param("s", $patientId);  
    
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo "success";
        } else {
            echo "No patient found with that ID";
        }
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
} else {
    echo "Invalid request";
}
?>