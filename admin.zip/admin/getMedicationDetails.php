<?php
include 'config.php';

if (isset($_GET['id'])) {
    $medId = $_GET['id'];
    
    $sql = "SELECT * FROM Pharmacy WHERE MedID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $medId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $med = $result->fetch_assoc();
        
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Medication ID:</h6>';
        echo '<p>' . $med['MedID'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Name:</h6>';
        echo '<p>' . $med['MedName'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Description:</h6>';
        echo '<p>' . $med['Description'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Supplier:</h6>';
        echo '<p>' . $med['Supplier'] . '</p>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Stock In Quantity:</h6>';
        echo '<p>' . $med['StockInQty'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Balance Quantity:</h6>';
        echo '<p>' . $med['BalanceQty'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Unit Price:</h6>';
        echo '<p>$' . number_format($med['Price'], 2) . '</p>';
        
        echo '<h6 class="font-weight-bold">Stock In Date:</h6>';
        echo '<p>' . $med['StockInDate'] . '</p>';
        echo '</div>';
        echo '</div>';
        
        $transactionSql = "SELECT t.TransactionID, t.Date, t.Qty, p.Name as PatientName 
                          FROM PharmacyTransaction t 
                          JOIN Patient p ON t.PatientID = p.PatientID 
                          WHERE t.MedID = ? 
                          ORDER BY t.Date DESC, t.TransactionID DESC LIMIT 10";
        $transactionStmt = $conn->prepare($transactionSql);
        $transactionStmt->bind_param("s", $medId);
        $transactionStmt->execute();
        $transactionResult = $transactionStmt->get_result();
        
        echo '<div class="mt-4">';
        echo '<h5 class="font-weight-bold">Recent Transactions</h5>';
        
        if ($transactionResult->num_rows > 0) {
            echo '<div class="table-responsive">';
            echo '<table class="table table-bordered">';
            echo '<thead><tr><th>Transaction ID</th><th>Date</th><th>Quantity</th><th>Patient</th></tr></thead>';
            echo '<tbody>';
            
            while ($transaction = $transactionResult->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $transaction['TransactionID'] . '</td>';
                echo '<td>' . $transaction['Date'] . '</td>';
                echo '<td>' . $transaction['Qty'] . '</td>';
                echo '<td>' . $transaction['PatientName'] . '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
            echo '</div>';
        } else {
            echo '<p>No transaction history found.</p>';
        }
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-danger">Medication not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>