<?php
include 'config.php';

if (isset($_GET['id'])) {
    $testId = $_GET['id'];
    
    $sql = "SELECT l.*, p.Name as PatientName, p.PatientID, p.NIC, p.Gender, p.DOB, 
                  s.Name as StaffName, s.Position, d.Description as DiagnosisDescription 
           FROM Laboratory l 
           JOIN Patient p ON l.PatientID = p.PatientID 
           JOIN Staff s ON l.StaffID = s.StaffID 
           JOIN Diagnosis d ON l.DiagnosisID = d.DiagnosisID 
           WHERE l.TestID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $testId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $test = $result->fetch_assoc();
        
        // Calculate age from DOB
        $dob = new DateTime($test['DOB']);
        $now = new DateTime();
        $age = $now->diff($dob)->y;
        
        echo '<div data-test-id="' . $test['TestID'] . '">';
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Test ID:</h6>';
        echo '<p>' . $test['TestID'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Test Title:</h6>';
        echo '<p>' . $test['TestTitle'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Test Date:</h6>';
        echo '<p>' . $test['Date'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Patient:</h6>';
        echo '<p>' . $test['PatientName'] . ' (' . $test['PatientID'] . ')</p>';
        
        echo '<h6 class="font-weight-bold">Patient Details:</h6>';
        echo '<p>NIC: ' . $test['NIC'] . '<br>';
        echo 'Gender: ' . $test['Gender'] . '<br>';
        echo 'Age: ' . $age . ' years</p>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Lab Technician:</h6>';
        echo '<p>' . $test['StaffName'] . ' (' . $test['Position'] . ')</p>';
        
        echo '<h6 class="font-weight-bold">Diagnosis:</h6>';
        echo '<p>' . $test['DiagnosisDescription'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Diagnosis ID:</h6>';
        echo '<p>' . $test['DiagnosisID'] . '</p>';
        echo '</div>';
        
        echo '<div class="col-12 mt-3">';
        echo '<h6 class="font-weight-bold">Test Results:</h6>';
        echo '<div class="p-3 bg-light rounded">' . nl2br($test['TestResults']) . '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-danger">Test record not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>