<?php
include 'config.php';

if (isset($_GET['id'])) {
    $transactionId = $_GET['id'];
    
    $sql = "SELECT t.*, p.Name as PatientName, p.PatientID, p.ContactNumber, 
                  m.MedName, m.Description, d.Description as DiagnosisDescription 
           FROM PharmacyTransaction t 
           JOIN Patient p ON t.PatientID = p.PatientID 
           JOIN Pharmacy m ON t.MedID = m.MedID 
           LEFT JOIN Diagnosis d ON t.DiagnosisID = d.DiagnosisID 
           WHERE t.TransactionID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $transactionId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $transaction = $result->fetch_assoc();
        
        echo '<div data-transaction-id="' . $transaction['TransactionID'] . '">';
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Transaction ID:</h6>';
        echo '<p>' . $transaction['TransactionID'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Date:</h6>';
        echo '<p>' . $transaction['Date'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Patient:</h6>';
        echo '<p>' . $transaction['PatientName'] . ' (' . $transaction['PatientID'] . ')</p>';
        
        echo '<h6 class="font-weight-bold">Contact Number:</h6>';
        echo '<p>' . $transaction['ContactNumber'] . '</p>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Medication:</h6>';
        echo '<p>' . $transaction['MedName'] . ' (' . $transaction['MedID'] . ')</p>';
        
        echo '<h6 class="font-weight-bold">Description:</h6>';
        echo '<p>' . $transaction['Description'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Quantity:</h6>';
        echo '<p>' . $transaction['Qty'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Unit Price:</h6>';
        echo '<p>Rs.' . number_format($transaction['UnitPrice'], 2) . '</p>';
        echo '</div>';
        
        echo '<div class="col-12 mt-3">';
        echo '<h6 class="font-weight-bold">Diagnosis:</h6>';
        echo '<p>' . ($transaction['DiagnosisDescription'] ? $transaction['DiagnosisDescription'] : 'N/A') . '</p>';
        
        echo '<h6 class="font-weight-bold">Total Bill:</h6>';
        echo '<p class="fs-4 fw-bold">Rs.' . number_format($transaction['TotalBill'], 2) . '</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-danger">Transaction not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>