<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VirtualPuls - Hospital Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        #current-date-time {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            background: #f5f5f5;
            padding: 5px 10px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        #theme-icon {
            font-size: 20px;
            color: #ffcc00;
            cursor: pointer;
            transition: transform 0.3s ease, color 0.3s ease;
        }

        #theme-icon:hover {
            transform: scale(1.2);
            color: #ffa500;
        }

        .h2 {
            text-align: center;
            display: block;
            margin: 0 auto;
        }

        .sidebar-icon {
            font-size: 22px;
            color: #007bff;
        }

        .sidebar-text {
            font-size: 18px;
            font-weight: bold;
        }

        .logout-btn {
            display: inline-block;
            padding: 0.5rem 1.5rem;
            background-color: #df7c86;
            color: white;
            text-decoration: none;
            border-radius: 10px;
            transition: background-color 0.3s;
        }

        .logout-btn:hover {
            background-color: #da505e;
            color: white;
        }

    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-chart-line me-2 sidebar-icon"></i>
                                <span class="sidebar-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>
                    </ul>


                </div>
            </div>



            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard</h1>
                    <div class="d-flex align-items-center">
                        <!-- Date, Time, and Day Display -->
                        <span id="current-date-time" class="me-3"></span>
                        <!-- Day/Night Icon -->
                        <i id="theme-icon" class="fas"></i>
                    </div>
                    <div class="ms-auto">
                        <a href="../logout.php" class="logout-btn">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </div>

                <script>
                    function updateDateTimeAndTheme() {
                        // Get the current date and time
                        const currentDate = new Date();
                        let hours = currentDate.getHours();
                        let minutes = currentDate.getMinutes();
                        let day = currentDate.getDate();
                        let month = currentDate.getMonth() + 1; // Months are 0-indexed
                        let year = currentDate.getFullYear();

                        // Day of the week
                        const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                        const dayOfWeek = daysOfWeek[currentDate.getDay()];

                        minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if minutes are less than 10

                        const dateString = `${month}/${day}/${year}`;
                        const timeString = `${hours}:${minutes}`;

                        // Display date, time, and day of the week
                        document.getElementById('current-date-time').textContent =
                            `${dayOfWeek}, ${dateString} - ${timeString}`;

                        // Change the icon and theme based on the time
                        const themeIcon = document.getElementById('theme-icon');
                        if (hours >= 6 && hours < 18) {
                            // Day time (6 AM to 6 PM)
                            themeIcon.classList.remove('fa-moon');
                            themeIcon.classList.add('fa-sun');
                            themeIcon.style.color = 'orange'; // Day icon color
                        } else {
                            // Night time (6 PM to 6 AM)
                            themeIcon.classList.remove('fa-sun');
                            themeIcon.classList.add('fa-moon');
                            themeIcon.style.color = 'blue'; // Night icon color
                        }
                    }

                    // Update time, date, and theme every minute
                    setInterval(updateDateTimeAndTheme, 60000);

                    // Initial call to set the date, time, and theme on page load
                    updateDateTimeAndTheme();
                </script>


                <!-- Dashboard Cards -->
                <div class="row">
                    <?php
                    // Get patient count
                    $patientQuery = "SELECT COUNT(*) as count FROM Patient";
                    $patientResult = $conn->query($patientQuery);
                    $patientCount = $patientResult->fetch_assoc()['count'];

                    // Get staff count
                    $staffQuery = "SELECT COUNT(*) as count FROM Staff";
                    $staffResult = $conn->query($staffQuery);
                    $staffCount = $staffResult->fetch_assoc()['count'];

                    // Get appointment count
                    $appointmentQuery = "SELECT COUNT(*) as count FROM Appointment";
                    $appointmentResult = $conn->query($appointmentQuery);
                    $appointmentCount = $appointmentResult->fetch_assoc()['count'];

                    // Get ward count
                    $wardQuery = "SELECT COUNT(*) as count FROM Ward";
                    $wardResult = $conn->query($wardQuery);
                    $wardCount = $wardResult->fetch_assoc()['count'];
                    ?>

                    <!-- Patient Card -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Patients</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $patientCount; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Staff Card -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Staff</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $staffCount; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-md fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Appointments Card -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Appointments</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo $appointmentCount; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Ward Card -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Admitted Patients</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $wardCount; ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-bed fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Access Buttons -->
                <div class="row mt-4">
                    <div class="col-lg-12">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Quick Access</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <a href="registerPatient.php" class="btn btn-primary btn-block py-3">
                                            <i class="fas fa-user-plus me-2"></i>Register Patient
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="admitPatients.php" class="btn btn-success btn-block py-3">
                                            <i class="fas fa-procedures me-2"></i>Admit Patient
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="pharmacyInventory.php" class="btn btn-info btn-block py-3">
                                            <i class="fas fa-pills me-2"></i>Pharmacy
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <a href="staffManagement.php" class="btn btn-warning btn-block py-3">
                                            <i class="fas fa-users-cog me-2"></i>Staff Management
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Patients -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Recent Patients</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Registration Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $recentPatientsQuery = "SELECT PatientID, Name, RegistrationDate FROM Patient ORDER BY RegistrationDate DESC LIMIT 5";
                                            $recentPatientsResult = $conn->query($recentPatientsQuery);

                                            if ($recentPatientsResult->num_rows > 0) {
                                                while ($row = $recentPatientsResult->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["PatientID"] . "</td>";
                                                    echo "<td>" . $row["Name"] . "</td>";
                                                    echo "<td>" . $row["RegistrationDate"] . "</td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='3' class='text-center'>No patients found</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Appointments -->
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Recent Appointments</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Patient</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $recentAppointmentsQuery = "SELECT a.AppointmentID, p.Name, a.Date 
                                                                        FROM Appointment a 
                                                                        JOIN Patient p ON a.PatientID = p.PatientID 
                                                                        ORDER BY a.Date DESC, a.Time DESC LIMIT 5";
                                            $recentAppointmentsResult = $conn->query($recentAppointmentsQuery);

                                            if ($recentAppointmentsResult->num_rows > 0) {
                                                while ($row = $recentAppointmentsResult->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["AppointmentID"] . "</td>";
                                                    echo "<td>" . $row["Name"] . "</td>";
                                                    echo "<td>" . $row["Date"] . "</td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='3' class='text-center'>No appointments found</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>

</html>