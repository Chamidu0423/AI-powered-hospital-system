-- Drop and create database
DROP DATABASE IF EXISTS VirtualPuls;
CREATE DATABASE VirtualPuls;
USE VirtualPuls;
 
-- ID Tracker Table to Track Last Used IDs
CREATE TABLE IDTracker (
    TableName VARCHAR(50) PRIMARY KEY,
    LastID INT NOT NULL
);
 
-- Initialize IDTracker for each table that uses custom IDs
INSERT INTO IDTracker (TableName, LastID) VALUES ('Patient', 0);
INSERT INTO IDTracker (TableName, LastID) VALUES ('Staff', 0);
INSERT INTO IDTracker (TableName, LastID) VALUES ('Appointment', 0);
INSERT INTO IDTracker (TableName, LastID) VALUES ('Diagnosis', 0);
INSERT INTO IDTracker (TableName, LastID) VALUES ('Laboratory', 0);
INSERT INTO IDTracker (TableName, LastID) VALUES ('Pharmacy', 0);
INSERT INTO IDTracker (TableName, LastID) VALUES ('PharmacyTransaction', 0);
INSERT INTO IDTracker (TableName, LastID) VALUES ('Ward', 0);
 
CREATE TABLE Patient (
    PatientID VARCHAR(20) PRIMARY KEY,
    Name VARCHAR(100),
    ContactNumber VARCHAR(15),
    Email VARCHAR(255),
    Address VARCHAR(150),
    NIC VARCHAR(20),
    DOB DATE,
    GuardianName VARCHAR(100),
    GuardianNIC VARCHAR(20),
    GuardianContactNumber VARCHAR(15),
    Reason TEXT,
    RegistrationDate DATE DEFAULT (CURRENT_DATE),
    Gender VARCHAR(10)
);
 
 
-- Staff table
CREATE TABLE Staff (
    StaffID VARCHAR(20) PRIMARY KEY,
    Name VARCHAR(100),
    Position VARCHAR(50),
    SLMC_Registration VARCHAR(50),
    Criteria VARCHAR(50),
    Attendance VARCHAR(100),
    CountOfMembers INT,
    NIC VARCHAR(20),
    ContactNumber VARCHAR(15),
    Address VARCHAR(150),
    Dp VARCHAR(255),
    Gender VARCHAR(10),
    DOB DATE,
    Email VARCHAR(255)
);
 
-- Appointment table
CREATE TABLE Appointment (
    AppointmentID VARCHAR(20) PRIMARY KEY,
    PatientID VARCHAR(20),
    StaffID VARCHAR(20),
    Date DATE DEFAULT (CURRENT_DATE),
    Time TIME DEFAULT (CURRENT_TIME),
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE
);
 
-- Diagnosis table
CREATE TABLE Diagnosis (
    DiagnosisID VARCHAR(20) PRIMARY KEY,
    PatientID VARCHAR(20),
    AppointmentID VARCHAR(20),
    Description TEXT,
    Medicine TEXT,
    WardStatus VARCHAR(100),
    TestTitle VARCHAR(100),
    Status VARCHAR(20),
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (AppointmentID) REFERENCES Appointment(AppointmentID) ON DELETE CASCADE
);
 
-- Laboratory table
CREATE TABLE Laboratory (
    TestID VARCHAR(20) PRIMARY KEY,
    TestTitle VARCHAR(100),
    Date DATE,
    TestResults TEXT,
    PatientID VARCHAR(20),
    StaffID VARCHAR(20),
    DiagnosisID VARCHAR(20),
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE,
    FOREIGN KEY (DiagnosisID) REFERENCES Diagnosis(DiagnosisID) ON DELETE CASCADE
);
 
-- Pharmacy table
CREATE TABLE Pharmacy (
    MedID VARCHAR(20) PRIMARY KEY,
    MedName VARCHAR(100),
    Description TEXT,
    StockInQty INT,
    StockInDate DATE DEFAULT (CURRENT_DATE),
    BalanceQty INT,
    Supplier VARCHAR(100),
    Price DECIMAL(10,2)
);
 
-- PharmacyTransaction table
CREATE TABLE PharmacyTransaction (
    TransactionID VARCHAR(20) PRIMARY KEY,
    MedID VARCHAR(20),
    Qty INT,
    StockOut INT,
    PatientID VARCHAR(20),
    Date DATE DEFAULT (CURRENT_DATE),
    UnitPrice DECIMAL(10,2),
    TotalBill DECIMAL(10,2),
    DiagnosisID VARCHAR(20),
    FOREIGN KEY (MedID) REFERENCES Pharmacy(MedID) ON DELETE CASCADE,
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (DiagnosisID) REFERENCES Diagnosis(DiagnosisID) ON DELETE CASCADE
);
 
 
-- Create the Ward Table
CREATE TABLE Ward (
    WardID VARCHAR(10) PRIMARY KEY,  
    WardNo VARCHAR(10),
    BedNo VARCHAR(10),
    PatientID VARCHAR(20),
    InDate DATE DEFAULT (CURRENT_DATE),
    OutDate DATE,
    DiagnosisID VARCHAR(20),
    WardStaff VARCHAR(100),
    StaffID VARCHAR(20),
    Position VARCHAR(50),
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (DiagnosisID) REFERENCES Diagnosis(DiagnosisID) ON DELETE CASCADE,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE
);
 
-- Create the Trigger for Auto-Incrementing WardID
DELIMITER $$
 
CREATE TRIGGER before_insert_ward
BEFORE INSERT ON Ward
FOR EACH ROW
BEGIN
    DECLARE new_id INT;
    SELECT IFNULL(MAX(CAST(SUBSTRING(WardID, 2) AS UNSIGNED)), 0) + 1 INTO new_id FROM Ward;
    SET NEW.WardID = CONCAT('W', LPAD(new_id, 3, '0'));
END $$
 
DELIMITER ;
 
-- Login table
CREATE TABLE Login (
    UserID VARCHAR(20) PRIMARY KEY,
    Password VARCHAR(255) DEFAULT NULL,
    Position VARCHAR(50) NOT NULL,
    Email VARCHAR(255)
);
 
-- Triggers for auto-incrementing IDs using IDTracker
DELIMITER $$
 
-- Generic ID Trigger Template
CREATE TRIGGER before_patient_insert
BEFORE INSERT ON Patient
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    SELECT LastID + 1 INTO next_id FROM IDTracker WHERE TableName = 'Patient';
    UPDATE IDTracker SET LastID = next_id WHERE TableName = 'Patient';
    SET NEW.PatientID = CONCAT('P', LPAD(next_id, 5, '0'));
END $$
 
CREATE TRIGGER before_staff_insert
BEFORE INSERT ON Staff
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    SELECT LastID + 1 INTO next_id FROM IDTracker WHERE TableName = 'Staff';
    UPDATE IDTracker SET LastID = next_id WHERE TableName = 'Staff';
    SET NEW.StaffID = CONCAT('S', LPAD(next_id, 5, '0'));
END $$
 
CREATE TRIGGER before_appointment_insert
BEFORE INSERT ON Appointment
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    SELECT LastID + 1 INTO next_id FROM IDTracker WHERE TableName = 'Appointment';
    UPDATE IDTracker SET LastID = next_id WHERE TableName = 'Appointment';
    SET NEW.AppointmentID = CONCAT('A', LPAD(next_id, 5, '0'));
END $$
 
CREATE TRIGGER before_diagnosis_insert
BEFORE INSERT ON Diagnosis
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    SELECT LastID + 1 INTO next_id FROM IDTracker WHERE TableName = 'Diagnosis';
    UPDATE IDTracker SET LastID = next_id WHERE TableName = 'Diagnosis';
    SET NEW.DiagnosisID = CONCAT('D', LPAD(next_id, 5, '0'));
END $$
 
DELIMITER ;
 
DELIMITER $$
 
CREATE TRIGGER before_insert_pharmacy
BEFORE INSERT ON Pharmacy
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    SELECT IFNULL(MAX(CAST(SUBSTRING(MedID, 2) AS UNSIGNED)), 0) + 1 INTO next_id FROM Pharmacy;
    SET NEW.MedID = CONCAT('M', LPAD(next_id, 4, '0'));
END $$
 
DELIMITER ;
 
 
-- Login Triggers
DELIMITER //
 
CREATE TRIGGER after_patient_insert
AFTER INSERT ON Patient
FOR EACH ROW
BEGIN
    INSERT INTO Login (UserID, Position, Email) VALUES (NEW.PatientID, 'patient', NEW.Email);
END//
 
CREATE TRIGGER after_staff_insert
AFTER INSERT ON Staff
FOR EACH ROW
BEGIN
    INSERT INTO Login (UserID, Position, Email) VALUES (NEW.StaffID, NEW.Position, NEW.Email);
END//
 
DELIMITER ;
 
CREATE TABLE LAB_REQUEST (
    RequestID INT AUTO_INCREMENT PRIMARY KEY,
    PatientID VARCHAR(20),
    TestTitle VARCHAR(100),
    Description TEXT,
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE
);
 
CREATE TABLE LAB_ASSIGN_DATE (
    AssignID INT AUTO_INCREMENT PRIMARY KEY,
    PatientID VARCHAR(20),
    TestTitle VARCHAR(100),
    Date DATE,
    Time TIME,
    Description TEXT,
    FOREIGN KEY (PatientID) REFERENCES Patient(PatientID) ON DELETE CASCADE
);
 
CREATE TABLE OTP (
    Otp_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
 
-- Sample Patient Data
INSERT INTO Patient (Name, ContactNumber, Address, NIC, DOB, GuardianName, GuardianNIC, GuardianContactNumber, Reason, Gender,Email)
VALUES
('Kamal Perera', '0712345678', '45 Galle Road, Colombo 03', '199012345678', '1990-05-15', 'Sunil Perera', '196512345678', '0718765432', 'Routine checkup', 'Male','1@gmail.com'),
('Nuwan Silva', '0779876543', '12 Lake Road, Kandy', '198502345678', '1985-07-22', 'Chandana Silva', '195812345678', '0771234567', 'Fever and body pain', 'Male','chamidudilshan0423@gmail.com'),
('Tharushi Fernando', '0765432109', '88 Temple Rd, Gampaha', '199511123456', '1995-11-25', 'Rohan Fernando', '197012345678', '0719988776', 'General health checkup', 'Female','ruchiralakshanm@gmail.com'),
('Dilini Jayawardena', '0701122334', '102 Highlevel Rd, Nugegoda', '198908765432', '1989-06-30', 'Saman Jayawardena', '196409876543', '0755566778', 'Migraine headaches', 'Female','ruchicreationsweb@gmail.com'),
('Aravinda Jayasuriya', '0744567890', '56 Beach Rd, Matara', '198002234567', '1980-12-05', 'Siriwardena Jayasuriya', '195212345678', '0781122334', 'Diabetes follow-up', 'Male','1@gmail.com');
 
-- Sample Staff Data (Sri Lanka)
INSERT INTO Staff (Name, Position, SLMC_Registration, Criteria, Attendance, CountOfMembers, NIC, ContactNumber, Address, Gender, DOB,Email)
VALUES
('Dr. Sanjeewa Fernando', 'Doctor', 'SLMC12345', 'General Physician', 'Present', 1, '197512345678', '0712233445', '34 Lotus Rd, Colombo 07', 'Male', '1975-03-12','1@gmail.com'),
('Dr. Nadeesha Perera', 'Doctor', 'SLMC67890', 'Cardiologist', 'Present', 1, '198312345678', '0723344556', '21 King St, Kandy', 'Female', '1983-09-25','chamidudilshan0423@gmail.com'),
('Dr. Chaminda Gamage', 'Doctor', 'SLMC34567', 'Neurologist', 'Present', 1, '197902345678', '0756677889', '56 Central Rd, Galle', 'Male', '1979-11-30','ruchicreationsweb@gmail.com'),
('Dr. Nirmala de Silva', 'Doctor', 'SLMC45678', 'Pediatrician', 'Present', 1, '199012345678', '0774455667', '10 Green Ave, Nawala', 'Female', '1990-07-18','2@gmail.com'),
('Dr. Janaka Karunaratne', 'Doctor', 'SLMC56789', 'Orthopedic Surgeon', 'Present', 1, '196902345678', '0789988776', '99 River Rd, Kurunegala', 'Male', '1969-04-05','3@gmail.com');
 
-- Sample Appointments (Sri Lanka)
INSERT INTO Appointment (PatientID, StaffID) VALUES
('P00001', 'S00001'),
('P00002', 'S00002'),
('P00003', 'S00003'),
('P00004', 'S00004'),
('P00005', 'S00005');
 
-- Sample Diagnosis Data (Sri Lanka)
INSERT INTO Diagnosis (PatientID, AppointmentID, Description, Medicine, TestTitle, Status)
VALUES
('P00001', 'A00001', 'Hypertension-Blood Pressure (BP) testing is pending, but baseline labs show: Total Cholesterol 220 mg/dL , LDL 140 mg/dL , Serum Creatinine 1.1 mg/dL, and Fasting Glucose 105 mg/dL . Losartan 50mg was initiated empirically for suspected Stage 1 hypertension (≥130/80 mmHg) to address cardiovascular risk and potential renal protection. Additional findings include a normal potassium level (4.2 mEq/L) and trace microalbuminuria (30 mg/g creatinine), reinforcing the need for aggressive BP control and metabolic monitoring.', 'Losartan 50mg', 'Blood Pressure Test','Pending'),
('P00002', 'A00002', 'Viral Fever-The Complete Blood Count (CBC) results show a White Blood Cell (WBC) count of 11,000/µL, a Red Blood Cell (RBC) count of 4.5 million/µL, and Platelets at 200,000/µL. The C-Reactive Protein (CRP) level is 12 mg/L, and the Erythrocyte Sedimentation Rate (ESR) is 25 mm/hr. The Peripheral Smear indicates mild lymphocytosis, suggesting a viral infection. These findings are consistent with a diagnosis of viral fever.', 'Paracetamol 500mg', 'CBC Test','Completed'),
('P00003', 'A00003', 'Migraine-Neurological assessment reveals recurrent unilateral throbbing headaches with photophobia and nausea. Brain MRI (completed 2024-10-15) shows: No acute intracranial hemorrhage, infarct, or mass lesion. Unremarkable brain parenchyma with normal gray-white differentiation. No evidence of venous sinus thrombosis. Mild mucosal thickening in the paranasal sinuses (incidental finding). Normal vascular flow voids and no restricted diffusion. These results exclude structural or vascular causes, supporting a diagnosis of migraine without aura. Baseline labs (CBC, CRP) are normal. Amitriptyline 10mg was initiated for migraine prophylaxis, targeting serotonin modulation and pain pathway regulation.', 'Amitriptyline 10mg', 'Neurological Scan','Completed'),
('P00004', 'A00004', 'Child Vaccination-Routine immunizations (DTaP, IPV, MMR, Varicella) administered per CDC schedule. Vaccination record confirms completion of age-appropriate doses with no reported adverse reactions. Parental counseling provided on expected mild side effects (e.g., fever, injection-site redness) and future booster timelines.', 'Routine Immunization', 'Vaccination Record','Completed'),
('P00005', 'A00005', 'Knee Pain - Arthritis-Physical exam shows bilateral knee tenderness, swelling, and reduced range of motion. X-ray (completed 2023-10-20) reveals: Moderate medial compartment joint space narrowing, marginal osteophytes at the tibial plateau and femoral condyles, subchondral sclerosis, and a small suprapatellar joint effusion. No acute fracture or chondrocalcinosis. These findings confirm osteoarthritis with degenerative changes. Initial labs (CRP 8 mg/L , ESR 20 mm/hr,, normal uric acid) align with non-inflammatory arthritis. Diclofenac Gel prescribed for localized anti-inflammatory and analgesic effects, targeting cyclooxygenase inhibition to reduce synovitis and pain.', 'Diclofenac Gel', 'X-ray Scan','Completed');
 
INSERT INTO LAB_ASSIGN_DATE (PatientID, TestTitle, Date, Time, Description)
VALUES (
    'P00001',
    'Blood Test',
    '2023-12-15',
    '10:30:00',
    'Complete blood count and lipid profile'
);

ALTER TABLE PharmacyTransaction MODIFY TransactionID INT AUTO_INCREMENT;
ALTER TABLE Laboratory MODIFY TestID INT AUTO_INCREMENT;
select * from OTP;
select * from Login;