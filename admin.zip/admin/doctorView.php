<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['diagnosis'])) {
    $appointmentId = $_POST['appointmentId'];
    $patientId = $_POST['patientId'];
    $description = $_POST['description'];
    $medicine = $_POST['medicine'];
    $testTitle = $_POST['testTitle'];
    $status = $_POST['status'];
    
    $sql = "INSERT INTO Diagnosis (PatientID, AppointmentID, Description, Medicine, TestTitle, Status) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $patientId, $appointmentId, $description, $medicine, $testTitle, $status);
    
    if ($stmt->execute()) {
        $success = "Diagnosis recorded successfully!";
    } else {
        $error = "Error: " . $stmt->error;
    }
    
    $stmt->close();
}

$searchTerm = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search'];
    
    $searchSql = "SELECT a.*, p.Name as PatientName, s.Name as StaffName, s.Position 
                 FROM Appointment a 
                 JOIN Patient p ON a.PatientID = p.PatientID 
                 JOIN Staff s ON a.StaffID = s.StaffID 
                 WHERE a.AppointmentID LIKE ? OR p.Name LIKE ? OR s.Name LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("sss", $searchParam, $searchParam, $searchParam);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
    
    $stmt->close();
}

$filterDate = isset($_GET['filter_date']) ? $_GET['filter_date'] : date('Y-m-d');
$filterDoctor = isset($_GET['filter_doctor']) ? $_GET['filter_doctor'] : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor View - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #current-date-time {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        background: #f5f5f5;
        padding: 5px 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    #theme-icon {
        font-size: 20px;
        color: #ffcc00;
        cursor: pointer;
        transition: transform 0.3s ease, color 0.3s ease;
    }

    #theme-icon:hover {
        transform: scale(1.2);
        color: #ffa500;
    }

    .h2 {
        text-align: center;
        display: block;
        margin: 0 auto;
    }

    .sidebar-icon {
        font-size: 22px;
        color: #007bff;
    }

    .sidebar-text {
        font-size: 18px;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link " href="index.php">
                                <i class="fas fa-chart-line me-2 sidebar-icon"></i>
                                <span class="sidebar-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">


                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Doctor View</h1>
                    <div class="d-flex align-items-center">
                        <span id="current-date-time" class="me-3"></span>
                        <i id="theme-icon" class="fas"></i>
                    </div>
                </div>

                <script>
                function updateDateTimeAndTheme() {
                    const currentDate = new Date();
                    let hours = currentDate.getHours();
                    let minutes = currentDate.getMinutes();
                    let day = currentDate.getDate();
                    let month = currentDate.getMonth() + 1;
                    let year = currentDate.getFullYear();

                    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    const dayOfWeek = daysOfWeek[currentDate.getDay()];

                    minutes = minutes < 10 ? '0' + minutes : minutes;

                    const dateString = `${month}/${day}/${year}`;
                    const timeString = `${hours}:${minutes}`;

                    document.getElementById('current-date-time').textContent =
                        `${dayOfWeek}, ${dateString} - ${timeString}`;

                    const themeIcon = document.getElementById('theme-icon');
                    if (hours >= 6 && hours < 18) {
                        themeIcon.classList.remove('fa-moon');
                        themeIcon.classList.add('fa-sun');
                        themeIcon.style.color = 'orange'; // Day icon color
                    } else {
                        themeIcon.classList.remove('fa-sun');
                        themeIcon.classList.add('fa-moon');
                        themeIcon.style.color = 'blue'; // Night icon color
                    }
                }

                setInterval(updateDateTimeAndTheme, 60000);

                updateDateTimeAndTheme();
                </script>

                <ul class="nav nav-tabs mb-4" id="doctorTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="view-tab" data-bs-toggle="tab" data-bs-target="#view"
                            type="button" role="tab" aria-controls="view" aria-selected="true">
                            <i class="fas fa-calendar-alt me-2"></i>Appointments
                        </button>
                    </li>

                </ul>

                <div class="tab-content" id="doctorTabsContent">
                    <!-- Appointments Tab -->
                    <div class="tab-pane fade show active" id="view" role="tabpanel" aria-labelledby="view-tab">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 font-weight-bold text-primary">Appointments</h6>
                                <div class="d-flex gap-2">
                                    <form method="GET" action="" class="d-flex gap-2">
                                        <input type="date" class="form-control" name="filter_date"
                                            value="<?php echo $filterDate; ?>">
                                        <select class="form-select" name="filter_doctor">
                                            <option value="">All Doctors</option>
                                            <?php
                                            $doctorSql = "SELECT StaffID, Name FROM Staff WHERE Position = 'Doctor' ORDER BY Name";
                                            $doctorResult = $conn->query($doctorSql);
                                            if ($doctorResult->num_rows > 0) {
                                                while($row = $doctorResult->fetch_assoc()) {
                                                    $selected = ($row["StaffID"] == $filterDoctor) ? 'selected' : '';
                                                    echo "<option value='" . $row["StaffID"] . "' " . $selected . ">" . $row["Name"] . "</option>";
                                                }
                                            }
                                            ?>
                                        </select>
                                        <button type="submit" class="btn btn-primary">Filter</button>
                                    </form>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Patient</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $appointmentSql = "SELECT a.*, p.Name as PatientName, d.Status as DiagnosisStatus 
                                                            FROM Appointment a 
                                                            JOIN Patient p ON a.PatientID = p.PatientID 
                                                            LEFT JOIN Diagnosis d ON a.AppointmentID = d.AppointmentID 
                                                            WHERE a.Date = ?";
                                            $params = array($filterDate);
                                            
                                            if (!empty($filterDoctor)) {
                                                $appointmentSql .= " AND a.StaffID = ?";
                                                $params[] = $filterDoctor;
                                            }
                                            
                                            $stmt = $conn->prepare($appointmentSql);
                                            if (!empty($filterDoctor)) {
                                                $stmt->bind_param("ss", ...$params);
                                            } else {
                                                $stmt->bind_param("s", ...$params);
                                            }
                                            $stmt->execute();
                                            $appointmentResult = $stmt->get_result();
                                            
                                            if ($appointmentResult->num_rows > 0) {
                                                while($row = $appointmentResult->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["AppointmentID"] . "</td>";
                                                    echo "<td>" . $row["PatientName"] . "</td>";
                                                    echo "<td>" . $row["Date"] . "</td>";
                                                    echo "<td>" . date('h:i A', strtotime($row["Time"])) . "</td>";
                                                    echo "<td>" . ($row["DiagnosisStatus"] ?? 'Pending') . "</td>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='6' class='text-center'>No appointments found</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script>
                $(document).ready(function() {
                    $('.record-diagnosis').click(function() {
                        $('#diagnosis-tab').tab('show');
                        $('#diagnosisAppointmentId').val($(this).data('id'));
                        $('#diagnosisPatientId').val($(this).data('patient'));
                    });

                    $('.view-appointment, .view-diagnosis').click(function() {
                        const id = $(this).data('id');
                        const type = $(this).hasClass('view-appointment') ? 'appointment' : 'diagnosis';

                        $.ajax({
                            url: `get${type.charAt(0).toUpperCase() + type.slice(1)}Details.php`,
                            data: {
                                id: id
                            },
                            success: function(response) {
                                $(`#${type}DetailsContent`).html(response);
                                $(`#${type}DetailsModal`).modal('show');
                            }
                        });
                    });
                });
                </script>
            </main>
        </div>
    </div>
</body>
</html>