<?php
include 'config.php';

$startDate = isset($_GET['start']) ? $_GET['start'] : date('Y-m-d', strtotime('-30 days'));
$endDate = isset($_GET['end']) ? $_GET['end'] : date('Y-m-d');

$transactionSql = "SELECT t.*, p.Name as PatientName, m.MedName 
                  FROM PharmacyTransaction t 
                  JOIN Patient p ON t.PatientID = p.PatientID 
                  JOIN Pharmacy m ON t.MedID = m.MedID 
                  WHERE t.Date BETWEEN ? AND ?
                  ORDER BY t.Date DESC, t.TransactionID DESC";
$stmt = $conn->prepare($transactionSql);
$stmt->bind_param("ss", $startDate, $endDate);
$stmt->execute();
$transactionResult = $stmt->get_result();

$totalSql = "SELECT SUM(TotalBill) as TotalRevenue FROM PharmacyTransaction WHERE Date BETWEEN ? AND ?";
$totalStmt = $conn->prepare($totalSql);
$totalStmt->bind_param("ss", $startDate, $endDate);
$totalStmt->execute();
$totalResult = $totalStmt->get_result();
$totalRow = $totalResult->fetch_assoc();
$totalRevenue = $totalRow['TotalRevenue'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Transactions Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .report-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .report-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .hospital-name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .report-subtitle {
            font-size: 16px;
            color: #555;
        }
        .report-date {
            margin-bottom: 20px;
            text-align: right;
        }
        .section-title {
            margin-top: 30px;
            margin-bottom: 15px;
            font-weight: bold;
            color: #333;
        }
        .summary-box {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .total-revenue {
            font-size: 24px;
            font-weight: bold;
            color: #28a745;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 15px ;
            }
        }
    </style>
</head>
<body>
    <div class="no-print mb-3">
        <form class="row g-3">
            <div class="col-auto">
                <label for="start" class="form-label">Start Date:</label>
                <input type="date" class="form-control" id="start" name="start" value="<?php echo $startDate; ?>">
            </div>
            <div class="col-auto">
                <label for="end" class="form-label">End Date:</label>
                <input type="date" class="form-control" id="end" name="end" value="<?php echo $endDate; ?>">
            </div>
            <div class="col-auto">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="form-control btn btn-primary">Filter</button>
            </div>
        </form>
        <div class="mt-2">
            <button onclick="window.print()" class="btn btn-primary">Print Report</button>
            <button onclick="window.close()" class="btn btn-secondary">Close</button>
        </div>
    </div>
    
    <div class="report-header">
        <div class="report-title">Pharmacy Transactions Report</div>
        <div class="hospital-name">VirtualPuls Hospital</div>
        <div class="report-subtitle">Excellence in Healthcare</div>
    </div>
    
    <div class="report-date">
        <p><strong>Report Period:</strong> <?php echo date('F d, Y', strtotime($startDate)); ?> to <?php echo date('F d, Y', strtotime($endDate)); ?></p>
        <p><strong>Generated On:</strong> <?php echo date('F d, Y H:i:s'); ?></p>
    </div>
    
    <div class="summary-box">
        <h4>Summary</h4>
        <div class="row">
            <div class="col-md-4">
                <p><strong>Total Transactions:</strong> <?php echo $transactionResult->num_rows; ?></p>
            </div>
            <div class="col-md-4">
                <p><strong>Period:</strong> <?php echo date('M d', strtotime($startDate)); ?> - <?php echo date('M d, Y', strtotime($endDate)); ?></p>
            </div>
            <div class="col-md-4">
                <p><strong>Total Revenue:</strong> <span class="total-revenue">Rs.<?php echo number_format($totalRevenue, 2); ?></span></p>
            </div>
        </div>
    </div>
    
    <h4 class="section-title">Transaction Details</h4>
    
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Transaction ID</th>
                    <th>Date</th>
                    <th>Patient</th>
                    <th>Medication</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($transactionResult->num_rows > 0) {
                    while($row = $transactionResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["TransactionID"] . "</td>";
                        echo "<td>" . $row["Date"] . "</td>";
                        echo "<td>" . $row["PatientName"] . "</td>";
                        echo "<td>" . $row["MedName"] . "</td>";
                        echo "<td>" . $row["Qty"] . "</td>";
                        echo "<td>Rs." . number_format($row["UnitPrice"], 2) . "</td>";
                        echo "<td>Rs." . number_format($row["TotalBill"], 2) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>No transactions found for the selected period</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    
    <div class="footer">
        <p>This is a computer-generated report and does not require a physical signature.</p>
        <p>VirtualPuls Hospital - <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>
</body>
</html>