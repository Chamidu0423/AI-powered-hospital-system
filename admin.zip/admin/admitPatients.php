<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patientId = $_POST['patientId'];
    $wardNo = $_POST['wardNo'];
    $bedNo = $_POST['bedNo'];
    $diagnosisId = $_POST['diagnosisId'];
    $staffId = $_POST['staffId'];
    $inDate = $_POST['inDate'];
    
    $staffSql = "SELECT Name, Position FROM Staff WHERE StaffID = ?";
    $staffStmt = $conn->prepare($staffSql);
    $staffStmt->bind_param("s", $staffId);
    $staffStmt->execute();
    $staffResult = $staffStmt->get_result();
    $staffRow = $staffResult->fetch_assoc();
    $wardStaff = $staffRow['Name'];
    $position = $staffRow['Position'];

    $checkBedSql = "SELECT * FROM Ward WHERE BedNo = ? AND WardNo = ? AND OutDate IS NULL";
    $checkBedStmt = $conn->prepare($checkBedSql);
    $checkBedStmt->bind_param("ss", $bedNo, $wardNo);
    $checkBedStmt->execute();
    $checkResult = $checkBedStmt->get_result();

    if ($checkResult->num_rows > 0) {
        $error = "Error: Bed number $bedNo in ward $wardNo is already occupied.";
    } else {
        $sql = "INSERT INTO Ward (WardNo, BedNo, PatientID, InDate, DiagnosisID, WardStaff, StaffID, Position) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssss", $wardNo, $bedNo, $patientId, $inDate, $diagnosisId, $wardStaff, $staffId, $position);
        
        if ($stmt->execute()) {
            $success = "Patient admitted successfully!";
        } else {
            $error = "Error: " . $stmt->error;
        }
        
        $stmt->close();
    }
    $checkBedStmt->close();
}

$searchTerm = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search'];
    
    $searchSql = "SELECT w.WardID, w.WardNo, w.BedNo, w.PatientID, w.InDate, p.Name as PatientName 
                 FROM Ward w 
                 JOIN Patient p ON w.PatientID = p.PatientID 
                 WHERE w.PatientID LIKE ? OR p.Name LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("ss", $searchParam, $searchParam);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
    
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admit Patients - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #current-date-time {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        background: #f5f5f5;
        padding: 5px 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    #theme-icon {
        font-size: 20px;
        color: #ffcc00;
        cursor: pointer;
        transition: transform 0.3s ease, color 0.3s ease;
    }

    #theme-icon:hover {
        transform: scale(1.2);
        color: #ffa500;
    }

    .h2 {
        text-align: center;
        display: block;
        margin: 0 auto;
    }

    .sidebar-icon {
        font-size: 22px;
        color: #007bff;
    }

    .sidebar-text {
        font-size: 18px;
        font-weight: bold;
    }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link " href="index.php">
                                <i class="fas fa-chart-line me-2 sidebar-icon"></i>
                                <span class="sidebar-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Admit Patients</h1>
                    <div class="d-flex align-items-center">
                        <span id="current-date-time" class="me-3"></span>
                        <i id="theme-icon" class="fas"></i>
                    </div>
                </div>

                <script>
                function updateDateTimeAndTheme() {
                    const currentDate = new Date();
                    let hours = currentDate.getHours();
                    let minutes = currentDate.getMinutes();
                    let day = currentDate.getDate();
                    let month = currentDate.getMonth() + 1;
                    let year = currentDate.getFullYear();

                    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    const dayOfWeek = daysOfWeek[currentDate.getDay()];

                    minutes = minutes < 10 ? '0' + minutes : minutes;

                    const dateString = `${month}/${day}/${year}`;
                    const timeString = `${hours}:${minutes}`;

                    document.getElementById('current-date-time').textContent =
                        `${dayOfWeek}, ${dateString} - ${timeString}`;

                    const themeIcon = document.getElementById('theme-icon');
                    if (hours >= 6 && hours < 18) {
                        themeIcon.classList.remove('fa-moon');
                        themeIcon.classList.add('fa-sun');
                        themeIcon.style.color = 'orange';
                    } else {
                        themeIcon.classList.remove('fa-sun');
                        themeIcon.classList.add('fa-moon');
                        themeIcon.style.color = 'blue';
                    }
                }

                setInterval(updateDateTimeAndTheme, 60000);
                updateDateTimeAndTheme();
                </script>

                <div class="row">
                    <!-- Admission Form -->
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Patient Admission Form</h6>
                            </div>
                            <div class="card-body">
                                <?php if (isset($success)): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo $success; ?>
                                </div>
                                <?php endif; ?>

                                <?php if (isset($error)): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $error; ?>
                                </div>
                                <?php endif; ?>

                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label for="patientId" class="form-label">Patient</label>
                                        <select class="form-select" id="patientId" name="patientId" required>
                                            <option value="">Select Patient</option>
                                            <?php
                                        $patientSql = "SELECT PatientID, Name FROM Patient ORDER BY Name";
                                        $patientResult = $conn->query($patientSql);
                                        
                                        if ($patientResult->num_rows > 0) {
                                            while($row = $patientResult->fetch_assoc()) {
                                                echo "<option value='" . $row["PatientID"] . "'>" . $row["Name"] . " (" . $row["PatientID"] . ")</option>";
                                            }
                                        }
                                        ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="diagnosisId" class="form-label">Diagnosis</label>
                                        <select class="form-select" id="diagnosisId" name="diagnosisId" required>
                                            <option value="">Select Diagnosis</option>
                                            <!-- Options will be populated based on the selected patient -->
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="wardStatus" class="form-label">Ward Status</label>
                                        <input type="text" id="wardStatus" class="form-control" value="N/A" readonly
                                            style="background-color: #f8f9fa;">
                                    </div>

                                    <div class="mb-3">
                                        <label for="wardNo" class="form-label">Ward Number</label>
                                        <select class="form-control" id="wardNo" name="wardNo" required>
                                            <option value="">Select Ward</option>
                                            <!-- Ward options will be dynamically loaded here -->
                                        </select>
                                    </div>


                                    <input type="hidden" id="bedNo" name="bedNo" value="">



                                    <div class="mb-3">
                                        <label for="bedCount" class="form-label">Available Beds</label>
                                        <span id="bedCount" class="form-text">Select a ward to see available beds</span>
                                    </div>

                                    <div class="mb-3">
                                        <label for="assignedBed" class="form-label">Assigned Bed</label>
                                        <input type="text" id="assignedBed" class="form-control"
                                            placeholder="Click Auto Assign Bed" readonly>
                                    </div>

                                    <div class="mb-3">
                                        <button type="button" id="assignBedBtn" class="btn btn-primary">
                                            Auto Assign Bed
                                        </button>
                                    </div>

                                    <script>
                                    // Dummy data for wards (each with 50 total beds)
                                    const wards = [{
                                            WardNo: 'Ward-01',
                                            wardName: 'Gadinogy',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-02',
                                            wardName: 'Cardiology',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-03',
                                            wardName: 'Neurology',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-04',
                                            wardName: 'Orthopedics',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-05',
                                            wardName: 'Pediatrics',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-06',
                                            wardName: 'Emergency',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-07',
                                            wardName: 'ICU',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-08',
                                            wardName: 'Surgical',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-09',
                                            wardName: 'Maternity',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        },
                                        {
                                            WardNo: 'Ward-10',
                                            wardName: 'Urology',
                                            totalBeds: 50,
                                            reservedBeds: []
                                        }
                                    ];

                                    // Dynamically load wards into the dropdown
                                    const wardSelect = document.getElementById('wardNo');
                                    wards.forEach(ward => {
                                        const option = document.createElement('option');
                                        option.value = ward.WardNo; // Use WardNo for the selection
                                        option.textContent =
                                            `${ward.WardNo} (${ward.wardName})`; // Display ward number and name
                                        wardSelect.appendChild(option);
                                    });

                                    // Function to update the available bed count
                                    function updateAvailableBeds(ward) {
                                        const availableBedsCount = ward.totalBeds - ward.reservedBeds.length;
                                        document.getElementById('bedCount').textContent =
                                            `Available Beds: ${availableBedsCount}`;

                                        // If all beds are occupied, show "Beds Over"
                                        if (availableBedsCount === 0) {
                                            document.getElementById('bedCount').textContent = 'Beds Over';
                                        }
                                    }

                                    // Event listener to update available beds when a ward is selected
                                    wardSelect.addEventListener('change', function() {
                                        const selectedWardNo = this.value;
                                        const selectedWard = wards.find(ward => ward.WardNo === selectedWardNo);

                                        if (selectedWard) {
                                            // Update available beds count and show
                                            updateAvailableBeds(selectedWard);
                                        } else {
                                            document.getElementById('bedCount').textContent =
                                                'Select a ward to see available beds.';
                                        }
                                    });

                                    // Event listener to automatically assign beds
                                    document.getElementById('assignBedBtn').addEventListener('click', function(e) {
                                        e.preventDefault();
                                        const wardNo = document.getElementById('wardNo').value;
                                        const selectedWard = wards.find(ward => ward.WardNo === wardNo);

                                        if (!selectedWard) {
                                            alert('Please select a ward first.');
                                            return;
                                        }

                                        if (selectedWard.reservedBeds.length >= selectedWard.totalBeds) {
                                            alert('All beds are occupied!');
                                            return;
                                        }

                                        // Find first available bed
                                        for (let i = 1; i <= selectedWard.totalBeds; i++) {
                                            if (!selectedWard.reservedBeds.includes(i)) {
                                                selectedWard.reservedBeds.push(i);
                                                const assignedBed = `B${i}`;

                                                // Update both display and hidden form field
                                                document.getElementById('assignedBed').value = assignedBed;
                                                document.getElementById('bedNo').value = assignedBed;

                                                alert(`Assigned Bed: ${assignedBed}`);
                                                updateAvailableBeds(selectedWard);
                                                break;
                                            }
                                        }
                                    });
                                    </script>


                                    <div class="mb-3">
                                        <label for="staffId" class="form-label">Attending Staff</label>
                                        <select class="form-select" id="staffId" name="staffId" required>
                                            <option value="">Select Staff</option>
                                            <?php
                                        $staffSql = "SELECT StaffID, Name, Position FROM Staff WHERE Position IN ('Doctor', 'Nurse') ORDER BY Position, Name";
                                        $staffResult = $conn->query($staffSql);
                                        
                                        if ($staffResult->num_rows > 0) {
                                            while($row = $staffResult->fetch_assoc()) {
                                                echo "<option value='" . $row["StaffID"] . "'>" . $row["Name"] . " (" . $row["Position"] . ")</option>";
                                            }
                                        }
                                        ?>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="inDate" class="form-label">Admission Date</label>
                                        <input type="date" class="form-control" id="inDate" name="inDate"
                                            value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>

                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">Admit Patient</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Search and Results -->
                    <div class="col-lg-6">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Search Admitted Patients</h6>
                            </div>
                            <div class="card-body">
                                <form method="GET" action="">
                                    <div class="search-container mb-4">
                                        <input type="text" class="form-control" name="search"
                                            placeholder="Search by Patient ID or Name"
                                            value="<?php echo $searchTerm; ?>">
                                        <button type="submit" class="btn btn-primary search-icon">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Ward ID</th>
                                                <th>Ward No</th>
                                                <th>Bed No</th>
                                                <th>Patient</th>
                                                <th>Admitted</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($searchResults) && empty($searchTerm)): ?>
                                            <?php
                                            $wardSql = "SELECT w.WardID, w.WardNo, w.BedNo, w.PatientID, w.InDate, p.Name as PatientName 
                                                        FROM Ward w 
                                                        JOIN Patient p ON w.PatientID = p.PatientID 
                                                        WHERE w.OutDate IS NULL 
                                                        ORDER BY w.InDate DESC LIMIT 10";
                                            $wardResult = $conn->query($wardSql);
                                            
                                            if ($wardResult->num_rows > 0) {
                                                while($row = $wardResult->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row["WardID"] . "</td>";
                                                    echo "<td>" . $row["WardNo"] . "</td>";
                                                    echo "<td>" . $row["BedNo"] . "</td>";
                                                    echo "<td>" . $row["PatientName"] . " (" . $row["PatientID"] . ")</td>";
                                                    echo "<td>" . $row["InDate"] . "</td>";
                                                    echo "<td>
                                                            <button class='btn btn-sm btn-info view-ward' data-id='" . $row["WardID"] . "'>
                                                                <i class='fas fa-eye'></i>
                                                            </button>
                                                            <button class='btn btn-sm btn-success discharge-patient' data-id='" . $row["WardID"] . "'>
                                                            <i class='fas fa-sign-out-alt'></i>
                                                                </button>
                                                        </td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='6' class='text-center'>No admitted patients found</td></tr>";
                                            }
                                        ?>
                                            <?php elseif (!empty($searchResults)): ?>
                                            <?php foreach ($searchResults as $ward): ?>
                                            <tr>
                                                <td><?php echo $ward["WardID"]; ?></td>
                                                <td><?php echo $ward["WardNo"]; ?></td>
                                                <td><?php echo $ward["BedNo"]; ?></td>
                                                <td><?php echo $ward["PatientName"]; ?>
                                                    (<?php echo $ward["PatientID"]; ?>)</td>
                                                <td><?php echo $ward["InDate"]; ?></td>
                                                <td>
                                                    <button class='btn btn-sm btn-info view-ward'
                                                        data-id='<?php echo $ward["WardID"]; ?>'>
                                                        <i class='fas fa-eye'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-success discharge-patient'
                                                        data-id='<?php echo $ward["WardID"]; ?>'>
                                                        <i class='fas fa-sign-out-alt'></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center">No results found for
                                                    "<?php echo $searchTerm; ?>"</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Ward Details Modal -->
                <div class="modal fade" id="wardDetailsModal" tabindex="-1" aria-labelledby="wardDetailsModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="wardDetailsModalLabel">Ward Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="wardDetailsContent">
                                <!-- Ward details will be loaded here -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Discharge Modal -->
                <div class="modal fade" id="dischargeModal" tabindex="-1" aria-labelledby="dischargeModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="dischargeModalLabel">Discharge Patient</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="dischargeForm">
                                    <input type="hidden" id="wardNumber" name="wardNumber">
                                    <div class="mb-3">
                                        <label for="outDate" class="form-label">Discharge Date</label>
                                        <input type="date" class="form-control" id="outDate" name="outDate"
                                            value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                </form>
                                <p>Are you sure you want to discharge this patient?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-success" id="confirmDischarge">Confirm
                                    Discharge</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // View ward details
        $('.view-ward').click(function() {
            var wardID = $(this).data('id');

            // AJAX to get ward details
            $.ajax({
                url: 'getWardDetails.php',
                type: 'GET',
                data: {
                    id: wardID
                },
                success: function(response) {
                    $('#wardDetailsContent').html(response);
                    $('#wardDetailsModal').modal('show');
                },
                error: function() {
                    alert('Error fetching ward details');
                }
            });
        });

        // Discharge patient
        $('.discharge-patient').click(function() {
            var wardID = $(this).data('id');
            $('#wardNumber').val(wardID);
            $('#dischargeModal').modal('show');
        });

        // Confirm discharge
        $('#confirmDischarge').click(function() {
            var wardID = $('#wardNumber').val();
            var outDate = $('#outDate').val();

            // AJAX request to discharge patient
            $.ajax({
                url: 'dischargePatient.php',
                type: 'POST',
                data: {
                    wardID: wardID,
                    outDate: outDate
                },
                success: function(response) {
                    $('#dischargeModal').modal('hide');
                    location.reload();
                },
                error: function() {
                    alert('Error discharging patient');
                }
            });
        });
    });

    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>

    <script>
    document.getElementById('patientId').addEventListener('change', function() {
        const patientId = this.value;

        // AJAX request to fetch the diagnoses based on the selected patient
        $.ajax({
            url: 'getDiagnoses.php',
            type: 'POST',
            data: {
                patientId: patientId
            },
            success: function(response) {
                const diagnosisSelect = document.getElementById('diagnosisId');
                diagnosisSelect.innerHTML =
                    '<option value="">Select Diagnosis</option>';

                const data = JSON.parse(response);
                data.forEach(function(diagnosis) {
                    const option = document.createElement('option');
                    option.value = diagnosis.DiagnosisID;
                    option.textContent = diagnosis.Description;
                    diagnosisSelect.appendChild(option);
                });
            },
            error: function() {
                alert('Error fetching diagnoses');
            }
        });
    });

    document.getElementById('diagnosisId').addEventListener('change', function() {
        const diagnosisId = this.value;

        $.ajax({
            url: 'getWardStatus.php', 
            type: 'POST',
            data: {
                diagnosisId: diagnosisId
            },
            success: function(response) {
                const data = JSON.parse(response);
                const wardStatusField = document.getElementById('wardStatus');
                wardStatusField.value = data.wardStatus || 'N/A'; // Update the ward status input

                // Apply color coding based on ward status
                if (data.wardStatus === 'Pre-Admit') {
                    wardStatusField.style.backgroundColor = 'blue';
                    wardStatusField.style.color = 'white';
                } else if (data.wardStatus === 'Admit') {
                    wardStatusField.style.backgroundColor = 'red';
                    wardStatusField.style.color = 'white';
                } else if (data.wardStatus === 'Discharge') {
                    wardStatusField.style.backgroundColor = 'green';
                    wardStatusField.style.color = 'white';
                } else {
                    wardStatusField.style.backgroundColor = '#f8f9fa'; // Default color for N/A
                    wardStatusField.style.color = 'black';
                }
            },
            error: function() {
                alert('Error fetching ward status');
            }
        });
    });
    </script>
</body>

</html>