<?php
include 'config.php';

if (isset($_POST['appointment_id'])) {
    $appointmentId = $_POST['appointment_id'];

    $sql = "DELETE FROM Appointment WHERE AppointmentID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $appointmentId);

    if ($stmt->execute()) {
        echo "Appointment deleted successfully!";
    } else {
        echo "Error deleting appointment: " . $conn->error;
    }
}
?>