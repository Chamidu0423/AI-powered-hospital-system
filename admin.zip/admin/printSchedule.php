<?php
include 'config.php';

// Get filter parameters
$filterDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$filterDoctor = isset($_GET['doctor']) ? $_GET['doctor'] : '';

// Get doctor name if doctor filter is applied
$doctorName = '';
if (!empty($filterDoctor)) {
    $doctorSql = "SELECT Name, Criteria FROM Staff WHERE StaffID = ?";
    $doctorStmt = $conn->prepare($doctorSql);
    $doctorStmt->bind_param("s", $filterDoctor);
    $doctorStmt->execute();
    $doctorResult = $doctorStmt->get_result();
    if ($doctorResult->num_rows > 0) {
        $doctorRow = $doctorResult->fetch_assoc();
        $doctorName = $doctorRow['Name'] . ' (' . $doctorRow['Criteria'] . ')';
    }
}

// Get appointments
$appointmentSql = "SELECT a.*, p.Name as PatientName, s.Name as StaffName, s.Position, s.Criteria 
                  FROM Appointment a 
                  JOIN Patient p ON a.PatientID = p.PatientID 
                  JOIN Staff s ON a.StaffID = s.StaffID 
                  WHERE a.Date = ?";

if (!empty($filterDoctor)) {
    $appointmentSql .= " AND a.StaffID = ?";
    $stmt = $conn->prepare($appointmentSql);
    $stmt->bind_param("ss", $filterDate, $filterDoctor);
} else {
    $stmt = $conn->prepare($appointmentSql);
    $stmt->bind_param("s", $filterDate);
}

$stmt->execute();
$appointmentResult = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Schedule - <?php echo $filterDate; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .schedule-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .schedule-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .hospital-name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .schedule-subtitle {
            font-size: 16px;
            color: #555;
        }
        .schedule-date {
            margin-bottom: 20px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="no-print mb-3">
        <button onclick="window.print()" class="btn btn-primary">Print Schedule</button>
        <button onclick="window.close()" class="btn btn-secondary">Close</button>
    </div>
    
    <div class="schedule-header">
        <div class="schedule-title">Appointment Schedule</div>
        <div class="hospital-name">VirtualPuls Hospital</div>
        <div class="schedule-subtitle">Excellence in Healthcare</div>
    </div>
    
    <div class="schedule-date">
        <p>Date: <?php echo date('F d, Y', strtotime($filterDate)); ?></p>
        <?php if (!empty($doctorName)): ?>
        <p>Doctor: <?php echo $doctorName; ?></p>
        <?php endif; ?>
    </div>
    
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Patient ID</th>
                    <th>Patient Name</th>
                    <?php if (empty($filterDoctor)): ?>
                    <th>Doctor</th>
                    <th>Specialty</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($appointmentResult->num_rows > 0) {
                    while($row = $appointmentResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . date('h:i A', strtotime($row["Time"])) . "</td>";
                        echo "<td>" . $row["PatientID"] . "</td>";
                        echo "<td>" . $row["PatientName"] . "</td>";
                        if (empty($filterDoctor)) {
                            echo "<td>" . $row["StaffName"] . "</td>";
                            echo "<td>" . $row["Criteria"] . "</td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    $colspan = empty($filterDoctor) ? 5 : 3;
                    echo "<tr><td colspan='" . $colspan . "' class='text-center'>No appointments scheduled for this date</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    
    <div class="footer">
        <p>This is a computer-generated schedule and does not require a physical signature.</p>
        <p>VirtualPuls Hospital - <?php echo date('Y-m-d H:i:s'); ?></p>
    </div>
</body>
</html>