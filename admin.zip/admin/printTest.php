<?php
include 'config.php';

if (isset($_GET['id'])) {
    $testId = $_GET['id'];
    
    $sql = "SELECT l.*, p.Name as PatientName, p.PatientID, p.NIC, p.Gender, p.DOB, p.ContactNumber,
                  s.Name as StaffName, s.Position, d.Description as DiagnosisDescription 
           FROM Laboratory l 
           JOIN Patient p ON l.PatientID = p.PatientID 
           JOIN Staff s ON l.StaffID = s.StaffID 
           JOIN Diagnosis d ON l.DiagnosisID = d.DiagnosisID 
           WHERE l.TestID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $testId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $test = $result->fetch_assoc();
        
        // Calculate age from DOB
        $dob = new DateTime($test['DOB']);
        $now = new DateTime();
        $age = $now->diff($dob)->y;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Report - <?php echo $test['TestID']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .report-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #333;
        }
        .report-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .hospital-name {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .report-subtitle {
            font-size: 16px;
            color: #555;
        }
        .patient-info {
            margin-bottom: 20px;
        }
        .test-results {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #777;
        }
        .signature {
            margin-top: 50px;
            border-top: 1px solid #333;
            width: 200px;
            text-align: center;
            padding-top: 5px;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print mb-3">
            <button onclick="window.print()" class="btn btn-primary">Print Report</button>
            <button onclick="window.close()" class="btn btn-secondary">Close</button>
        </div>
        
        <div class="report-header">
            <div class="report-title">Laboratory Test Report</div>
            <div class="hospital-name">VirtualPuls Hospital</div>
            <div class="report-subtitle">Excellence in Healthcare</div>
        </div>
        
        <div class="row">
            <div class="col-md-6 patient-info">
                <h5>Patient Information</h5>
                <table class="table table-bordered">
                    <tr>
                        <th>Patient Name</th>
                        <td><?php echo $test['PatientName']; ?></td>
                    </tr>
                    <tr>
                        <th>Patient ID</th>
                        <td><?php echo $test['PatientID']; ?></td>
                    </tr>
                    <tr>
                        <th>NIC</th>
                        <td><?php echo $test['NIC']; ?></td>
                    </tr>
                    <tr>
                        <th>Gender</th>
                        <td><?php echo $test['Gender']; ?></td>
                    </tr>
                    <tr>
                        <th>Age</th>
                        <td><?php echo $age; ?> years</td>
                    </tr>
                    <tr>
                        <th>Contact</th>
                        <td><?php echo $test['ContactNumber']; ?></td>
                    </tr>
                </table>
            </div>
            
            <div class="col-md-6">
                <h5>Test Information</h5>
                <table class="table table-bordered">
                    <tr>
                        <th>Test ID</th>
                        <td><?php echo $test['TestID']; ?></td>
                    </tr>
                    <tr>
                        <th>Test Title</th>
                        <td><?php echo $test['TestTitle']; ?></td>
                    </tr>
                    <tr>
                        <th>Test Date</th>
                        <td><?php echo $test['Date']; ?></td>
                    </tr>
                    <tr>
                        <th>Diagnosis ID</th>
                        <td><?php echo $test['DiagnosisID']; ?></td>
                    </tr>
                    <tr>
                        <th>Lab Technician</th>
                        <td><?php echo $test['StaffName']; ?></td>
                    </tr>
                    <tr>
                        <th>Position</th>
                        <td><?php echo $test['Position']; ?></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <h5>Diagnosis</h5>
                <p><?php echo $test['DiagnosisDescription']; ?></p>
                
                <h5>Test Results</h5>
                <div class="test-results">
                    <?php echo nl2br($test['TestResults']); ?>
                </div>
            </div>
        </div>
        
        <div class="row mt-5">
            <div class="col-6">
                <div class="signature">
                    Lab Technician Signature
                </div>
            </div>
            <div class="col-6 text-end">
                <div class="signature" style="margin-left: auto;">
                    Doctor's Signature
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>This is a computer-generated report and does not require a physical signature.</p>
            <p>VirtualPuls Hospital - <?php echo date('Y-m-d H:i:s'); ?></p>
        </div>
    </div>
</body>
</html>
<?php
    } else {
        echo '<div class="alert alert-danger">Test record not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>