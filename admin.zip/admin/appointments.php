<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patientId = $_POST['patientId'];
    $staffId = $_POST['staffId'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    
    $sql = "INSERT INTO Appointment (PatientID, StaffID, Date, Time) 
            VALUES (?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $patientId, $staffId, $date, $time);
    
    if ($stmt->execute()) {
        $success = "Appointment scheduled successfully!";
    } else {
        $error = "Error: " . $stmt->error;
    }
    
    $stmt->close();
}

$searchTerm = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search'];
    
    $searchSql = "SELECT a.*, p.Name as PatientName, s.Name as StaffName, s.Position 
                 FROM Appointment a 
                 JOIN Patient p ON a.PatientID = p.PatientID 
                 JOIN Staff s ON a.StaffID = s.StaffID 
                 WHERE a.AppointmentID LIKE ? OR p.Name LIKE ? OR s.Name LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("sss", $searchParam, $searchParam, $searchParam);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
    
    $stmt->close();
}

$timeSlots = [
    '08:00:00', '08:30:00', '09:00:00', '09:30:00', '10:00:00', '10:30:00',
    '11:00:00', '11:30:00', '13:00:00', '13:30:00', '14:00:00', '14:30:00',
    '15:00:00', '15:30:00', '16:00:00', '16:30:00'
];

$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$selectedDoctor = isset($_GET['doctor']) ? $_GET['doctor'] : '';

$bookedSlots = [];
if (!empty($selectedDoctor)) {
    $bookedSlotsSql = "SELECT Time FROM Appointment WHERE Date = ? AND StaffID = ?";
    $bookedSlotsStmt = $conn->prepare($bookedSlotsSql);
    $bookedSlotsStmt->bind_param("ss", $selectedDate, $selectedDoctor);
    $bookedSlotsStmt->execute();
    $bookedSlotsResult = $bookedSlotsStmt->get_result();
    
    while ($row = $bookedSlotsResult->fetch_assoc()) {
        $bookedSlots[] = $row['Time'];
    }
    
    $bookedSlotsStmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #current-date-time {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        background: #f5f5f5;
        padding: 5px 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    #theme-icon {
        font-size: 20px;
        color: #ffcc00;
        cursor: pointer;
        transition: transform 0.3s ease, color 0.3s ease;
    }

    #theme-icon:hover {
        transform: scale(1.2);
        color: #ffa500;
    }

    .h2 {
        text-align: center;
        display: block;
        margin: 0 auto;
    }

    .sidebar-icon {
        font-size: 22px;
        color: #007bff;
    }

    .sidebar-text {
        font-size: 18px;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link " href="index.php">
                                <i class="fas fa-chart-line me-2 sidebar-icon"></i>
                                <span class="sidebar-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>

                    </ul>
                </div>
            </div>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Appointments</h1>
                    <div class="d-flex align-items-center">
                        <span id="current-date-time" class="me-3"></span>
                        <i id="theme-icon" class="fas"></i>
                    </div>
                </div>

                <script>
                function updateDateTimeAndTheme() {
                    const currentDate = new Date();
                    let hours = currentDate.getHours();
                    let minutes = currentDate.getMinutes();
                    let day = currentDate.getDate();
                    let month = currentDate.getMonth() + 1; 
                    let year = currentDate.getFullYear();

                    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    const dayOfWeek = daysOfWeek[currentDate.getDay()];

                    minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if minutes are less than 10

                    const dateString = `${month}/${day}/${year}`;
                    const timeString = `${hours}:${minutes}`;

                    document.getElementById('current-date-time').textContent =
                        `${dayOfWeek}, ${dateString} - ${timeString}`;

                    // Change the icon and theme based on the time
                    const themeIcon = document.getElementById('theme-icon');
                    if (hours >= 6 && hours < 18) {
                        // Day time (6 AM to 6 PM)
                        themeIcon.classList.remove('fa-moon');
                        themeIcon.classList.add('fa-sun');
                        themeIcon.style.color = 'orange'; // Day icon color
                    } else {
                        // Night time (6 PM to 6 AM)
                        themeIcon.classList.remove('fa-sun');
                        themeIcon.classList.add('fa-moon');
                        themeIcon.style.color = 'blue'; // Night icon color
                    }
                }

                setInterval(updateDateTimeAndTheme, 60000);

                updateDateTimeAndTheme();
                </script>

                <ul class="nav nav-tabs mb-4" id="appointmentTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="schedule-tab" data-bs-toggle="tab"
                            data-bs-target="#schedule" type="button" role="tab" aria-controls="schedule"
                            aria-selected="true">
                            <i class="fas fa-calendar-plus me-2"></i>Schedule Appointment
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="view-tab" data-bs-toggle="tab" data-bs-target="#view" type="button"
                            role="tab" aria-controls="view" aria-selected="false">
                            <i class="fas fa-calendar-alt me-2"></i>View Appointments
                        </button>
                    </li>

                </ul>

                <div class="tab-content" id="appointmentTabsContent">
                    <!-- Schedule Appointment Tab -->
                    <div class="tab-pane fade show active" id="schedule" role="tabpanel" aria-labelledby="schedule-tab">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Schedule New Appointment</h6>
                                    </div>
                                    <div class="card-body">
                                        <?php if (isset($success)): ?>
                                        <div class="alert alert-success" role="alert">
                                            <?php echo $success; ?>
                                        </div>
                                        <?php endif; ?>

                                        <?php if (isset($error)): ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?php echo $error; ?>
                                        </div>
                                        <?php endif; ?>

                                        <form method="POST" action="">
                                            <div class="mb-3">
                                                <label for="patientId" class="form-label">Patient</label>
                                                <select class="form-select" id="patientId" name="patientId" required>
                                                    <option value="">Select Patient</option>
                                                    <?php
                                                    $patientSql = "SELECT PatientID, Name FROM Patient ORDER BY Name";
                                                    $patientResult = $conn->query($patientSql);
                                                    
                                                    if ($patientResult->num_rows > 0) {
                                                        while($row = $patientResult->fetch_assoc()) {
                                                            echo "<option value='" . $row["PatientID"] . "'>" . $row["Name"] . " (" . $row["PatientID"] . ")</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label for="staffId" class="form-label">Doctor</label>
                                                <select class="form-select" id="staffId" name="staffId" required>
                                                    <option value="">Select Doctor</option>
                                                    <?php
                                                    $doctorSql = "SELECT StaffID, Name, Criteria FROM Staff WHERE Position = 'Doctor' ORDER BY Name";
                                                    $doctorResult = $conn->query($doctorSql);
                                                    
                                                    if ($doctorResult->num_rows > 0) {
                                                        while($row = $doctorResult->fetch_assoc()) {
                                                            $selected = ($row["StaffID"] == $selectedDoctor) ? 'selected' : '';
                                                            echo "<option value='" . $row["StaffID"] . "' " . $selected . ">" . $row["Name"] . " (" . $row["Criteria"] . ")</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label for="date" class="form-label">Appointment Date</label>
                                                <input type="date" class="form-control" id="date" name="date"
                                                    value="<?php echo $selectedDate; ?>"
                                                    min="<?php echo date('Y-m-d'); ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label for="time" class="form-label">Appointment Time</label>
                                                <select class="form-select" id="time" name="time" required>
                                                    <option value="">Select Time</option>
                                                    <?php
                                                    foreach ($timeSlots as $slot) {
                                                        $disabled = in_array($slot, $bookedSlots) ? 'disabled' : '';
                                                        $formattedTime = date('h:i A', strtotime($slot));
                                                        echo "<option value='" . $slot . "' " . $disabled . ">" . $formattedTime . "</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="d-grid gap-2">
                                                <button type="submit" class="btn btn-primary">Schedule
                                                    Appointment</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Check Availability</h6>
                                    </div>
                                    <div class="card-body">
                                        <form method="GET" action="">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="doctor" class="form-label">Select Doctor</label>
                                                    <select class="form-select" id="doctor" name="doctor" required>
                                                        <option value="">Select Doctor</option>
                                                        <?php
                                                        $doctorResult->data_seek(0); // Reset result pointer
                                                        if ($doctorResult->num_rows > 0) {
                                                            while($row = $doctorResult->fetch_assoc()) {
                                                                $selected = ($row["StaffID"] == $selectedDoctor) ? 'selected' : '';
                                                                echo "<option value='" . $row["StaffID"] . "' " . $selected . ">" . $row["Name"] . " (" . $row["Criteria"] . ")</option>";
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="date" class="form-label">Select Date</label>
                                                    <input type="date" class="form-control" id="date" name="date"
                                                        value="<?php echo $selectedDate; ?>"
                                                        min="<?php echo date('Y-m-d'); ?>" required>
                                                </div>
                                            </div>
                                            <div class="d-grid gap-2">
                                                <button type="submit" class="btn btn-primary">Check
                                                    Availability</button>
                                            </div>
                                        </form>

                                        <?php if (!empty($selectedDoctor)): ?>
                                        <div class="mt-4">
                                            <h6 class="font-weight-bold">Available Time Slots for
                                                <?php echo date('F d, Y', strtotime($selectedDate)); ?></h6>
                                            <div class="time-slots">
                                                <?php
                                                foreach ($timeSlots as $slot) {
                                                    $isBooked = in_array($slot, $bookedSlots);
                                                    $slotClass = $isBooked ? 'time-slot disabled' : 'time-slot';
                                                    $formattedTime = date('h:i A', strtotime($slot));
                                                    echo "<div class='" . $slotClass . "' data-time='" . $slot . "'>" . $formattedTime . "</div>";
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- View Appointments Tab -->
                    <div class="tab-pane fade" id="view" role="tabpanel" aria-labelledby="view-tab">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 font-weight-bold text-primary">Appointment Schedule</h6>
                                <button class="btn btn-sm btn-outline-primary" id="printSchedule">
                                    <i class="fas fa-print me-1"></i> Print Schedule
                                </button>
                            </div>
                            <div class="card-body">
                                <form method="GET" action="" class="mb-4">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="search-container">
                                                <input type="text" class="form-control" name="search"
                                                    placeholder="Search by ID, Patient or Doctor"
                                                    value="<?php echo $searchTerm; ?>">
                                                <button type="submit" class="btn btn-primary search-icon">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <input type="date" class="form-control" name="filter_date"
                                                value="<?php echo isset($_GET['filter_date']) ? $_GET['filter_date'] : date('Y-m-d'); ?>">
                                        </div>
                                        <div class="col-md-2">
                                            <select class="form-select" name="filter_doctor">
                                                <option value="">All Doctors</option>
                                                <?php
                                                $doctorResult->data_seek(0); // Reset result pointer
                                                if ($doctorResult->num_rows > 0) {
                                                    while($row = $doctorResult->fetch_assoc()) {
                                                        $selected = (isset($_GET['filter_doctor']) && $row["StaffID"] == $_GET['filter_doctor']) ? 'selected' : '';
                                                        echo "<option value='" . $row["StaffID"] . "' " . $selected . ">" . $row["Name"] . "</option>";
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                                        </div>
                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Patient</th>
                                                <th>Doctor</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($searchResults) && empty($searchTerm)): ?>
                                            <?php
                                                $filterDate = isset($_GET['filter_date']) ? $_GET['filter_date'] : date('Y-m-d');
                                                $filterDoctor = isset($_GET['filter_doctor']) ? $_GET['filter_doctor'] : '';
                                                
                                                $appointmentSql = "SELECT a.*, p.Name as PatientName, s.Name as StaffName, s.Position 
                                                                FROM Appointment a 
                                                                JOIN Patient p ON a.PatientID = p.PatientID 
                                                                JOIN Staff s ON a.StaffID = s.StaffID 
                                                                WHERE a.Date = ?";
                                                
                                                if (!empty($filterDoctor)) {
                                                    $appointmentSql .= " AND a.StaffID = ?";
                                                    $stmt = $conn->prepare($appointmentSql);
                                                    $stmt->bind_param("ss", $filterDate, $filterDoctor);
                                                } else {
                                                    $stmt = $conn->prepare($appointmentSql);
                                                    $stmt->bind_param("s", $filterDate);
                                                }
                                                
                                                $stmt->execute();
                                                $appointmentResult = $stmt->get_result();
                                                
                                                if ($appointmentResult->num_rows > 0) {
                                                    while($row = $appointmentResult->fetch_assoc()) {
                                                        echo "<tr>";
                                                        echo "<td>" . $row["AppointmentID"] . "</td>";
                                                        echo "<td>" . $row["PatientName"] . "</td>";
                                                        echo "<td>" . $row["StaffName"] . " (" . $row["Position"] . ")</td>";
                                                        echo "<td>" . $row["Date"] . "</td>";
                                                        echo "<td>" . date('h:i A', strtotime($row["Time"])) . "</td>";
                                                        echo "<td>
                                                                <button class='btn btn-sm btn-info view-appointment' data-id='" . $row["AppointmentID"] . "'>
                                                                    <i class='fas fa-eye'></i>
                                                                </button>
                                                                
                                                                <button class='btn btn-sm btn-danger delete-appointment' data-id='" . $row["AppointmentID"] . "'>
                                                                    <i class='fas fa-trash'></i>
                                                                </button>
                                                            </td>";
                                                        echo "</tr>";
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='6' class='text-center'>No appointments found for the selected date</td></tr>";
                                                }
                                                ?>
                                            <?php elseif (!empty($searchResults)): ?>
                                            <?php foreach ($searchResults as $appointment): ?>
                                            <tr>
                                                <td><?php echo $appointment["AppointmentID"]; ?></td>
                                                <td><?php echo $appointment["PatientName"]; ?></td>
                                                <td><?php echo $appointment["StaffName"]; ?>
                                                    (<?php echo $appointment["Position"]; ?>)</td>
                                                <td><?php echo $appointment["Date"]; ?></td>
                                                <td><?php echo date('h:i A', strtotime($appointment["Time"])); ?></td>
                                                <td>
                                                    <button class='btn btn-sm btn-info view-appointment'
                                                        data-id='<?php echo $appointment["AppointmentID"]; ?>'>
                                                        <i class='fas fa-eye'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-primary record-diagnosis'
                                                        data-id='<?php echo $appointment["AppointmentID"]; ?>'
                                                        data-patient='<?php echo $appointment["PatientID"]; ?>'>
                                                        <i class='fas fa-stethoscope'></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center">No results found for
                                                    "<?php echo $searchTerm; ?>"</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

                <!-- Appointment Details Modal -->
                <div class="modal fade" id="appointmentDetailsModal" tabindex="-1"
                    aria-labelledby="appointmentDetailsModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="appointmentDetailsModalLabel">Appointment Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="appointmentDetailsContent">
                                <!-- Appointment details will be loaded here -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="printAppointmentBtn">Print</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Diagnosis Details Modal -->
                <div class="modal fade" id="diagnosisDetailsModal" tabindex="-1"
                    aria-labelledby="diagnosisDetailsModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="diagnosisDetailsModalLabel">Diagnosis Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="diagnosisDetailsContent">
                                <!-- Diagnosis details will be loaded here -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="printDiagnosisBtn">Print</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // Time slot selection
        $('.time-slot:not(.disabled)').click(function() {
            var time = $(this).data('time');
            $('#time').val(time);
            $('.time-slot').removeClass('selected');
            $(this).addClass('selected');
        });

        // View appointment details
        $('.view-appointment').click(function() {
            var appointmentId = $(this).data('id');

            // AJAX request to get appointment details
            $.ajax({
                url: 'getAppointmentDetails.php',
                type: 'GET',
                data: {
                    id: appointmentId
                },
                success: function(response) {
                    $('#appointmentDetailsContent').html(response);
                    $('#appointmentDetailsModal').modal('show');
                },
                error: function() {
                    alert('Error fetching appointment details');
                }
            });
        });

        // Record diagnosis
        $('.record-diagnosis').click(function() {
            var appointmentId = $(this).data('id');
            var patientId = $(this).data('patient');

            $('#diagnosisAppointmentId').val(appointmentId);
            $('#diagnosisPatientId').val(patientId);

            // Switch to diagnosis tab
            $('#diagnosis-tab').tab('show');
        });

        // View diagnosis details
        $('.view-diagnosis').click(function() {
            var diagnosisId = $(this).data('id');

            // AJAX request to get diagnosis details
            $.ajax({
                url: 'getDiagnosisDetails.php',
                type: 'GET',
                data: {
                    id: diagnosisId
                },
                success: function(response) {
                    $('#diagnosisDetailsContent').html(response);
                    $('#diagnosisDetailsModal').modal('show');
                },
                error: function() {
                    alert('Error fetching diagnosis details');
                }
            });
        });

        // Print appointment
        $('#printAppointmentBtn').click(function() {
            var appointmentId = $('#appointmentDetailsContent').data('appointment-id');
            if (appointmentId) {
                window.open('printAppointment.php?id=' + appointmentId, '_blank');
            }
        });

        // Print diagnosis
        $('.print-diagnosis, #printDiagnosisBtn').click(function() {
            var diagnosisId = $(this).data('id') || $('#diagnosisDetailsContent').data('diagnosis-id');
            if (diagnosisId) {
                window.open('printDiagnosis.php?id=' + diagnosisId, '_blank');
            }
        });

        // Print schedule
        $('#printSchedule').click(function() {
            var filterDate = $('input[name="filter_date"]').val();
            var filterDoctor = $('select[name="filter_doctor"]').val();
            window.open('printSchedule.php?date=' + filterDate + '&doctor=' + filterDoctor, '_blank');
        });
    });


    $(document).on('click', '.delete-appointment', function() {
        var appointmentId = $(this).data('id');

        if (confirm("Are you sure you want to delete this appointment?")) {
            $.ajax({
                url: 'delete_appointment.php', // Create this PHP file to handle deletion
                type: 'POST',
                data: {
                    appointment_id: appointmentId
                },
                success: function(response) {
                    alert(response);
                    location.reload(); // Refresh the page after deletion
                }
            });
        }
    });
    </script>
</body>

</html>