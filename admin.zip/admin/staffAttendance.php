<?php
include 'config.php';

// Get today's date
$today = date('Y-m-d');

$staffSql = "SELECT StaffID, Name, Position, Attendance FROM Staff ORDER BY Position, Name";
$staffResult = $conn->query($staffSql);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_attendance'])) {
    $conn->begin_transaction();
    
    try {
        foreach ($_POST['attendance'] as $staffId => $attendance) {
            $updateSql = "UPDATE Staff SET Attendance = ? WHERE StaffID = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("ss", $attendance, $staffId);
            $updateStmt->execute();
        }
        
        $conn->commit();
        
        $success = "Attendance updated successfully!";
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Attendance - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #current-date-time {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        background: #f5f5f5;
        padding: 5px 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    #theme-icon {
        font-size: 20px;
        color: #ffcc00;
        cursor: pointer;
        transition: transform 0.3s ease, color 0.3s ease;
    }

    #theme-icon:hover {
        transform: scale(1.2);
        color: #ffa500;
    }

    .h2 {
        text-align: center;
        display: block;
        margin: 0 auto;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="laboratoryManagement.php">
                                <i class="fas fa-flask me-2"></i>Laboratory
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>

                    </ul>
                </div>
            </div>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Staff Attendance</h1>
                    <a href="staffManagement.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Back to Staff Management
                    </a>
                </div>

                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">Daily Attendance Sheet</h6>
                        <div>
                            <span class="me-3">Date: <?php echo date('F d, Y', strtotime($today)); ?></span>
                            <button class="btn btn-sm btn-outline-primary" id="printAttendance">
                                <i class="fas fa-print me-1"></i> Print Attendance
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (isset($success)): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $success; ?>
                        </div>
                        <?php endif; ?>

                        <?php if (isset($error)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $error; ?>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Staff ID</th>
                                            <th>Name</th>
                                            <th>Position</th>
                                            <th>Attendance Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($staffResult->num_rows > 0) {
                                            while($row = $staffResult->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["StaffID"] . "</td>";
                                                echo "<td>" . $row["Name"] . "</td>";
                                                echo "<td>" . $row["Position"] . "</td>";
                                                echo "<td>
                                                        <select class='form-select' name='attendance[" . $row["StaffID"] . "]'>
                                                            <option value='Present' " . ($row["Attendance"] == 'Present' ? 'selected' : '') . ">Present</option>
                                                            <option value='Absent' " . ($row["Attendance"] == 'Absent' ? 'selected' : '') . ">Absent</option>
                                                            <option value='On Leave' " . ($row["Attendance"] == 'On Leave' ? 'selected' : '') . ">On Leave</option>
                                                            <option value='Late' " . ($row["Attendance"] == 'Late' ? 'selected' : '') . ">Late</option>
                                                        </select>
                                                    </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='4' class='text-center'>No staff found</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="d-grid gap-2 col-md-4 mx-auto mt-4">
                                <button type="submit" name="update_attendance" class="btn btn-primary">Update
                                    Attendance</button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // Print attendance
        $('#printAttendance').click(function() {
            window.print();
        });
    });
    </script>
</body>

</html>