<?php
include 'config.php';

if (isset($_POST['patientId'])) {
    $patientId = $_POST['patientId'];
    $diagnosisSql = "SELECT DiagnosisID, Description FROM Diagnosis WHERE PatientID = ?";
    $stmt = $conn->prepare($diagnosisSql);
    $stmt->bind_param("s", $patientId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $diagnoses = [];
    while ($row = $result->fetch_assoc()) {
        $diagnoses[] = $row;
    }
    
    echo json_encode($diagnoses);
    $stmt->close();
}
?>