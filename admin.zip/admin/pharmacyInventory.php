<?php
include 'config.php';

// Process form submission for adding medication
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add') {
    // Get form data
    $medName = $_POST['medName'];
    $description = $_POST['description'];
    $stockInQty = $_POST['stockInQty'];
    $supplier = $_POST['supplier'];
    $price = $_POST['price'];
    $stockInDate = $_POST['stockInDate'];
    
    // Insert data into Pharmacy table
    $sql = "INSERT INTO Pharmacy (MedName, Description, StockInQty, StockInDate, BalanceQty, Supplier, Price) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisssd", $medName, $description, $stockInQty, $stockInDate, $stockInQty, $supplier, $price);
    
    if ($stmt->execute()) {
        $success = "Medication added successfully!";
    } else {
        $error = "Error: " . $stmt->error;
    }
    
    $stmt->close();
}

// Process form submission for dispensing medication
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'dispense') {
    // Get form data
    $medId = $_POST['medId'];
    $patientId = $_POST['patientId'];
    $qty = $_POST['qty'];
    $diagnosisId = $_POST['diagnosisId'];
    $date = $_POST['date'];
    
    // Get medication price
    $priceSql = "SELECT Price, BalanceQty FROM Pharmacy WHERE MedID = ?";
    $priceStmt = $conn->prepare($priceSql);
    $priceStmt->bind_param("s", $medId);
    $priceStmt->execute();
    $priceResult = $priceStmt->get_result();
    $priceRow = $priceResult->fetch_assoc();
    $unitPrice = $priceRow['Price'];
    $balanceQty = $priceRow['BalanceQty'];
    $totalBill = $unitPrice * $qty;
    
    // Check if enough stock is available
    if ($balanceQty < $qty) {
        $dispenseError = "Error: Not enough stock available. Current balance: " . $balanceQty;
    } else {
        // Begin transaction
        $conn->begin_transaction();
        
        try {
            // Insert data into PharmacyTransaction table
            $transactionSql = "INSERT INTO PharmacyTransaction (MedID, Qty, StockOut, PatientID, Date, UnitPrice, TotalBill, DiagnosisID) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            $transactionStmt = $conn->prepare($transactionSql);
            $transactionStmt->bind_param("siissdds", $medId, $qty, $qty, $patientId, $date, $unitPrice, $totalBill, $diagnosisId);
            $transactionStmt->execute();
            
            // Update balance quantity in Pharmacy table
            $newBalance = $balanceQty - $qty;
            $updateSql = "UPDATE Pharmacy SET BalanceQty = ? WHERE MedID = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("is", $newBalance, $medId);
            $updateStmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            $dispenseSuccess = "Medication dispensed successfully!";
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $dispenseError = "Error: " . $e->getMessage();
        }
    }
}

// Search functionality for inventory
$searchTerm = '';
$searchResults = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = $_GET['search'];
    
    $searchSql = "SELECT * FROM Pharmacy WHERE MedID LIKE ? OR MedName LIKE ?";
    $stmt = $conn->prepare($searchSql);
    $searchParam = "%" . $searchTerm . "%";
    $stmt->bind_param("ss", $searchParam, $searchParam);
    $stmt->execute();
    
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $searchResults[] = $row;
    }
    
    $stmt->close();
}

// Get low stock medications
$lowStockSql = "SELECT * FROM Pharmacy WHERE BalanceQty <= 10 ORDER BY BalanceQty ASC";
$lowStockResult = $conn->query($lowStockSql);
$lowStockCount = $lowStockResult->num_rows;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Inventory - VirtualPuls</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #current-date-time {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        background: #f5f5f5;
        padding: 5px 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    #theme-icon {
        font-size: 20px;
        color: #ffcc00;
        cursor: pointer;
        transition: transform 0.3s ease, color 0.3s ease;
    }

    #theme-icon:hover {
        transform: scale(1.2);
        color: #ffa500;
    }

    .h2 {
        text-align: center;
        display: block;
        margin: 0 auto;
    }

    .sidebar-icon {
        font-size: 22px;
        color: #007bff;
    }

    .sidebar-text {
        font-size: 18px;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <img src="logoWithSlogan.png" alt="" style="height: 80%; width: 80%;">
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link " href="index.php">
                                <i class="fas fa-chart-line me-2 sidebar-icon"></i>
                                <span class="sidebar-text">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registerPatient.php">
                                <i class="fas fa-user-plus me-2"></i>Register Patient
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="staffManagement.php">
                                <i class="fas fa-users-cog me-2"></i>Staff Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="appointments.php">
                                <i class="fas fa-calendar-check me-2"></i>Appointments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admitPatients.php">
                                <i class="fas fa-procedures me-2"></i>Admit Patients
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link active" href="pharmacyInventory.php">
                                <i class="fas fa-pills me-2"></i>Pharmacy
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="doctorView.php">
                                <i class="fas fa-user-md me-2"></i>Doctor View
                            </a>
                        </li>

                    </ul>
                </div>
            </div>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Pharmacy Inventory</h1>
                    <?php if ($lowStockCount > 0): ?>
                    <div class="alert alert-warning py-1 px-3 mb-0">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo $lowStockCount; ?> medications are
                        low in stock
                    </div>
                    <?php endif; ?>
                    <!-- Date, Time, and Day Display -->
                    <div class="d-flex align-items-center">
                        <span id="current-date-time" class="me-3"></span>
                        <!-- Day/Night Icon -->
                        <i id="theme-icon" class="fas"></i>
                    </div>
                </div>

                <script>
                function updateDateTimeAndTheme() {
                    // Get the current date and time
                    const currentDate = new Date();
                    let hours = currentDate.getHours();
                    let minutes = currentDate.getMinutes();
                    let day = currentDate.getDate();
                    let month = currentDate.getMonth() + 1; // Months are 0-indexed
                    let year = currentDate.getFullYear();

                    // Day of the week
                    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    const dayOfWeek = daysOfWeek[currentDate.getDay()];

                    minutes = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if minutes are less than 10

                    const dateString = `${month}/${day}/${year}`;
                    const timeString = `${hours}:${minutes}`;

                    // Display date, time, and day of the week
                    document.getElementById('current-date-time').textContent =
                        `${dayOfWeek}, ${dateString} - ${timeString}`;

                    // Change the icon and theme based on the time
                    const themeIcon = document.getElementById('theme-icon');
                    if (hours >= 6 && hours < 18) {
                        // Day time (6 AM to 6 PM)
                        themeIcon.classList.remove('fa-moon');
                        themeIcon.classList.add('fa-sun');
                        themeIcon.style.color = 'orange'; // Day icon color
                    } else {
                        // Night time (6 PM to 6 AM)
                        themeIcon.classList.remove('fa-sun');
                        themeIcon.classList.add('fa-moon');
                        themeIcon.style.color = 'blue'; // Night icon color
                    }
                }

                // Update time, date, and theme every minute
                setInterval(updateDateTimeAndTheme, 60000);

                // Initial call to set the date, time, and theme on page load
                updateDateTimeAndTheme();
                </script>

                <ul class="nav nav-tabs mb-4" id="pharmacyTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="inventory-tab" data-bs-toggle="tab"
                            data-bs-target="#inventory" type="button" role="tab" aria-controls="inventory"
                            aria-selected="true">
                            <i class="fas fa-clipboard-list me-2"></i>Inventory
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="add-medication-tab" data-bs-toggle="tab"
                            data-bs-target="#add-medication" type="button" role="tab" aria-controls="add-medication"
                            aria-selected="false">
                            <i class="fas fa-plus-circle me-2"></i>Add Medication
                        </button>
                    </li>


                </ul>

                <div class="tab-content" id="pharmacyTabsContent">
                    <!-- Inventory Tab -->
                    <div class="tab-pane fade show active" id="inventory" role="tabpanel"
                        aria-labelledby="inventory-tab">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                <h6 class="m-0 font-weight-bold text-primary">Medication Inventory</h6>
                                <button class="btn btn-sm btn-outline-primary" id="printInventory">
                                    <i class="fas fa-print me-1"></i> Print Inventory
                                </button>
                            </div>
                            <div class="card-body">
                                <form method="GET" action="" class="mb-4">
                                    <div class="search-container">
                                        <input type="text" class="form-control" name="search"
                                            placeholder="Search by ID or Name" value="<?php echo $searchTerm; ?>">
                                        <button type="submit" class="btn btn-primary search-icon">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </form>

                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Stock In</th>
                                                <th>Balance</th>
                                                <th>Price</th>
                                                <th>Supplier</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($searchResults) && empty($searchTerm)): ?>
                                            <?php
                                                $inventorySql = "SELECT * FROM Pharmacy ORDER BY MedName";
                                                $inventoryResult = $conn->query($inventorySql);
                                                
                                                if ($inventoryResult->num_rows > 0) {
                                                    while($row = $inventoryResult->fetch_assoc()) {
                                                        $stockClass = ($row["BalanceQty"] <= 10) ? "text-danger fw-bold" : "";
                                                        
                                                        echo "<tr>";
                                                        echo "<td>" . $row["MedID"] . "</td>";
                                                        echo "<td>" . $row["MedName"] . "</td>";
                                                        echo "<td>" . $row["StockInQty"] . "</td>";
                                                        echo "<td class='" . $stockClass . "'>" . $row["BalanceQty"] . "</td>";
                                                        echo "<td>Rs." . number_format($row["Price"], 2) . "</td>";
                                                        echo "<td>" . $row["Supplier"] . "</td>";
                                                        echo "<td>
                                                                <button class='btn btn-sm btn-info view-med' data-id='" . $row["MedID"] . "'>
                                                                    <i class='fas fa-eye'></i>
                                                                </button>
                                                                <button class='btn btn-sm btn-warning restock-med' data-id='" . $row["MedID"] . "' data-name='" . $row["MedName"] . "'>
                                                                    <i class='fas fa-plus'></i>
                                                                </button>
                                                            </td>";
                                                        echo "</tr>";
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='7' class='text-center'>No medications found</td></tr>";
                                                }
                                                ?>
                                            <?php elseif (!empty($searchResults)): ?>
                                            <?php foreach ($searchResults as $med): ?>
                                            <?php $stockClass = ($med["BalanceQty"] <= 10) ? "text-danger fw-bold" : ""; ?>
                                            <tr>
                                                <td><?php echo $med["MedID"]; ?></td>
                                                <td><?php echo $med["MedName"]; ?></td>
                                                <td><?php echo $med["StockInQty"]; ?></td>
                                                <td class="<?php echo $stockClass; ?>"><?php echo $med["BalanceQty"]; ?>
                                                </td>
                                                <td>$<?php echo number_format($med["Price"], 2); ?></td>
                                                <td><?php echo $med["Supplier"]; ?></td>
                                                <td>
                                                    <button class='btn btn-sm btn-info view-med'
                                                        data-id='<?php echo $med["MedID"]; ?>'>
                                                        <i class='fas fa-eye'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-warning restock-med'
                                                        data-id='<?php echo $med["MedID"]; ?>'
                                                        data-name='<?php echo $med["MedName"]; ?>'>
                                                        <i class='fas fa-plus'></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No results found for
                                                    "<?php echo $searchTerm; ?>"</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <?php if ($lowStockCount > 0): ?>
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-danger">Low Stock Alert</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Balance</th>
                                                <th>Supplier</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            while($row = $lowStockResult->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $row["MedID"] . "</td>";
                                                echo "<td>" . $row["MedName"] . "</td>";
                                                echo "<td class='text-danger fw-bold'>" . $row["BalanceQty"] . "</td>";
                                                echo "<td>" . $row["Supplier"] . "</td>";
                                                echo "<td>
                                                        <button class='btn btn-sm btn-warning restock-med' data-id='" . $row["MedID"] . "' data-name='" . $row["MedName"] . "'>
                                                            <i class='fas fa-plus'></i> Restock
                                                        </button>
                                                    </td>";
                                                echo "</tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Add Medication Tab -->
                    <div class="tab-pane fade" id="add-medication" role="tabpanel" aria-labelledby="add-medication-tab">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Add New Medication</h6>
                            </div>
                            <div class="card-body">
                                <?php if (isset($success)): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo $success; ?>
                                </div>
                                <?php endif; ?>

                                <?php if (isset($error)): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $error; ?>
                                </div>
                                <?php endif; ?>

                                <form method="POST" action="">
                                    <input type="hidden" name="action" value="add">

                                    <div class="mb-3">
                                        <label for="medName" class="form-label">Medication Name</label>
                                        <input type="text" class="form-control" id="medName" name="medName" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="description" class="form-label">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="3"
                                            required></textarea>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="stockInQty" class="form-label">Stock Quantity</label>
                                            <input type="number" class="form-control" id="stockInQty" name="stockInQty"
                                                min="1" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="price" class="form-label">Unit Price (RS)</label>
                                            <input type="number" class="form-control" id="price" name="price" min="0.01"
                                                step="0.01" required>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="supplier" class="form-label">Supplier</label>
                                            <input type="text" class="form-control" id="supplier" name="supplier"
                                                required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="stockInDate" class="form-label">Stock In Date</label>
                                            <input type="date" class="form-control" id="stockInDate" name="stockInDate"
                                                value="<?php echo date('Y-m-d'); ?>" required>
                                        </div>
                                    </div>

                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">Add Medication</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>



                </div>

                <!-- Medication Details Modal -->
                <div class="modal fade" id="medicationDetailsModal" tabindex="-1"
                    aria-labelledby="medicationDetailsModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="medicationDetailsModalLabel">Medication Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="medicationDetailsContent">
                                <!-- Medication details will be loaded here -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Restock Modal -->
                <div class="modal fade" id="restockModal" tabindex="-1" aria-labelledby="restockModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="restockModalLabel">Restock Medication</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="restockForm">
                                    <input type="hidden" id="restockMedId" name="medId">
                                    <div class="mb-3">
                                        <label for="restockMedName" class="form-label">Medication</label>
                                        <input type="text" class="form-control" id="restockMedName" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="restockQty" class="form-label">Quantity to Add</label>
                                        <input type="number" class="form-control" id="restockQty" name="qty" min="1"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="restockDate" class="form-label">Restock Date</label>
                                        <input type="date" class="form-control" id="restockDate" name="date"
                                            value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary" id="confirmRestock">Confirm
                                    Restock</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Transaction Details Modal -->
                <div class="modal fade" id="transactionDetailsModal" tabindex="-1"
                    aria-labelledby="transactionDetailsModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="transactionDetailsModalLabel">Transaction Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body" id="transactionDetailsContent">
                                <!-- Transaction details will be loaded here -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" id="printReceiptBtn">Print
                                    Receipt</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // Patient selection changes diagnosis options
        $('#patientId').change(function() {
            var patientId = $(this).val();

            if (patientId) {
                // AJAX request to get diagnoses for this patient
                $.ajax({
                    url: 'getPatientDiagnoses.php',
                    type: 'GET',
                    data: {
                        patientId: patientId
                    },
                    success: function(response) {
                        $('#diagnosisId').html(response);
                    }
                });
            }
        });

        // View medication details
        $('.view-med').click(function() {
            var medId = $(this).data('id');

            // AJAX request to get medication details
            $.ajax({
                url: 'getMedicationDetails.php',
                type: 'GET',
                data: {
                    id: medId
                },
                success: function(response) {
                    $('#medicationDetailsContent').html(response);
                    $('#medicationDetailsModal').modal('show');
                },
                error: function() {
                    alert('Error fetching medication details');
                }
            });
        });

        // Restock medication
        $('.restock-med').click(function() {
            var medId = $(this).data('id');
            var medName = $(this).data('name');

            $('#restockMedId').val(medId);
            $('#restockMedName').val(medName);
            $('#restockModal').modal('show');
        });

        // Confirm restock
        $('#confirmRestock').click(function() {
            var medId = $('#restockMedId').val();
            var qty = $('#restockQty').val();
            var date = $('#restockDate').val();

            // AJAX request to restock medication
            $.ajax({
                url: 'restockMedication.php',
                type: 'POST',
                data: {
                    medId: medId,
                    qty: qty,
                    date: date
                },
                success: function(response) {
                    $('#restockModal').modal('hide');
                    // Reload the page to show updated data
                    location.reload();
                },
                error: function() {
                    alert('Error restocking medication');
                }
            });
        });

        // View transaction details
        $('.view-transaction').click(function() {
            var transactionId = $(this).data('id');

            // AJAX request to get transaction details
            $.ajax({
                url: 'getTransactionDetails.php',
                type: 'GET',
                data: {
                    id: transactionId
                },
                success: function(response) {
                    $('#transactionDetailsContent').html(response);
                    $('#transactionDetailsModal').modal('show');
                },
                error: function() {
                    alert('Error fetching transaction details');
                }
            });
        });

        // Print receipt
        $('.print-receipt').click(function() {
            var transactionId = $(this).data('id');
            window.open('printReceipt.php?id=' + transactionId, '_blank');
        });

        // Print from modal
        $('#printReceiptBtn').click(function() {
            var transactionId = $('#transactionDetailsContent').data('transaction-id');
            if (transactionId) {
                window.open('printReceipt.php?id=' + transactionId, '_blank');
            }
        });

        // Print inventory
        $('#printInventory').click(function() {
            window.open('printInventory.php', '_blank');
        });

        // Print transactions
        $('#printTransactions').click(function() {
            window.open('printTransactions.php', '_blank');
        });
    });


    // delete recorded
    // Listen for the delete button click event
    document.querySelectorAll('.delete-transaction').forEach(button => {
        button.addEventListener('click', function() {
            const transactionId = this.getAttribute('data-id');

            // Confirm the deletion
            if (confirm("Are you sure you want to delete this transaction?")) {
                // Send an AJAX request to delete the transaction
                fetch('deleteTransaction.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            TransactionID: transactionId
                        }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Optionally, remove the row from the table
                            this.closest('tr').remove();
                            alert('Transaction deleted successfully.');
                        } else {
                            alert('Error deleting the transaction.');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error occurred while deleting.');
                    });
            }
        });
    });
    </script>
</body>

</html>