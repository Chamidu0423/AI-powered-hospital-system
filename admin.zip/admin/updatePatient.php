<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patientId = $_POST['patient_id'];
    
    // Get all form data
    $name = $_POST['name'];
    $contactNumber = $_POST['contactNumber'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $nic = $_POST['nic'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $reason = $_POST['reason'];
    $guardianName = $_POST['guardianName'];
    $guardianContact = $_POST['guardianContactNumber'];
    $guardianNic = $_POST['guardianNic'];

    try {
        $sql = "UPDATE Patient SET 
                Name = ?,
                ContactNumber = ?,
                Email = ?,
                Address = ?,
                NIC = ?,
                DOB = ?,
                Gender = ?,
                Reason = ?,
                GuardianName = ?,
                GuardianContactNumber = ?,
                GuardianNIC = ?
                WHERE PatientID = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssss", 
            $name,
            $contactNumber,
            $email,
            $address,
            $nic,
            $dob,
            $gender,
            $reason,
            $guardianName,
            $guardianContact,
            $guardianNic,
            $patientId
        );

        if ($stmt->execute()) {
            $_SESSION['success'] = "Patient updated successfully!";
        } else {
            $_SESSION['error'] = "Error updating patient: " . $stmt->error;
        }
        
        header("Location: registerPatient.php");
        exit();

    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: registerPatient.php");
        exit();
    }
}