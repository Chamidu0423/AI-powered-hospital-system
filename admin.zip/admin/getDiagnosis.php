<?php
include 'config.php';

if (isset($_GET['id'])) {
    $diagnosisId = $_GET['id'];
    
    $sql = "SELECT d.*, p.Name as PatientName, p.PatientID, p.ContactNumber, p.NIC, 
                  a.Date as AppointmentDate, a.Time as AppointmentTime, s.Name as DoctorName 
           FROM Diagnosis d 
           JOIN Patient p ON d.PatientID = p.PatientID 
           LEFT JOIN Appointment a ON d.AppointmentID = a.AppointmentID 
           LEFT JOIN Staff s ON a.StaffID = s.StaffID 
           WHERE d.DiagnosisID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $diagnosisId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $diagnosis = $result->fetch_assoc();
        
        echo '<div data-diagnosis-id="' . $diagnosis['DiagnosisID'] . '">';
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6 class="font-weight-bold">Diagnosis ID:</h6>';
        echo '<p>' . $diagnosis['DiagnosisID'] . '</p>';
        
        echo '<h6 class="font-weight-bold">Patient:</h6>';
        echo '<p>' . $diagnosis['PatientName'] . ' (' . $diagnosis['PatientID'] . ')</p>';
        
        echo '<h6 class="font-weight-bold">Contact Number:</h6>';
        echo '<p>' . $diagnosis['ContactNumber'] . '</p>';
        
        echo '<h6 class="font-weight-bold">NIC:</h6>';
        echo '<p>' . $diagnosis['NIC'] . '</p>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        if ($diagnosis['AppointmentDate']) {
            echo '<h6 class="font-weight-bold">Appointment Date:</h6>';
            echo '<p>' . $diagnosis['AppointmentDate'] . '</p>';
            
            echo '<h6 class="font-weight-bold">Appointment Time:</h6>';
            echo '<p>' . date('h:i A', strtotime($diagnosis['AppointmentTime'])) . '</p>';
            
            echo '<h6 class="font-weight-bold">Doctor:</h6>';
            echo '<p>' . $diagnosis['DoctorName'] . '</p>';
        }
        
        echo '<h6 class="font-weight-bold">Status:</h6>';
        echo '<p>' . $diagnosis['Status'] . '</p>';
        echo '</div>';
        
        echo '<div class="col-12 mt-3">';
        echo '<h6 class="font-weight-bold">Description:</h6>';
        echo '<p>' . nl2br($diagnosis['Description']) . '</p>';
        
        if (!empty($diagnosis['Medicine'])) {
            echo '<h6 class="font-weight-bold">Prescribed Medicine:</h6>';
            echo '<p>' . nl2br($diagnosis['Medicine']) . '</p>';
        }
        
        if (!empty($diagnosis['TestTitle'])) {
            echo '<h6 class="font-weight-bold">Lab Test:</h6>';
            echo '<p>' . $diagnosis['TestTitle'] . '</p>';
            
            // Check if lab test has been performed
            $testSql = "SELECT TestID FROM Laboratory WHERE DiagnosisID = ?";
            $testStmt = $conn->prepare($testSql);
            $testStmt->bind_param("s", $diagnosisId);
            $testStmt->execute();
            $testResult = $testStmt->get_result();
            
            if ($testResult->num_rows > 0) {
                $testRow = $testResult->fetch_assoc();
                echo '<p><a href="printTest.php?id=' . $testRow['TestID'] . '" target="_blank" class="btn btn-sm btn-outline-primary">View Test Results</a></p>';
            } else {
                echo '<p><span class="badge bg-warning text-dark">Test Pending</span></p>';
            }
        }
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-danger">Diagnosis not found</div>';
    }
    
    $stmt->close();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>