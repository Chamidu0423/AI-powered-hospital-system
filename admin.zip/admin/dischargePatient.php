<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $wardID = $_POST['wardID'];
    $outDate = $_POST['outDate'];

    $sql = "UPDATE Ward SET OutDate = ? WHERE WardID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $outDate, $wardID);

    if ($stmt->execute()) {
        echo "Patient discharged successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>